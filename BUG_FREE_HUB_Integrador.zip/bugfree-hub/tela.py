"""Tela interativa do BUG FREE: digite um valor bruto e veja ele normalizado.

    python tela.py          abre http://localhost:8000 no navegador

Usa exatamente as mesmas funcoes do pipeline (bugfree/normalizacao.py,
bugfree/crm.py, bugfree/parsers.py). Nada aqui reimplementa regra.
"""
import json
import re
import sys
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from bugfree import auditoria as A
from bugfree import config, crm, modelo_frete, parsers
from bugfree import normalizacao as N
from bugfree.catalogos import APELIDOS_CIDADE, PESO_PADRAO_VEICULO, STATUS, TIPOS_CARGA, chave
from bugfree.schema import registro_bruto

PORTA = 8000
PAGINA = Path(__file__).resolve().parent / "bugfree" / "tela.html"
CLIENTES = crm.carregar_crm(config.ARQ_CRM)
if not (config.DIR_OUTPUT / "base_final.csv").exists():
    raise SystemExit("Rode primeiro:  python main.py   (gera a base e treina o modelo de frete)")
MODELO = modelo_frete.carregar_ou_treinar(config.DIR_OUTPUT / "modelo_frete.pkl",
                                          config.DIR_OUTPUT / "base_final.csv")


def r(saida, regra, ok=True, extra=None):
    return {"saida": saida, "regra": regra, "ok": ok, "extra": extra}


# --------------------------------------------------------------------------
# Um tratamento por campo: devolve a saida e a regra que foi aplicada
# --------------------------------------------------------------------------

def valor(s, _):
    v = N.normalizar_valor(s)
    if v is None:
        return r("nulo", "Nao foi possivel ler um numero.", False)
    fmt = A.formato_valor(s)
    regras = {
        A.FORMATOS_VALOR[0]: "Remove 'R$', tira o ponto de milhar e troca a virgula decimal por ponto.",
        A.FORMATOS_VALOR[1]: "Formato BR: tira o ponto de milhar e troca a virgula decimal por ponto.",
        A.FORMATOS_VALOR[2]: "Ja esta no padrao (ponto decimal).",
        A.FORMATOS_VALOR[3]: "Inteiro: so ganha as casas decimais.",
        A.FORMATOS_VALOR[4]: "Sufixo 'k' = mil: troca a virgula por ponto e multiplica por 1000.",
    }
    return r(f"{v:.2f}", regras.get(fmt, "Numero lido."), extra=f"Grafia detectada: {fmt}")


def peso(s, _):
    v = N.normalizar_peso(s)
    if v is None:
        return r("nulo", "Nao foi possivel ler o peso.", False)
    fmt = A.formato_peso(s)
    regra = ("Toneladas: multiplica por 1000 para ficar em kg." if fmt.startswith("ton")
             else "Ja esta em kg." if "kg" in fmt else "Sem unidade: assumido kg.")
    return r(f"{v:.1f} kg", regra, extra=f"Grafia detectada: {fmt}")


def data(s, canal):
    iso, ambigua = N.normalizar_data(s, canal)
    if iso is None:
        return r("nulo", "Data invalida ou em formato desconhecido.", False)
    t = s.strip().lower()
    if re.match(r"\d{4}-", t):
        regra = "Ja esta em ISO (aaaa-mm-dd)."
    elif re.fullmatch(r"\d{1,2}-[a-z]{3}-\d{4}", t):
        regra = "Mes por extenso abreviado (abr = 04) convertido para ISO."
    else:
        a, b = (int(x) for x in t.split("/")[:2])
        if a > 12:
            regra = f"{a} nao pode ser mes: lido como dia/mes."
        elif b > 12:
            regra = f"{b} nao pode ser mes: lido como mes/dia."
        elif ambigua:
            regra = (f"AMBIGUA: dia e mes podem ser trocados e o canal '{canal}' nao tem formato "
                     "fixo. Lido como dd/mm e marcado data_ambigua = True.")
        elif a == b:
            regra = "Dia e mes iguais: nao importa a ordem."
        else:
            regra = f"Canal '{canal}' tem formato fixo dd/mm (LOCALE_CANAL): sem ambiguidade."
    return r(iso, regra, ok=not ambigua, extra="data_ambigua = True" if ambigua else None)


def local(s, _):
    cidade, uf = N.normalizar_local(s)
    if not cidade:
        return r("nulo", "Cidade nao reconhecida no catalogo (ou UF nao combina). "
                         "Na base, isso descarta a demanda: 'rota incompleta'.", False)
    k = chave(s)
    partes = re.match(r"^(.+?)[\s/\-]+([a-z]{2})$", k)
    nome = partes[1] if partes and not k in APELIDOS_CIDADE else k
    if k in APELIDOS_CIDADE or nome in APELIDOS_CIDADE:
        regra = f"Apelido '{nome}' trocado pelo nome oficial."
    elif partes:
        regra = "Separa cidade e UF, tira acento/caixa e busca o nome oficial no catalogo."
    else:
        regra = "Cidade encontrada no catalogo; UF completada."
    return r(f"{cidade} / {uf}", regra)


def tipo(s, _):
    v = N.normalizar_tipo(s)
    if not v:
        return r("nulo", f"Fora do vocabulario controlado. Aceitos: {', '.join(sorted(TIPOS_CARGA))}.", False)
    return r(v, f"Vocabulario controlado: '{chave(s)}' -> {v}.")


def status(s, _):
    v = N.normalizar_status(s)
    if not v:
        return r("nulo", f"Fora do vocabulario controlado. Aceitos: {', '.join(sorted(set(STATUS.values())))}.", False)
    return r(v, f"Vocabulario controlado: '{chave(s)}' -> {v}.")


def cnpj(s, _):
    fmt = A.formato_cnpj(s)
    d = N.normalizar_cnpj(s)
    if d is None:
        motivo = ("Truncado" if fmt.startswith("truncado") else "Oculto" if fmt.startswith("oculto")
                  else "Digito verificador nao confere")
        return r("nulo", f"{motivo}: vira nulo. Um CNPJ parcial poderia apontar o cliente errado; "
                         "vinculo errado contamina faturamento, vinculo ausente so gera revisao.", False,
                 extra="A demanda seguira para o vinculo por razao social.")
    cli = next((c for c in CLIENTES if c["cnpj_digitos"] == d), None)
    extra = (f"Encontrado no CRM: {cli['cliente_id']} - {cli['razao_social']} (vinculo deterministico)"
             if cli else "CNPJ valido, mas nao esta no CRM: segue para o vinculo por razao social.")
    return r(d, "Remove a mascara e confere os dois digitos verificadores: valido.", extra=extra)


def cliente(s, _):
    cli, score = crm.melhor_candidato(s, CLIENTES)
    if not cli:
        return r("nulo", "Nome vazio.", False)
    lim = config.LIMIAR_FUZZY
    k = crm.nome_chave(s)
    if score >= lim:
        return r(f"{cli['cliente_id']} - {cli['razao_social']}",
                 f"Score {score:.1f} >= limiar {lim}: vinculo FUZZY aceito.",
                 extra=f"Comparado como '{k}' x '{cli['nome_chave']}'")
    return r("SEM_MATCH (curadoria)",
             f"Melhor candidato: {cli['razao_social']} com score {score:.1f}, abaixo do limiar {lim}.",
             False, extra=f"Comparado como '{k}' x '{cli['nome_chave']}'")


def mensagem(s, _):
    """Mensagem de WhatsApp inteira: parser + limpeza + CRM, como no pipeline."""
    corpo = re.sub(r"^.*?-\s*Cliente:\s*(WA-\d{4}\s*-\s*)?", "", s.strip(), count=1) if "Cliente:" in s else s
    campos = parsers._template(corpo) if "Empresa:" in corpo else parsers._texto_livre(corpo)
    bruto = registro_bruto(id_demanda="WA-TESTE", canal="whatsapp", **campos)
    limpo, motivo = N.normalizar_registro(bruto)
    if not motivo:
        crm.vincular([limpo], CLIENTES, config.LIMIAR_FUZZY)
    return {"bruto": bruto, "limpo": limpo, "motivo": motivo}


def qtd(s, _):
    q = N.normalizar_qtd(s)
    if q is None:
        return r("nulo", "Quantidade precisa ser um numero inteiro maior que zero. "
                         "Na base, isso descarta a demanda: 'quantidade invalida'.", False)
    return r(str(q), "Numero inteiro positivo: aceito.")


def veiculo(s, _):
    k = chave(s).rstrip("s")
    if k not in PESO_PADRAO_VEICULO:
        return r("nulo", "Tipo de veiculo desconhecido.", False)
    return r(k, f"Peso tipico: {PESO_PADRAO_VEICULO[k]} kg por {k} (usado se o peso nao for informado).")


# campo do formulario -> (campo do schema bruto, rotulo, tratamento)
FORMULARIO = [
    ("cliente_nome", "Cliente", None),
    ("cnpj", "CNPJ", cnpj),
    ("origem", "Origem", local),
    ("destino", "Destino", local),
    ("qtd_unidades", "Quantidade", qtd),
    ("veiculo", "Veiculo", veiculo),
    ("tipo_carga", "Tipo de carga", tipo),
    ("peso", "Peso", peso),
    ("valor_frete", "Valor do frete", valor),
    ("data_coleta", "Data de coleta", data),
    ("status", "Status", status),
]


def demanda(dados, _):
    """Formulario completo: mesma sequencia do pipeline (schema -> limpeza -> CRM)."""
    canal = dados.get("canal") or "whatsapp"
    campos = {k: str(dados.get(k) or "").strip() or None for k, _, _ in FORMULARIO}
    bruto = registro_bruto(id_demanda=dados.get("id_demanda") or "TELA-0001", canal=canal, **campos)
    limpo, motivo = N.normalizar_registro(bruto)
    crm.vincular([limpo], CLIENTES, config.LIMIAR_FUZZY)

    linhas = []
    for k, rotulo, fn in FORMULARIO:
        digitado = bruto[k]
        if k == "cliente_nome":
            if limpo["metodo_vinculo"] == "CNPJ":
                res = r(f"{limpo['cliente_id']} - {limpo['cliente_razao_social']}",
                        "Vinculado pelo CNPJ (deterministico).")
            elif digitado:
                res = cliente(digitado, canal)
            else:
                res = r("nulo", "Sem nome e sem CNPJ valido: nao ha como vincular.", False)
        elif digitado is None and k == "peso" and limpo["peso_estimado"]:
            res = r(f"{limpo['peso_kg']:.1f} kg", "Nao informado: estimado como quantidade x peso tipico do veiculo.",
                    extra="peso_estimado = True")
        elif digitado is None:
            padrao = k == "status"
            res = r(limpo["status"] if padrao else "nulo",
                    "Nao informado: recebe o status padrao NOVA." if padrao else "Nao informado.",
                    ok=padrao or k not in ("origem", "destino", "qtd_unidades"))
        else:
            res = fn(digitado, canal)
        linhas.append({"campo": rotulo, "digitado": digitado, **res})
    ia = modelo_frete.prever(MODELO, limpo)
    if ia.get("ok"):
        limpo["frete_justo_ia"] = ia["frete_justo"]
        limpo["veredito_ia"] = ia.get("veredito")
    return {"linhas": linhas, "limpo": limpo, "motivo": motivo, "ia": ia}


CAMPOS = {"demanda": demanda, "valor": valor, "peso": peso, "data": data, "local": local, "tipo": tipo,
          "status": status, "cnpj": cnpj, "cliente": cliente, "mensagem": mensagem}


class Handler(BaseHTTPRequestHandler):
    def _enviar(self, codigo, corpo, tipo_conteudo):
        dados = corpo.encode("utf-8")
        self.send_response(codigo)
        self.send_header("Content-Type", tipo_conteudo)
        self.send_header("Content-Length", str(len(dados)))
        self.end_headers()
        self.wfile.write(dados)

    def do_GET(self):
        if self.path in ("/", "/index.html"):
            self._enviar(200, PAGINA.read_text(encoding="utf-8"), "text/html; charset=utf-8")
        else:
            self._enviar(404, "nao encontrado", "text/plain; charset=utf-8")

    def do_POST(self):
        try:
            req = json.loads(self.rfile.read(int(self.headers.get("Content-Length", 0))) or b"{}")
            texto = str(req.get("texto", ""))
            if req.get("campo") == "demanda":
                res = demanda(req.get("dados") or {}, None)
            elif not texto.strip():
                res = None
            else:
                res = CAMPOS[req["campo"]](texto, req.get("canal", "whatsapp"))
            self._enviar(200, json.dumps(res, ensure_ascii=False, default=str), "application/json")
        except Exception as e:  # mostra o erro na tela em vez de derrubar o servidor
            self._enviar(200, json.dumps({"saida": "erro", "regra": str(e), "ok": False}), "application/json")

    def log_message(self, *args):
        pass


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    url = f"http://localhost:{PORTA}"
    ThreadingHTTPServer.allow_reuse_address = False  # no Windows, evita 2 servidores na mesma porta
    try:
        srv = ThreadingHTTPServer(("127.0.0.1", PORTA), Handler)
    except OSError:
        print(f"A porta {PORTA} ja esta em uso: a tela provavelmente ja esta aberta em {url}")
        webbrowser.open(url)
        return
    print(f"BUG FREE - tela interativa em {url}   (Ctrl+C para sair)")
    if "--sem-navegador" not in sys.argv:
        webbrowser.open(url)
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\nencerrado.")


if __name__ == "__main__":
    main()
