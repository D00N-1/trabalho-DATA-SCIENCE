# W5HH – Condução do projeto BUG FREE (UNIVEL x Rodomax)

Condução do projeto organizada pelo framework W5HH, conforme a metodologia da proposta.

---

## Why – Por quê

A Rodomax recebe demandas de frete por **5 canais heterogêneos** (WhatsApp, e-mail, portal/API,
planilha legado e PDF). Hoje um operador lê cada fonte, interpreta e digita numa planilha central.

O lote analisado mostra o tamanho do problema, medido pela auditoria do próprio HUB:

| Evidência (lote de 113 demandas) | Valor |
|---|---|
| Grafias diferentes para 13 cidades de origem | 24 |
| Grafias diferentes para o valor do frete | 5 ("R$ 1.500,00", "1.500,00", "1500.00", "1500", "1,5k") |
| Peso informado em kg e em toneladas na mesma coluna | sim |
| CNPJ truncado, oculto ou ausente | 26 de 113 (23%) |
| Demandas reenviadas em duplicidade pela API | 2 |
| Demandas sem destino (inaproveitáveis sem contato) | 6 |

**Consequências do processo manual:** não há rastreabilidade de perdas (a demanda some e ninguém
sabe por quê), cada operador escreve de um jeito, o custo cresce linearmente com o volume e há risco
de erro de digitação (ex.: "8,3" no lugar de "8,3k").

**Proposta de valor do HUB:** ingestão automática, um formato único, nenhum descarte silencioso e
uma base pronta para IA. A 2ª etapa demonstra isso com a estimativa de frete justo.

---

## What – O quê

### Requisitos funcionais
| ID | Requisito | Onde está |
|---|---|---|
| RF01 | Ler os 5 canais sem intervenção manual | `parsers.py` |
| RF02 | Mapear todas as fontes para um schema único | `schema.py`, `MAPA_COLUNAS` |
| RF03 | Medir as inconsistências antes de corrigir (auditoria estatística) | `auditoria.py` |
| RF04 | Eliminar colunas obsoletas, registrando o motivo | `parsers.py` + `auditoria.colunas_obsoletas` |
| RF05 | Normalizar datas, valores, pesos, rotas, tipos, status e documentos | `normalizacao.py` |
| RF06 | Excluir registros inválidos, gravando id, canal e motivo | `normalizacao.executar` → `descartes.csv` |
| RF07 | Vincular cada demanda ao cadastro do CRM | `crm.py` |
| RF08 | Unificar os lotes numa base final e gerar relatórios | `main.py` → `output/` |
| RF09 | Estimar o frete justo de uma demanda nova (2ª etapa) | `modelo_frete.py` |
| RF10 | Interface para cadastrar e normalizar uma demanda | `tela.py` |

### Requisitos não funcionais
| ID | Requisito | Como é atendido |
|---|---|---|
| RNF01 | **Rastreabilidade:** nenhum registro ou coluna some sem motivo | `descartes.csv`, tabela de colunas obsoletas |
| RNF02 | **Reprodutibilidade:** mesma entrada, mesma saída | Semente fixa, `random_state=42`, sem dependência de rede |
| RNF03 | **Extensibilidade:** canal novo com baixo custo | Um leitor novo em `LEITORES`; a limpeza não muda |
| RNF04 | **Desempenho:** processar o lote em segundos | Lote completo + treino do modelo em poucos segundos num notebook comum |
| RNF05 | **Portabilidade:** rodar em Windows, Linux e Mac | Python puro + bibliotecas do PyPI; servidor web da biblioteca padrão |
| RNF06 | **Privacidade (LGPD):** minimizar dados pessoais | Colunas pessoais eliminadas (DIGITADO_POR, Contato); o modelo não usa nome nem CNPJ |
| RNF07 | **Conservadorismo na dúvida:** preferir nulo a valor errado | CNPJ parcial → nulo; limiar de vínculo no topo da faixa ótima |

### Transformações lógicas
Separação cidade/UF e apelidos, conversão monetária, kg/toneladas, datas em ISO com formato por
canal, vocabulário controlado, validação de CNPJ pelos dígitos verificadores, estimativa de peso
pelo tipo de veículo e deduplicação por `id_demanda`. Detalhes em `DOCUMENTACAO.md`, seção 6.6.

### Restrições arquiteturais
- **Parser não limpa; limpador não parseia.** O schema é o único acoplamento.
- Processamento em **lote** (sem carga incremental nesta versão).
- Sem integração com o ERP em produção nesta versão.
- O gabarito de vínculos só pode ser usado para calibrar o limiar, nunca para decidir.

### As 8 etapas de execução da proposta → código
| # | Etapa da proposta | Implementação | Evidência na saída |
|---|---|---|---|
| 1 | Leitura parametrizada de logs brutos | `parsers.py`: um leitor por canal, caminhos em `config.py`, encoding e separador por fonte | 113 registros lidos |
| 2 | Mapeamento de inconsistências implícitas | `auditoria.py`: cardinalidade, grafias, formatos, IDs repetidos | 24 grafias → 13 cidades |
| 3 | Auditoria estatística inicial | `auditoria.estatisticas`: média, desvio, quartis, outliers (IQR) | Tabela e boxplot no relatório |
| 4 | Exclusão direcionada de registros incompletos | `normalizacao.executar` | 10 descartes, 100% com motivo |
| 5 | Eliminação de colunas obsoletas | Leitores registram toda coluna fora do schema; auditoria justifica | 11 colunas eliminadas com evidência |
| 6 | Normalização dos dados | `normalizacao.py` | Base final padronizada |
| 7 | Junções lógicas com o CRM | `crm.vincular`: CNPJ → similaridade → curadoria | 78 + 15 vinculados, 10 em curadoria |
| 8 | Concatenação e unificação de lotes | `ler_todos` junta 13 arquivos (6 e-mails, 3 PDFs...) dos 5 canais | `base_final.csv` com 103 linhas |

---

## Who – Quem

### 1ª etapa – HUB
| Integrante | Responsabilidade principal |
|---|---|
| João G. Reis | Problema e diagnóstico (canais, cardinalidade, formatos) |
| Alessandro L. Lorensi | Objetivo e escopo |
| Vinicius Soares | Arquitetura e ingestão (leitores) |
| Eduardo Reway | Normalização, limitações e próximos passos |
| Kauã Foscarini | Exclusão direcionada e resultados (funil, vínculo ao CRM) |

### 2ª etapa – IA
| Integrante | Responsabilidade principal |
|---|---|
| Alessandro L. Lorensi | Integração do pipeline com a camada de IA, análise crítica (LGPD e riscos) e redação do relatório |
| Kauã Foscarini Mendes | Preparação e codificação dos atributos a partir da base estruturada e testes de validação |
| Eduardo Reway | Desenvolvimento do protótipo (pipeline e sistema de demandas), publicação no GitHub, apresentação e demonstração da IA no protótipo |
| João Gabriel Reis dos Santos | Definição do problema de negócio e análise dos exemplos de acertos e erros |
| Vinicius Soares Back | Treinamento do algoritmo de IA e função de inferência para novos casos |

As autoavaliações ficam no relatório individual de cada integrante, como pede a proposta.

---

## Where – Onde

| Item | Ferramenta |
|---|---|
| Linguagem | Python 3.10+ (testado em 3.14) |
| Bibliotecas | pandas, numpy, scikit-learn, rapidfuzz, pdfplumber, fpdf2, matplotlib |
| Ambiente | Notebook Windows 11; dependências com `uv` ou `pip` |
| Execução | Terminal (PowerShell) e navegador para o relatório HTML e o sistema |
| Versionamento | Git + GitHub |
| Apoio | IA generativa como apoio ao desenvolvimento, declarada no relatório |
| Gestão | Divisão de tarefas por estágio do pipeline e comunicação entre os integrantes |

---

## When – Quando

Marcos fixos da disciplina: entrega da 1ª etapa em **16/09/2026** e da 2ª etapa em **25/11/2026**.
Cronograma planejado das atividades:

```mermaid
gantt
    title BUG FREE - cronograma
    dateFormat  YYYY-MM-DD
    axisFormat  %d/%m
    section 1a etapa - HUB
    Entendimento do problema e dos canais   :a1, 2026-08-17, 7d
    Leitores dos 5 canais                   :a2, after a1, 10d
    Auditoria e mapeamento                  :a3, after a2, 5d
    Normalizacao e exclusao                 :a4, after a3, 7d
    Juncao com CRM e calibracao             :a5, after a4, 4d
    Relatorio e apresentacao                :crit, a6, 2026-09-10, 6d
    Entrega 1a etapa                        :milestone, m1, 2026-09-16, 0d
    section 2a etapa - IA
    Escolha do problema e da tecnica        :b1, 2026-10-26, 7d
    Preparacao dos dados e atributos        :b2, after b1, 7d
    Modelos, linha de base e avaliacao      :b3, after b2, 10d
    Prototipo (tela) e testes               :b4, after b3, 7d
    Relatorio e ensaio                      :crit, b5, 2026-11-19, 6d
    Entrega 2a etapa                        :milestone, m2, 2026-11-25, 0d
```

**Atividades críticas** (atrasar uma delas atrasa a entrega): os leitores (sem eles nada roda), a
normalização (base de tudo) e, na 2ª etapa, a avaliação com linha de base (critério de nota).

---

## How – Como

- **Metodologia:** ciclos curtos com entregas incrementais. Cada estágio do pipeline foi construído
  e validado antes do próximo, conferindo os números da auditoria a cada passo.
- **Reuniões:** encontros do grupo para alinhar o andamento (o que foi feito, o que vem a seguir e
  os bloqueios) e dividir as tarefas.
- **Quadro de tarefas:** organização no estilo Kanban (a fazer, em andamento, concluído), com uma
  tarefa por estágio do pipeline.
- **Padrões de qualidade:**
  - um módulo por estágio, com a responsabilidade documentada no topo do arquivo;
  - nenhum descarte nem coluna eliminada sem motivo registrado;
  - resultados reprodutíveis (semente fixa) e conferidos contra os números esperados (113 → 103 → 93);
  - avaliação do modelo sempre contra uma linha de base e em dados de teste não vistos;
  - código versionado no GitHub.

---

## How Much – Quanto (viabilidade)

### Técnica
- **Hardware:** qualquer computador atual (o lote inteiro e o treino rodam em segundos, com menos
  de 1 GB de memória). Não exige GPU nem servidor dedicado.
- **Software:** só ferramentas gratuitas e de código aberto (Python e bibliotecas do PyPI).
- **Riscos técnicos:** formatos novos nos canais exigem ajuste dos leitores; texto livre continua
  sendo a parte mais frágil.

### Econômica (estimativa)
Premissas adotadas na estimativa:

| Premissa | Valor adotado |
|---|---|
| Volume de demandas | 1.000 por mês |
| Tempo manual por demanda (ler, interpretar, digitar, conferir) | 4 min |
| Tempo com o HUB (só a curadoria dos ~10% sem vínculo e dos descartes) | 0,5 min em média |
| Custo da hora do operador (salário + encargos) | R$ 30/h |

| | Manual | Com o HUB |
|---|---|---|
| Horas por mês | 66,7 h | 8,3 h |
| Custo por mês | R$ 2.000 | R$ 250 |
| **Economia** | | **≈ R$ 1.750/mês (≈ R$ 21.000/ano)** |

**Custo de desenvolvimento** (valor de mercado equivalente): ~200 h × R$ 60/h ≈ R$ 12.000.
**Infraestrutura:** praticamente zero (roda num computador existente).
**Retorno do investimento:** ≈ 7 meses, sem contar benefícios difíceis de medir: menos erro de
digitação, rastreabilidade, resposta mais rápida ao cliente e a cotação apoiada pela IA.

### Operacional
- **Aceitação:** o operador continua no controle (revisa a curadoria e decide o frete). O HUB tira a
  digitação, não o trabalho de decisão. Isso reduz a resistência.
- **Treinamento:** curto (cerca de 1 a 2 horas), para usar a tela, ler `descartes.csv` e
  `curadoria_crm.csv` e interpretar o alerta de frete fora da curva.
- **Curva de adoção sugerida:** 2 semanas rodando em paralelo com o processo manual (comparando os
  resultados), depois troca gradual por canal, começando pela API e pela planilha, as fontes mais
  estáveis.
