"""Etapa 2 - IA: estimativa de FRETE JUSTO (regressao).

Pergunta de negocio: "qual seria um frete justo para esta rota e esta carga?"
Quem usa: o operador comercial, na hora de cotar ou aceitar uma demanda.

Alvo:      valor do frete POR VEICULO (valor_frete / qtd_unidades).
           O frete total estimado = previsao x quantidade.
Atributos: distancia da rota (km, calculada a partir das cidades normalizadas),
           peso medio por veiculo (diferencia moto, carro, caminhonete),
           tipo de carga (one-hot).
Modelos:   linha de base (media do treino), regressao linear e arvore de regressao.
Avaliacao: treino/teste 75/25 + validacao cruzada 5-fold; MAE e R2.
"""
import csv
import pickle

import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, r2_score
from sklearn.model_selection import KFold, cross_val_predict, train_test_split
from sklearn.tree import DecisionTreeRegressor

from .catalogos import distancia_km

SEMENTE = 42
TIPOS = ["CEGONHA", "PRANCHA", "GUINCHO", "BAU", "SIDER", "CARRETA_ABERTA", "CONTAINER"]
COLUNAS = ["distancia_km", "peso_por_veiculo", "km_x_porte", "peso_informado"] + [f"tipo_{t}" for t in TIPOS]


# --------------------------------------------------------------------------
# Preparacao dos dados
# --------------------------------------------------------------------------

def _num(v):
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def atributos(r, mediana_peso):
    """Transforma uma demanda normalizada no vetor de atributos do modelo."""
    km = distancia_km(r.get("origem_cidade"), r.get("destino_cidade"))
    qtd = _num(r.get("qtd_unidades"))
    peso = _num(r.get("peso_kg"))
    peso_v = peso / qtd if peso and qtd else None
    pv = peso_v if peso_v is not None else mediana_peso   # imputacao pela mediana
    x = {"distancia_km": km,
         "peso_por_veiculo": pv,
         # interacao: o custo por km cresce com o porte do veiculo (moto x carro x caminhonete)
         "km_x_porte": km * pv / 1000 if km is not None else None,
         "peso_informado": 1.0 if peso_v is not None else 0.0}
    for t in TIPOS:
        x[f"tipo_{t}"] = 1.0 if r.get("tipo_carga") == t else 0.0
    return [x[c] for c in COLUNAS], km


def preparar(base):
    """Filtra demandas utilizaveis e monta X (atributos), y (R$/veiculo) e qtd."""
    pesos = [_num(r["peso_kg"]) / _num(r["qtd_unidades"]) for r in base
             if _num(r.get("peso_kg")) and _num(r.get("qtd_unidades"))]
    mediana_peso = float(np.median(pesos))
    X, y, qtd, ids, fora = [], [], [], [], []
    for r in base:
        q, v = _num(r.get("qtd_unidades")), _num(r.get("valor_frete"))
        x, km = atributos(r, mediana_peso)
        if not q or not v or km is None:
            fora.append(r["id_demanda"])
            continue
        X.append(x)
        y.append(v / q)
        qtd.append(q)
        ids.append(r["id_demanda"])
    return np.array(X), np.array(y), np.array(qtd), ids, mediana_peso, fora


# --------------------------------------------------------------------------
# Treino e avaliacao
# --------------------------------------------------------------------------

class LinhaDeBase:
    """Referencia simples: sempre preve a media do frete por veiculo do treino."""

    def fit(self, X, y):
        self.media = float(np.mean(y))
        return self

    def predict(self, X):
        return np.full(len(X), self.media)


def _metricas(y_true_total, y_pred_total):
    return {"mae": round(float(mean_absolute_error(y_true_total, y_pred_total)), 2),
            "r2": round(float(r2_score(y_true_total, y_pred_total)), 3),
            "mape": round(float(np.mean(np.abs(y_pred_total - y_true_total) / y_true_total) * 100), 1)}


def treinar_e_avaliar(base):
    X, y, qtd, ids, mediana_peso, fora = preparar(base)
    idx = np.arange(len(y))
    tr, te = train_test_split(idx, test_size=0.25, random_state=SEMENTE)
    kf = KFold(n_splits=5, shuffle=True, random_state=SEMENTE)

    # profundidade da arvore escolhida por validacao cruzada SO no treino
    busca = []
    for prof in [2, 3, 4, 5, 6, 8]:
        arv = DecisionTreeRegressor(max_depth=prof, min_samples_leaf=3, random_state=SEMENTE)
        p = cross_val_predict(arv, X[tr], y[tr], cv=kf)
        busca.append({"max_depth": prof, "mae_cv": round(float(mean_absolute_error(y[tr] * qtd[tr], p * qtd[tr])), 2)})
    melhor_prof = min(busca, key=lambda b: b["mae_cv"])["max_depth"]

    modelos = {
        "Linha de base (media)": LinhaDeBase(),
        "Regressao linear": LinearRegression(),
        f"Arvore de regressao (max_depth={melhor_prof})":
            DecisionTreeRegressor(max_depth=melhor_prof, min_samples_leaf=3, random_state=SEMENTE),
    }
    resultados = []
    for nome, m in modelos.items():
        m.fit(X[tr], y[tr])
        teste = _metricas(y[te] * qtd[te], m.predict(X[te]) * qtd[te])
        cv = cross_val_predict(m, X, y, cv=kf) if not isinstance(m, LinhaDeBase) else \
            np.concatenate([np.full(len(b), y[a].mean()) for a, b in kf.split(X)])[np.argsort(np.concatenate([b for _, b in kf.split(X)]))]
        resultados.append({"modelo": nome, "teste": teste, "cv5": _metricas(y * qtd, cv * qtd)})

    vencedor = min(resultados[1:], key=lambda r: r["teste"]["mae"])
    modelo = modelos[vencedor["modelo"]]

    # previsoes no conjunto de teste (exemplos de acertos e erros)
    prev_te = modelo.predict(X[te]) * qtd[te]
    base_te = modelos["Linha de base (media)"].predict(X[te]) * qtd[te]
    exemplos = []
    por_id = {r["id_demanda"]: r for r in base}
    for i, p, b in zip(te, prev_te, base_te):
        r = por_id[ids[i]]
        real = y[i] * qtd[i]
        exemplos.append({"id_demanda": ids[i],
                         "rota": f"{r['origem_cidade']}/{r['origem_uf']} -> {r['destino_cidade']}/{r['destino_uf']}",
                         "km": X[i][0], "qtd": int(qtd[i]), "tipo": r["tipo_carga"] or "-",
                         "real": round(real, 2), "previsto": round(float(p), 2),
                         "linha_de_base": round(float(b), 2),
                         "erro_pct": round(float((p - real) / real * 100), 1)})
    exemplos.sort(key=lambda e: abs(e["erro_pct"]))

    # faixa "normal" de desvio, medida por validacao cruzada no modelo final
    cv_final = cross_val_predict(modelo, X, y, cv=kf)
    desvio = (y - cv_final) / cv_final * 100
    faixa = (round(float(np.percentile(desvio, 5)), 1), round(float(np.percentile(desvio, 95)), 1))

    # modelo final treinado com todos os dados (para uso no prototipo)
    modelo.fit(X, y)
    explicacao = _explicar(modelo)
    return {
        "n_total": int(len(y)), "n_treino": int(len(tr)), "n_teste": int(len(te)),
        "fora_do_modelo": fora, "atributos": COLUNAS, "busca_profundidade": busca,
        "resultados": resultados, "vencedor": vencedor["modelo"], "explicacao": explicacao,
        "faixa_normal_pct": faixa, "exemplos_teste": exemplos,
        "_artefato": {"modelo": modelo, "mediana_peso": mediana_peso, "faixa": faixa,
                      "nome": vencedor["modelo"], "mae_teste": vencedor["teste"]["mae"],
                      "mape_teste": vencedor["teste"]["mape"]},
    }


def _explicar(modelo):
    if isinstance(modelo, LinearRegression):
        coef = dict(zip(COLUNAS, modelo.coef_))
        return {"tipo": "linear", "intercepto": round(float(modelo.intercept_), 2),
                "coeficientes": {k: round(float(v), 4) for k, v in coef.items()}}
    imp = sorted(zip(COLUNAS, modelo.feature_importances_), key=lambda x: -x[1])
    return {"tipo": "arvore", "importancia": {k: round(float(v), 3) for k, v in imp if v > 0}}


# --------------------------------------------------------------------------
# Uso: demanda nova -> frete justo
# --------------------------------------------------------------------------

def salvar(artefato, caminho):
    with open(caminho, "wb") as f:
        pickle.dump(artefato, f)


def carregar(caminho):
    with open(caminho, "rb") as f:
        return pickle.load(f)


def carregar_ou_treinar(caminho_modelo, caminho_base):
    if caminho_modelo.exists():
        return carregar(caminho_modelo)
    with open(caminho_base, encoding="utf-8-sig") as f:
        base = list(csv.DictReader(f))
    art = treinar_e_avaliar(base)["_artefato"]
    salvar(art, caminho_modelo)
    return art


def prever(artefato, demanda):
    """Recebe uma demanda normalizada e devolve o frete justo e o veredito."""
    x, km = atributos(demanda, artefato["mediana_peso"])
    qtd = _num(demanda.get("qtd_unidades"))
    if km is None or not qtd:
        return {"ok": False, "motivo": "Precisa de origem, destino e quantidade validos para estimar."}
    por_veiculo = float(artefato["modelo"].predict(np.array([x]))[0])
    justo = por_veiculo * qtd
    lo, hi = artefato["faixa"]
    res = {"ok": True, "distancia_km": km, "frete_justo": round(justo, 2),
           "por_veiculo": round(por_veiculo, 2),
           "faixa_min": round(justo * (1 + lo / 100), 2), "faixa_max": round(justo * (1 + hi / 100), 2),
           "modelo": artefato["nome"], "mae": artefato["mae_teste"],
           "peso_imputado": x[2] == 0.0}
    informado = _num(demanda.get("valor_frete"))
    if informado:
        dif = (informado - justo) / justo * 100
        res["informado"] = informado
        res["diferenca_pct"] = round(dif, 1)
        res["veredito"] = ("ABAIXO DA CURVA" if dif < lo else "ACIMA DA CURVA" if dif > hi
                           else "DENTRO DO ESPERADO")
    return res
