"""Relatorio HTML de auditoria (arquivo unico, graficos embutidos)."""
import base64
import html
import io
from collections import Counter

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

from . import normalizacao as N  # noqa: E402
from .auditoria import formato_cnpj  # noqa: E402

AZUL, LARANJA, CINZA, VERDE, VERMELHO = "#1e2a38", "#e8a33d", "#9aa5b1", "#3f8f6b", "#b5483b"
NOMES_CANAL = {"whatsapp": "WhatsApp", "email": "E-mail", "api": "Portal / API",
               "csv": "Planilha legado", "pdf": "Ordem de coleta (PDF)"}

plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10,
                     "axes.spines.top": False, "axes.spines.right": False,
                     "axes.edgecolor": CINZA, "axes.titleweight": "bold",
                     "axes.titlesize": 11, "axes.titlelocation": "left"})


def _img(fig):
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=130, bbox_inches="tight")
    plt.close(fig)
    return f'<img src="data:image/png;base64,{base64.b64encode(buf.getvalue()).decode()}">'


def _barh(rotulos, valores, titulo, cor=LARANJA, sufixo="", largura=7):
    fig, ax = plt.subplots(figsize=(largura, 0.45 * len(rotulos) + 0.9))
    y = range(len(rotulos))[::-1]
    ax.barh(list(y), valores, color=cor, height=0.6)
    ax.set_yticks(list(y), rotulos)
    ax.set_title(titulo)
    ax.xaxis.set_visible(False)
    ax.spines["bottom"].set_visible(False)
    for yi, v in zip(y, valores):
        ax.text(v, yi, f" {v:g}{sufixo}", va="center", fontsize=9, color=AZUL)
    ax.set_xlim(0, max(valores) * 1.18)
    return _img(fig)


def _tabela(cabecalho, linhas, classe=""):
    th = "".join(f"<th>{html.escape(str(c))}</th>" for c in cabecalho)
    trs = "".join("<tr>" + "".join(f"<td>{html.escape('' if v is None else str(v))}</td>"
                                   for v in l) + "</tr>" for l in linhas)
    return f'<table class="{classe}"><thead><tr>{th}</tr></thead><tbody>{trs}</tbody></table>'


def _exemplos_transformacao(brutos):
    """Busca nos dados reais um exemplo de cada transformacao."""
    def primeiro(cond):
        return next((r for r in brutos if cond(r)), None)

    ex = []
    r = primeiro(lambda r: r["origem"] and " - " in str(r["origem"]))
    if r:
        ex.append(("Separacao cidade / UF", r["origem"], " / ".join(N.normalizar_local(r["origem"]))))
    r = primeiro(lambda r: r["origem"] and str(r["origem"]).lower() in ("cwb", "foz", "poa"))
    if r:
        ex.append(("Apelido de cidade", r["origem"], " / ".join(N.normalizar_local(r["origem"]))))
    for cond in (lambda v: str(v).startswith("R$"), lambda v: str(v).endswith("k")):
        r = primeiro(lambda r: r["valor_frete"] is not None and cond(r["valor_frete"]))
        if r:
            ex.append(("Conversao monetaria", r["valor_frete"], f"{N.normalizar_valor(r['valor_frete']):.2f}"))
    r = primeiro(lambda r: r["peso"] and str(r["peso"]).endswith("t"))
    if r:
        ex.append(("Unificacao de grandeza (kg)", r["peso"], N.normalizar_peso(r["peso"])))
    r = primeiro(lambda r: r["data_coleta"] and "-" in str(r["data_coleta"])[:3])
    if r:
        ex.append(("Data", r["data_coleta"], N.normalizar_data(r["data_coleta"], r["canal"])[0]))
    r = primeiro(lambda r: r["data_coleta"] and "/" in str(r["data_coleta"])
                 and int(str(r["data_coleta"]).split("/")[1]) > 12)
    if r:
        ex.append(("Data (mes/dia detectado)", r["data_coleta"], N.normalizar_data(r["data_coleta"], r["canal"])[0]))
    r = primeiro(lambda r: r["tipo_carga"] == "cegonheira")
    if r:
        ex.append(("Vocabulario controlado", r["tipo_carga"], N.normalizar_tipo(r["tipo_carga"])))
    r = primeiro(lambda r: r["status"] == "em cotação")
    if r:
        ex.append(("Vocabulario controlado", r["status"], N.normalizar_status(r["status"])))
    r = primeiro(lambda r: formato_cnpj(r["cnpj"]).startswith("truncado"))
    if r:
        ex.append(("Validacao de documento", f"{r['cnpj']} (truncado)", "nulo"))
    return ex


CSS = f"""
*{{box-sizing:border-box}} body{{margin:0;font-family:'Segoe UI',Calibri,Arial,sans-serif;
color:#1f2933;background:#eef0f2}} header{{background:{AZUL};color:#fff;padding:48px 8vw 40px}}
header .tag{{color:{LARANJA};font-weight:700;font-size:13px;letter-spacing:.06em}}
header h1{{font-family:Cambria,Georgia,serif;font-size:42px;margin:10px 0 6px}}
header p{{color:#c5ccd3;margin:4px 0}} header .bar{{width:180px;height:4px;background:{LARANJA};margin:22px 0}}
main{{padding:10px 8vw 60px}} section{{background:#fff;border-radius:10px;padding:26px 30px;margin:22px 0;
box-shadow:0 1px 3px rgba(0,0,0,.06)}} section .tag{{font-size:12px;font-weight:700;color:#52606d;letter-spacing:.06em}}
h2{{font-family:Cambria,Georgia,serif;font-size:27px;color:{AZUL};margin:4px 0 16px}}
h3{{font-size:15px;color:{AZUL};margin:18px 0 8px}}
.grid{{display:grid;grid-template-columns:1fr 1fr;gap:28px;align-items:start}}
.grid3{{display:grid;grid-template-columns:repeat(3,1fr);gap:22px;align-items:start}}
@media(max-width:900px){{.grid,.grid3{{grid-template-columns:1fr}}}}
table{{border-collapse:collapse;width:100%;font-size:13.5px}} th{{background:{AZUL};color:#fff;text-align:left;
padding:7px 10px;font-weight:600}} td{{border-bottom:1px solid #e4e7eb;padding:6px 10px}}
table.compacta td,table.compacta th{{padding:4px 7px;font-size:12px}}
img{{max-width:100%}} .kpis{{display:grid;grid-template-columns:repeat(4,1fr);gap:14px}}
.kpi{{background:{AZUL};color:#fff;border-radius:10px;padding:20px;text-align:center}}
.kpi b{{display:block;font-family:Cambria,Georgia,serif;font-size:44px}} .kpi.l b{{color:{LARANJA}}}
.kpi span{{color:#c5ccd3;font-size:13px}} .nota{{color:#52606d;font-size:13px;font-style:italic}}
.destaque{{color:#9a6512;font-weight:700}} pre{{background:{AZUL};color:#d9dee3;padding:18px;border-radius:8px;
white-space:pre-wrap;font-size:13px}} .scroll{{max-height:420px;overflow:auto}}
.ok{{color:{VERDE};font-weight:700}}
"""


def _secao_ia(ia, wa7):
    res = ia["resultados"]
    nomes = [r["modelo"].replace(" (", "\n(") for r in res]
    fig, axs = plt.subplots(1, 2, figsize=(11, 3.8))
    cores = [CINZA] + [LARANJA if r["modelo"] == ia["vencedor"] else AZUL for r in res[1:]]
    for ax, chave_m, titulo, fmt in [(axs[0], "mae", "MAE no teste (R$, menor e melhor)", "R$ {:,.0f}"),
                                     (axs[1], "r2", "R² no teste (maior e melhor)", "{:.2f}")]:
        vals = [r["teste"][chave_m] for r in res]
        ax.bar(range(len(vals)), vals, color=cores, width=0.6)
        ax.set_xticks(range(len(vals)), nomes, fontsize=8.5)
        for i, v in enumerate(vals):
            ax.text(i, v, fmt.format(v).replace(",", "."), ha="center", va="bottom", fontsize=9, color=AZUL)
        ax.set_title(titulo)
        ax.yaxis.set_visible(False)
    g_comp = _img(fig)

    ex = ia["exemplos_teste"]
    fig, ax = plt.subplots(figsize=(5.6, 4.6))
    reais = [e["real"] for e in ex]
    ax.scatter(reais, [e["linha_de_base"] for e in ex], color=CINZA, label="linha de base (media)", s=28)
    ax.scatter(reais, [e["previsto"] for e in ex], color=LARANJA, label=ia["vencedor"], s=34, edgecolor=AZUL, lw=.5)
    lim = max(reais + [e["previsto"] for e in ex]) * 1.05
    ax.plot([0, lim], [0, lim], "--", color=AZUL, lw=1, label="previsao perfeita")
    ax.set_xlabel("Frete real (R$)")
    ax.set_ylabel("Frete previsto (R$)")
    ax.set_title(f"Teste: real x previsto ({ia['n_teste']} demandas)")
    ax.legend(fontsize=8, frameon=False)
    g_disp = _img(fig)

    tab_res = _tabela(["Modelo", "MAE teste", "R² teste", "Erro % medio teste", "MAE validacao cruzada (5 folds)", "R² cv"],
                      [[r["modelo"], f"R$ {r['teste']['mae']:,.0f}".replace(",", "."), r["teste"]["r2"],
                        f"{r['teste']['mape']}%", f"R$ {r['cv5']['mae']:,.0f}".replace(",", "."), r["cv5"]["r2"]] for r in res])
    lin = lambda e: [e["id_demanda"], e["rota"], f"{e['km']:.0f}", e["qtd"], e["tipo"],
                     f"R$ {e['real']:,.0f}".replace(",", "."), f"R$ {e['previsto']:,.0f}".replace(",", "."),
                     f"{e['erro_pct']:+.1f}%"]
    cab = ["id", "rota", "km", "qtd", "tipo", "real", "previsto", "erro"]
    exp = ia["explicacao"]
    if exp["tipo"] == "linear":
        c = exp["coeficientes"]
        txt_exp = (f"Interpretacao: cada km soma cerca de R$ {c['distancia_km']:.2f} por veiculo, mais "
                   f"R$ {c['km_x_porte']:.2f} por km a cada tonelada de porte do veiculo (atributo km x porte). "
                   "Ou seja, rota longa com veiculo pesado custa mais: e o que o modelo aprendeu dos dados.")
    else:
        txt_exp = "Importancia dos atributos: " + ", ".join(f"{k} {v:.0%}" for k, v in exp["importancia"].items())
    mae_b = res[0]["teste"]["mae"]
    mae_v = next(r for r in res if r["modelo"] == ia["vencedor"])["teste"]["mae"]
    return f"""<section><div class="tag">ETAPA 2 · INTELIGENCIA ARTIFICIAL</div><h2>Qual seria um frete justo para esta rota e esta carga?</h2>
<p><b>Decisao apoiada:</b> o operador comercial cota ou aceita uma demanda. O modelo estima o frete justo e avisa
quando o valor pedido esta fora da curva. <b>Tecnica:</b> regressao (linear e arvore de regressao), comparada a uma
linha de base que sempre preve a media. <b>Alvo:</b> valor do frete por veiculo (frete total = previsao x quantidade).
<b>Atributos:</b> distancia da rota (calculada das cidades normalizadas pelo HUB), peso medio por veiculo,
interacao distancia x porte e tipo de carga.</p>
<p class="destaque">{ia['vencedor']}: erro medio de R$ {mae_v:,.0f} por frete, contra R$ {mae_b:,.0f} da linha de base
({100 * (1 - mae_v / mae_b):.0f}% menor). Treino {ia['n_treino']} / teste {ia['n_teste']} demandas.</p>
{g_comp}{tab_res}
<p class="nota">Profundidade da arvore escolhida por validacao cruzada so no treino:
{', '.join(f"max_depth={b['max_depth']}: R$ {b['mae_cv']:,.0f}" for b in ia['busca_profundidade'])}.</p>
<p>{txt_exp}</p>
<div class="grid"><div>{g_disp}</div><div>
<h3>Acertos (menor erro no teste)</h3>{_tabela(cab, [lin(e) for e in ex[:4]], "compacta")}
<h3>Erros (maior erro no teste)</h3>{_tabela(cab, [lin(e) for e in ex[-4:]], "compacta")}
<p class="nota">Os maiores erros vem de (a) mensagens do WhatsApp sem peso nem tipo de veiculo, em que o porte
foi imputado pela mediana, e (b) fretes realmente fora da curva: ai o "erro" e o alerta funcionando.</p></div></div>
<h3>Caso novo: WA-0007</h3>
<p>Cascavel/PR → Florianopolis/SC, {wa7['distancia_km']:.0f} km, 7 carros. Frete justo estimado:
<b>R$ {wa7['frete_justo']:,.0f}</b> (faixa normal R$ {wa7['faixa_min']:,.0f} a R$ {wa7['faixa_max']:,.0f}).
Informado: R$ {wa7['informado']:,.0f} ({wa7['diferenca_pct']:+.1f}%) → <b>{wa7['veredito']}</b>.
Para testar outros casos: <code>python tela.py</code>, aba Nova demanda, botao Exportar.</p></section>"""


def gerar(caminho, *, brutos_por_canal, aud, base, descartes, calib, limiar, texto_wa7, ia=None, wa7_ia=None):
    brutos = [r for regs in brutos_por_canal.values() for r in regs]
    n_brutos, n_base = len(brutos), len(base)
    vinc = Counter(r["metodo_vinculo"] for r in base)
    n_vinc = vinc["CNPJ"] + vinc["FUZZY"]
    s = []

    # 1. problema
    canais = list(brutos_por_canal)
    g_canais = _barh([NOMES_CANAL[c] for c in canais], [len(brutos_por_canal[c]) for c in canais],
                     "Registros brutos por canal", cor=AZUL)
    s.append(f"""<section><div class="tag">O PROBLEMA</div><h2>Cinco canais, um lote de {n_brutos} demandas</h2>
<div class="grid"><div>{g_canais}</div><div><h3>Formatos de entrada</h3>{_tabela(
        ["Canal", "Formato", "Registros"],
        [[NOMES_CANAL["whatsapp"], "texto livre ou template", len(brutos_por_canal["whatsapp"])],
         [NOMES_CANAL["email"], "tabela HTML (cabecalhos diferentes)", len(brutos_por_canal["email"])],
         [NOMES_CANAL["api"], "webhook JSON (com reenvios)", len(brutos_por_canal["api"])],
         [NOMES_CANAL["csv"], "CSV latin-1, separador ;", len(brutos_por_canal["csv"])],
         [NOMES_CANAL["pdf"], "PDF com tabela", len(brutos_por_canal["pdf"])]])}</div></div></section>""")

    # 2. diagnostico
    card = [[c["coluna"], c["distintos"], c["reais"]] for c in aud["cardinalidade"]]
    fv = aud["formatos"]["valor_frete"]
    g_fmt = _barh([f["formato"] for f in fv], [f["pct"] for f in fv],
                  "Valor do frete: % dos registros em cada grafia", sufixo="%")
    origem = aud["cardinalidade"][0]
    outros = "".join(f"<div><h3>{t}</h3>" + _tabela(["Formato", "Registros", "%"],
                                                [[f["formato"], f["registros"], f["pct"]] for f in aud["formatos"][k]], "compacta") + "</div>"
                     for k, t in [("peso", "Peso"), ("cnpj", "CNPJ"), ("data_coleta", "Data de coleta")])
    s.append(f"""<section><div class="tag">DIAGNOSTICO (ANTES DE QUALQUER CORRECAO)</div>
<h2>A mesma informacao, escrita de varios jeitos</h2><div class="grid"><div>
<h3>Cardinalidade inflada: valores distintos encontrados x valores reais</h3>
{_tabela(["Coluna", "Distintos", "Reais"], card)}
<p class="destaque">{origem['distintos']} grafias de origem para {origem['reais']} lugares reais.</p>
<p class="nota">Grafias de origem encontradas: {html.escape(' · '.join(repr(g) for g in origem['grafias']))}</p>
</div><div>{g_fmt}<p class="nota">O valor do frete chega em {len(fv)} grafias diferentes.</p></div></div>
<div class="grid3">{outros}</div>
<p class="nota">IDs repetidos encontrados: {', '.join(f'{k} ({v}x)' for k, v in aud['ids_repetidos'].items()) or 'nenhum'}.</p></section>""")

    # 2b. auditoria estatistica + colunas obsoletas
    est = aud.get("estatisticas", {})
    if est:
        nomes_est = {"valor_frete": "Valor do frete (R$)", "valor_por_veiculo": "Frete por veiculo (R$)",
                     "peso_kg": "Peso (kg)", "qtd_unidades": "Quantidade de veiculos"}
        f = lambda v: f"{v:,.0f}".replace(",", ".")
        tab_est = _tabela(["Campo", "n", "Media", "Desvio padrao", "Min", "Q1", "Mediana", "Q3", "Max", "Outliers (1,5 x IQR)"],
                          [[nomes_est[k], e["n"], f(e["media"]), f(e["desvio_padrao"]), f(e["minimo"]), f(e["q1"]),
                            f(e["mediana"]), f(e["q3"]), f(e["maximo"]), e["outliers_iqr"]] for k, e in est.items()])
        fig, ax = plt.subplots(figsize=(7, 2.4))
        vpv = [N.normalizar_valor(r["valor_frete"]) / q for r in brutos
               if (q := N.normalizar_qtd(r["qtd_unidades"])) and N.normalizar_valor(r["valor_frete"])]
        ax.boxplot(vpv, vert=False, widths=0.5, patch_artist=True,
                   boxprops=dict(facecolor=LARANJA, color=AZUL), medianprops=dict(color=AZUL, lw=2))
        ax.set_yticks([])
        ax.set_xlabel("R$ por veiculo")
        ax.set_title("Distribuicao do frete por veiculo (antes da limpeza)")
        g_box = _img(fig)
        obs = aud.get("colunas_obsoletas", [])
        s.append(f"""<section><div class="tag">AUDITORIA ESTATISTICA E COLUNAS OBSOLETAS</div>
<h2>Estatistica descritiva e o que foi eliminado</h2>
<p>Medido sobre os {n_brutos} registros brutos. Os valores sao convertidos so para medir; o registro original nao muda.</p>
{tab_est}<div class="grid"><div>{g_box}</div><div><p class="nota">A media do frete fica bem acima da mediana: a distribuicao
e assimetrica (poucas rotas longas e caras). Por isso a mediana e o IQR descrevem melhor o "frete tipico". Outliers pelo
criterio de Tukey: fora de Q1 - 1,5 x IQR e Q3 + 1,5 x IQR.</p></div></div>
<h3>Eliminacao de colunas obsoletas ({len(obs)} colunas)</h3>
{_tabela(["Canal", "Coluna", "Evidencia medida", "Motivo"], [[c['canal'], c['coluna'], c['evidencia'], c['motivo']] for c in obs])}
<p class="nota">Toda coluna fora do schema e registrada pelo leitor e justificada aqui. Nenhuma coluna some sem explicacao.
Duas delas (DIGITADO_POR e Contato) sao dados pessoais: elimina-las tambem atende ao principio de necessidade da LGPD.</p></section>""")

    # 3. ingestao (WA-0007)
    wa7 = next(r for r in base if r["id_demanda"] == "WA-0007")
    s.append(f"""<section><div class="tag">INGESTAO</div><h2>Do texto cru ao registro estruturado</h2>
<div class="grid"><div><h3>ANTES · WhatsApp exportado</h3><pre>{html.escape(texto_wa7)}</pre></div>
<div><h3>DEPOIS · registro no schema</h3>{_tabela(["Campo", "Valor"], [
        ["cliente_id", f"{wa7['cliente_id']} ({wa7['cliente_razao_social']})"],
        ["origem", f"{wa7['origem_cidade']} / {wa7['origem_uf']}"],
        ["destino", f"{wa7['destino_cidade']} / {wa7['destino_uf']}"],
        ["qtd_unidades", wa7["qtd_unidades"]], ["valor_frete", f"{wa7['valor_frete']:.2f}"],
        ["data_coleta", wa7["data_coleta"]], ["metodo_vinculo", f"{wa7['metodo_vinculo']} (score {wa7['score_vinculo']})"]])}
</div></div><p>Quatro decisoes nessa passagem: 'Floripa' vira o nome oficial, '8,3k' vira numero, '04/25' e lido como
mes/dia porque 25 nao pode ser mes, e 'Frota Pampa' encontra '{wa7['cliente_razao_social']}' no cadastro por similaridade.</p></section>""")

    # 4. normalizacao
    s.append(f"""<section><div class="tag">NORMALIZACAO</div><h2>As transformacoes aplicadas (exemplos reais do lote)</h2>
{_tabela(["Transformacao", "Entrada", "Saida"], _exemplos_transformacao(brutos))}
<p><b>Documento truncado vira nulo.</b> Um CNPJ parcial poderia apontar para o cliente errado. Vinculo errado
contamina faturamento; vinculo ausente so gera trabalho de revisao.</p></section>""")

    # 5. descartes
    mot = Counter(d["motivo"] for d in descartes)
    g_desc = _barh(list(mot), list(mot.values()), "Descartes por motivo")
    s.append(f"""<section><div class="tag">EXCLUSAO DIRECIONADA</div><h2>Nenhum registro some em silencio</h2>
<div class="grid"><div>{g_desc}<p class="destaque">{len(descartes)} de {n_brutos} registros excluidos ·
100% deles com motivo rastreavel</p></div><div><h3>descartes.csv</h3>
{_tabela(["id_demanda", "canal", "motivo", "valor bruto"], [[d['id_demanda'], d['canal'], d['motivo'], d['valor_bruto']] for d in descartes], "compacta")}
</div></div></section>""")

    # 6. resultado
    fig, ax = plt.subplots(figsize=(7, 3.2))
    etapas = ["Brutos ingeridos", "Base final", "Vinculados ao CRM"]
    vals = [n_brutos, n_base, n_vinc]
    ax.bar(etapas, vals, color=[CINZA, AZUL, LARANJA], width=0.55)
    for i, v in enumerate(vals):
        ax.text(i, v + 1.5, str(v), ha="center", fontweight="bold", color=AZUL)
    ax.set_ylim(0, n_brutos * 1.15)
    ax.set_title("Funil de aproveitamento")
    ax.yaxis.set_visible(False)
    g_funil = _img(fig)
    vlin = [["CNPJ (deterministico)", vinc["CNPJ"], f"{100 * vinc['CNPJ'] / n_base:.1f}%"],
            [f"Similaridade da razao social (score >= {limiar})", vinc["FUZZY"], f"{100 * vinc['FUZZY'] / n_base:.1f}%"],
            ["Sem match - vai para curadoria", vinc["SEM_MATCH"], f"{100 * vinc['SEM_MATCH'] / n_base:.1f}%"]]
    s.append(f"""<section><div class="tag">RESULTADO</div><h2>Funil de aproveitamento</h2>
<div class="kpis"><div class="kpi"><b>{n_brutos}</b><span>brutos ingeridos</span></div>
<div class="kpi l"><b>{len(descartes)}</b><span>descartados com motivo</span></div>
<div class="kpi"><b>{n_base}</b><span>base final unificada</span></div>
<div class="kpi"><b>{n_vinc}</b><span>vinculados ao CRM</span></div></div>
<p class="destaque">{100 * n_base / n_brutos:.1f}% de aproveitamento ({n_base} de {n_brutos} brutos chegam a base final) ·
{100 * n_vinc / n_base:.1f}% da base vinculada ao CRM ({n_vinc} de {n_base})</p>
<div class="grid"><div>{g_funil}</div><div><h3>Vinculacao ao cadastro (sobre os {n_base} da base final)</h3>
{_tabela(["Metodo", "Registros", "%"], vlin)}</div></div></section>""")

    # 7. calibracao
    curva = calib["curva"]
    fig, ax = plt.subplots(figsize=(8, 3.6))
    xs = [p["limiar"] for p in curva]
    faixa = calib["faixa_otima"]
    ax.axvspan(min(faixa) - 2.5, max(faixa) + 2.5, color=VERDE, alpha=0.08, label="faixa com melhor F1")
    ax.plot(xs, [p["precisao"] for p in curva], "o-", color=AZUL, label="Precisao (vinculos certos / vinculos feitos)")
    ax.plot(xs, [p["recall"] for p in curva], "s-", color=LARANJA, label="Recall (clientes encontrados / clientes reais)")
    ax.axvline(limiar, color=VERMELHO, ls="--", lw=1.2)
    ax.text(limiar + 0.6, 8, f"limiar usado = {limiar}", color=VERMELHO, fontsize=9)
    ax.set_xlabel("Limiar de similaridade (score minimo para aceitar o vinculo)")
    ax.set_ylabel("%")
    ax.set_ylim(0, 105)
    ax.set_xticks(xs)
    ax.legend(loc="lower left", fontsize=8, frameon=False)
    ax.set_title("Calibracao do limiar de similaridade")
    g_cal = _img(fig)
    s.append(f"""<section><div class="tag">CALIBRACAO</div><h2>Por que o limiar e {limiar}</h2>
<div class="grid"><div>{g_cal}</div><div>
<p>Avaliado sobre {calib['pares_avaliados']} demandas sem CNPJ valido, comparando com o cliente verdadeiro de cada uma
(pares rotulados). Limiar baixo demais aceita prospects parecidos com clientes (ex.: 'Moto Center Toledo' x
'Moto Center Cascavel'); alto demais perde apelidos legitimos (ex.: 'Frota Pampa').</p>
<p>Faixa com melhor F1: <b>{min(faixa)} a {max(faixa)}</b>. Usamos o maior limiar dessa faixa
(<b>{calib['limiar_recomendado']}</b>), o lado conservador.</p>
{_tabela(["Limiar", "Certos", "Errados", "Perdidos", "Precisao %", "Recall %", "F1 %"],
         [[p['limiar'], p['vinculos_corretos'], p['vinculos_errados'], p['perdidos'], p['precisao'], p['recall'], p['f1']] for p in curva], "compacta")}
</div></div></section>""")

    # 8. curadoria + amostra
    sem = [r for r in base if r["metodo_vinculo"] == "SEM_MATCH"]
    s.append(f"""<section><div class="tag">CURADORIA</div><h2>Demandas que precisam de revisao humana</h2>
{_tabela(["id_demanda", "canal", "nome informado", "candidato mais proximo", "score"],
         [[r['id_demanda'], r['canal'], r['cliente_nome_original'], r.get('candidato_mais_proximo'), r['score_vinculo']] for r in sem])}
<p class="nota">Provavelmente clientes novos (prospects): nenhum tem CNPJ cadastrado nem nome parecido o bastante.</p></section>""")
    cols = ["id_demanda", "canal", "cliente_id", "metodo_vinculo", "origem_cidade", "origem_uf",
            "destino_cidade", "destino_uf", "tipo_carga", "qtd_unidades", "peso_kg", "valor_frete",
            "data_coleta", "status"]
    s.append(f"""<section><div class="tag">BASE FINAL</div><h2>Base unificada ({n_base} registros)</h2>
<div class="scroll">{_tabela(cols, [[r[c] for c in cols] for r in base], "compacta")}</div></section>""")

    if ia:
        s.append(_secao_ia(ia, wa7_ia))

    # 9. limitacoes
    amb = sum(r["data_ambigua"] for r in base)
    s.append(f"""<section><div class="tag">LIMITACOES E PROXIMOS PASSOS</div><h2>O que ainda nao resolvemos</h2>
{_tabela(["#", "Limitacao", "Medido neste lote", "Proximo passo"], [
        [1, "Parser de texto livre", f"{mot.get('rota incompleta ou nao parseavel', 0)} descartes por rota, todos do WhatsApp",
         "Extracao por NER ou LLM validada contra o schema"],
        [2, "Limiar calibrado em base pequena", f"{calib['pares_avaliados']} pares rotulados, 8 clientes no CRM",
         "Curva de precisao e recall sobre centenas de pares rotulados"],
        [3, "Ambiguidade de data", f"{amb} datas do WhatsApp lidas como dd/mm e marcadas data_ambigua",
         "Campo de formato (locale) por canal, negociado com quem emite a fonte"],
        [4, "Sem carga incremental", "o lote inteiro e reprocessado a cada execucao",
         "Watermark e idempotencia por id_demanda"]])}</section>""")

    doc = f"""<!doctype html><html lang="pt-br"><head><meta charset="utf-8">
<title>BUG FREE - Relatorio do pipeline</title><style>{CSS}</style></head><body>
<header><div class="tag">PROJETO UNIVEL x RODOMAX · PARTE 2: PIPELINE EM FUNCIONAMENTO</div>
<h1>BUG FREE - HUB Integrador de Dados</h1>
<p>Relatorio gerado automaticamente pelo pipeline (python main.py)</p><div class="bar"></div>
<p>Data Science e Inteligencia Artificial · 4º Periodo · Prof. Lucas Soares da Silva</p>
<p><b>Alessandro L. Lorensi · Eduardo Reway · João G. Reis · Kauã Foscarini · Vinicius Soares</b></p></header>
<main>{''.join(s)}</main></body></html>"""
    caminho.write_text(doc, encoding="utf-8")
