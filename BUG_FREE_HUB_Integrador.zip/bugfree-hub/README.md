# BUG FREE - HUB Integrador de Dados (Parte 2: o pipeline funcionando)

Projeto UNIVEL x Rodomax · Data Science e Inteligência Artificial · 4º Período · Prof. Lucas Soares da Silva
Alessandro L. Lorensi · Eduardo Reway · João G. Reis · Kauã Foscarini · Vinicius Soares

Motor de normalização e saneamento de demandas de frete recebidas por cinco canais
heterogêneos, implementado em Python exatamente com a arquitetura da apresentação.

## Documentação

| Documento | Conteúdo |
|---|---|
| [docs/DOCUMENTACAO.md](docs/DOCUMENTACAO.md) | Documentação técnica completa: arquitetura, cada módulo explicado, IA, decisões e perguntas da arguição |
| [docs/W5HH.md](docs/W5HH.md) | W5HH: requisitos, as 8 etapas da proposta → código, equipe, ambiente, cronograma (Gantt), metodologia e viabilidade |
| `output/relatorio.html` | Relatório gerado pelo próprio pipeline, com gráficos (baixe e abra no navegador) |

## Como rodar

Requer Python 3.10+.

```
pip install -r requirements.txt
python main.py --abrir
```

`--abrir` abre o relatório no navegador ao final. `--gerar` recria os dados brutos de exemplo.
(Com `uv`: `uv sync` e depois `uv run python main.py --abrir`.)

> No Windows, se aparecer `DLL load failed ... muito grande`, a pasta do projeto está num
> caminho longo demais. Coloque-a num caminho curto (ex.: `C:\bugfree`).

## Etapa 2: IA, frete justo (regressão)

`python main.py` também treina e avalia o modelo (`bugfree/modelo_frete.py`, estágio 7):

| Modelo | MAE teste | R² teste |
|---|---|---|
| Linha de base (média) | R$ 2.787 | 0,20 |
| **Regressão linear** (escolhido) | **R$ 1.172** | **0,71** |
| Árvore de regressão (max_depth=4) | R$ 1.213 | 0,72 |

O alvo é o frete por veículo. Os atributos são distância (km), porte do veículo, distância × porte e
tipo de carga. A avaliação usa treino/teste 75/25 e validação cruzada 5-fold. Na tela, ao
**Exportar** uma demanda, o modelo mostra o frete justo, a faixa normal e se o valor informado está
fora da curva. Explicação completa em `docs/DOCUMENTACAO.md`, seção 7.

## Sistema de demandas (tela)

```
python tela.py
```

Abre `http://localhost:8000` no navegador, com três abas:

- **Nova demanda**: formulário (cliente, CNPJ, origem, destino, quantidade, tipo, peso, valor,
  data, status). Preencha do jeito que o dado chega e clique em **Exportar**. Aparece o antes e
  depois de cada campo e a regra aplicada: `8,3k` → `8300.00`, `9,1 t` → `9100.0 kg`,
  `04/25/2026` → `2026-04-25`, `Floripa/SC` → `Florianópolis / SC`, `cegonheira` → `CEGONHA`,
  `Frota Pampa` → `CLI007`. Se a demanda for inválida (rota incompleta, quantidade 0), ela aparece
  como DESCARTADA, com o motivo. O botão "Preencher exemplo" alterna 4 exemplos prontos.
- **Demandas exportadas**: as demandas válidas já normalizadas, com o botão **Baixar CSV**.
- **Mensagem de WhatsApp**: cole uma mensagem inteira e veja o parser, a limpeza e o CRM juntos.

A tela usa as mesmas funções do pipeline (`normalizacao.py`, `crm.py`, `parsers.py`).
Para sair, aperte Ctrl+C no terminal.

## A linha de produção em seis estágios

| # | Estágio | Arquivo | O que faz |
|---|---------|---------|-----------|
| 01 | Canais | `data/raw/` | 5 fontes brutas: WhatsApp (.txt), e-mail (.html), Portal/API (.jsonl), planilha legado (.csv latin-1), ordem de coleta (.pdf) |
| 02 | Leitores | `bugfree/parsers.py` | Extraem e mapeiam cada fonte para o schema bruto, sem limpar nada |
| 03 | Auditoria | `bugfree/auditoria.py` | Mede a bagunça antes de qualquer correção: cardinalidade, formatos, nulos, IDs repetidos |
| 04 | Limpeza | `bugfree/normalizacao.py` | Normaliza cidade/UF, valor, peso, data, tipo, status, CNPJ e descarta com motivo |
| 05 | CRM | `bugfree/crm.py` | Vincula ao cadastro: CNPJ (determinístico) → similaridade da razão social → curadoria |
| 06 | Base final | `output/` | Base unificada + relatórios de auditoria |

`bugfree/schema.py` é o único acoplamento entre as camadas: **parser não limpa; limpador não
parseia**. Um canal novo custa uma função em `parsers.py` e uma entrada em `LEITORES`.

## Resultado (o mesmo da apresentação)

```
FUNIL: 113 brutos -> 10 descartados -> 103 na base final -> 93 vinculados ao CRM
Aproveitamento: 91.2% (103/113)   Vinculo ao CRM: 90.3% (93/103)
```

| Auditoria (antes da limpeza) | Distintos | Reais |
|---|---|---|
| origem | 24 | 13 |
| destino | 14 | 8 |
| tipo_carga | 12 | 7 |
| status | 11 | 7 |

- Descartes: 6 rotas incompletas (todas do WhatsApp), 2 quantidades inválidas, 2 duplicatas técnicas
- Vínculo: 78 por CNPJ (75,7%) · 15 por razão social (14,6%) · 10 para curadoria (9,7%)

## Arquivos gerados em `output/`

| Arquivo | Conteúdo |
|---|---|
| `relatorio.html` | Relatório completo com gráficos, na mesma ordem dos slides |
| `base_final.csv` | 103 demandas normalizadas e vinculadas |
| `descartes.csv` | Cada registro excluído, com id, canal, motivo e valor bruto que causou a exclusão |
| `curadoria_crm.csv` | Demandas sem cliente encontrado, com o candidato mais próximo e o score |
| `calibracao_limiar.csv` | Precisão / recall / F1 para cada limiar de similaridade |
| `auditoria.json` | Todas as medidas da auditoria |

## Sobre os dados

Os arquivos em `data/raw/` são **dados sintéticos** criados por `gerar_dados.py` (semente fixa,
sempre os mesmos) para reproduzir o cenário da apresentação: as mesmas quantidades por canal e
os mesmos tipos de problema. Para rodar com dados reais, basta colocar os arquivos reais nas
pastas de `data/raw/` e rodar `python main.py`, sem `--gerar`.

`data/gabarito/vinculo_rotulado.csv` diz qual é o cliente verdadeiro de cada demanda. Ele é
usado **só** na calibração do limiar (`bugfree/calibracao.py`); o pipeline nunca o lê.

## Correções em relação à apresentação

1. **WA-0007**: no slide de descartes, ele aparecia como "rota incompleta", mas também era o
   exemplo de ingestão bem-sucedida. Aqui ele é processado com sucesso e os 6 descartes por rota
   são WA-0001, 0004, 0010, 0015, 0019 e 0023.
2. **91,2% x 90,3%**: 91,2% é o aproveitamento (103/113). O vínculo ao CRM é 93/103 = **90,3%**.
   O pipeline e o relatório mostram os dois separados.
3. **Gráfico de formatos**: agora mostra as 5 grafias do valor do frete, cada barra com seu nome.
4. **Gráfico de calibração**: os eixos têm nome (limiar x %) e mostram precisão e recall medidos
   em pares rotulados. O limiar 85 é o maior da faixa com melhor F1 (70 a 85), o lado
   conservador, porque vínculo errado é pior que vínculo ausente.
5. **Ambiguidade de data**: implementado o "locale por canal" sugerido em Limitações
   (`LOCALE_CANAL` em `bugfree/config.py`). Canais com formato fixo não geram ambiguidade; no
   WhatsApp, as datas em que dia e mês podem ser trocados recebem `data_ambigua = True`.
