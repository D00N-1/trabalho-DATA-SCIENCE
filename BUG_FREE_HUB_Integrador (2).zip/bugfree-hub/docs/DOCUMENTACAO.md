# Documentação técnica – BUG FREE · HUB Integrador de Dados

Projeto UNIVEL x Rodomax · Data Science e Inteligência Artificial · 4º Período · Prof. Lucas Soares da Silva
Alessandro L. Lorensi · Eduardo Reway · João G. Reis · Kauã Foscarini · Vinicius Soares

Este documento explica **o que o sistema faz, como o código está organizado e por que cada decisão
foi tomada**. Ele também serve de guia de estudo para a arguição: a seção 11 lista as perguntas
prováveis com respostas.

> A condução do projeto (W5HH: requisitos, cronograma, metodologia, viabilidade) e o mapa das
> **8 etapas de execução da proposta → código** estão em [W5HH.md](W5HH.md).

---

## Sumário
1. [Visão geral](#1-visão-geral)
2. [Como instalar e rodar](#2-como-instalar-e-rodar)
3. [Estrutura de pastas](#3-estrutura-de-pastas)
4. [Arquitetura: a linha de produção](#4-arquitetura-a-linha-de-produção)
5. [Os dados](#5-os-dados)
6. [Módulo por módulo](#6-módulo-por-módulo)
7. [A técnica de IA: frete justo](#7-a-técnica-de-ia-frete-justo)
8. [O sistema (tela.py)](#8-o-sistema-telapy)
9. [Arquivos de saída](#9-arquivos-de-saída)
10. [Decisões de projeto](#10-decisões-de-projeto)
11. [Perguntas prováveis na arguição](#11-perguntas-prováveis-na-arguição)
12. [Limitações e próximos passos](#12-limitações-e-próximos-passos)
13. [Glossário](#13-glossário)

---

## Resumo das técnicas de IA

| Pergunta da Rodomax | Técnica | Resultado principal | Na tela |
|---|---|---|---|
| Qual seria um frete justo? | Regressão linear (vs árvore, KNN e linha de base) | MAE R$ 1.172 vs R$ 2.787 (−58%) | Frete justo + veredito |
| Que tipos de demanda recebemos? | K-means | 6 perfis, silhueta 0,38 vs −0,10 aleatório | Perfil da demanda |
| Quais fogem do padrão? | DBSCAN | Achou 2 de 3 fretes fora da curva (IQR: 0) | "Foge do padrão" |
| Que casos parecidos já tivemos? | KNN (vizinhos mais próximos) | 3 demandas mais parecidas | Tabela de casos parecidos |
| Como extrair campos de mensagem livre? | Regex + dicionários + similaridade, com taxa de acerto | 83% por campo em mensagens novas (base: 5%) | Aba Mensagem de WhatsApp |

---

## 1. Visão geral

A Rodomax recebe pedidos de frete (demandas) por **cinco canais diferentes**, cada um escrevendo o
mesmo dado de um jeito:

| Canal | Formato | Registros |
|---|---|---|
| WhatsApp | texto livre ou template | 25 |
| E-mail | tabela HTML com cabeçalhos diferentes | 20 |
| Portal / API | webhook JSON (com reenvios) | 27 |
| Planilha legado | CSV latin-1, separador `;` | 29 |
| Ordem de coleta | PDF com tabela | 12 |

Hoje um operador lê tudo e digita numa planilha. O projeto tem duas partes:

- **1ª etapa – HUB (motor de normalização):** lê os 5 canais, mede a bagunça, limpa, descarta o que
  é inválido (sempre registrando o motivo), vincula cada demanda ao cadastro de clientes (CRM) e
  gera uma base única.
  Resultado: **113 brutos → 10 descartados → 103 na base final → 93 vinculados ao CRM.**
- **2ª etapa – IA:** com a base limpa, um modelo de **regressão** estima o **frete justo** de uma
  demanda e avisa quando o valor pedido está fora da curva.
  Resultado: **erro médio de R$ 1.172 por frete, contra R$ 2.787 da linha de base (58% menor).**

Tudo pode ser demonstrado num **sistema web local** (`tela.py`): você digita uma demanda do jeito
que ela chegou (ex.: valor "8,3k"), clica em **Exportar** e vê o dado normalizado ("8300.00") e o
frete justo estimado pela IA.

---

## 2. Como instalar e rodar

Requer Python 3.10 ou superior.

```bash
python -m pip install -r requirements.txt   # ou: uv sync
python main.py --abrir    # roda o pipeline completo + IA e abre o relatório
python tela.py            # abre o sistema em http://localhost:8000
```

| Comando | O que faz |
|---|---|
| `python main.py` | Roda os 7 estágios e grava tudo em `output/` |
| `python main.py --gerar` | Recria antes os dados brutos de exemplo (`data/raw/`) |
| `python main.py --abrir` | Abre o relatório HTML no navegador ao final |
| `python tela.py` | Sobe o sistema de demandas (Ctrl+C para sair) |
| `python gerar_dados.py` | Só recria os dados brutos |

> No Windows, se aparecer `DLL load failed ... muito grande`, a pasta está num caminho longo demais.
> Mova para um caminho curto (ex.: `C:\bugfree`).

---

## 3. Estrutura de pastas

```
bug free/
├── main.py                 # orquestra os 7 estágios (ponto de entrada do pipeline)
├── tela.py                 # servidor do sistema web (formulário, Exportar, WhatsApp)
├── gerar_dados.py          # gera os dados brutos sintéticos dos 5 canais + CRM + gabarito
├── requirements.txt        # dependências (pip)
├── pyproject.toml          # dependências (uv)
├── bugfree/                # o pacote com toda a lógica
│   ├── config.py           # caminhos e parâmetros (limiar, formato de data por canal)
│   ├── catalogos.py        # dicionários de referência: cidades, apelidos, tipos, status, coordenadas
│   ├── schema.py           # o schema único (contrato entre as camadas)
│   ├── parsers.py          # estágio 02: leitores dos 5 canais
│   ├── auditoria.py        # estágio 03: mede a bagunça antes de corrigir
│   ├── normalizacao.py     # estágio 04: limpeza e exclusão direcionada
│   ├── crm.py              # estágio 05: vínculo ao cadastro de clientes
│   ├── calibracao.py       # escolha do limiar de similaridade (precisão / recall)
│   ├── modelo_frete.py     # estágio 07: IA de frete justo (regressão linear, árvore, KNN)
│   ├── perfis.py           # estágio 08: perfis (K-means), anomalias (DBSCAN), casos parecidos (KNN)
│   ├── extracao.py         # estágio 09: taxa de acerto da extração de mensagens livres
│   ├── relatorio.py        # gera o relatório HTML com gráficos
│   └── tela.html           # interface do sistema
├── data/
│   ├── raw/                # estágio 01: as 5 fontes brutas
│   │   ├── whatsapp/conversa_comercial.txt
│   │   ├── email/email_01..06.html
│   │   ├── api/webhooks.jsonl
│   │   ├── csv/planilha_legado.csv
│   │   └── pdf/ordem_coleta_lote_01..03.pdf
│   ├── crm/clientes.csv    # cadastro com 8 clientes
│   └── gabarito/vinculo_rotulado.csv   # cliente verdadeiro de cada demanda (só para calibrar)
├── output/                 # estágio 06: resultados (recriados a cada execução)
└── docs/                   # documentação e textos do relatório
```

---

## 4. Arquitetura: a linha de produção

```
 01 Canais ──▶ 02 Leitores ──▶ 03 Auditoria ──▶ 04 Limpeza ──▶ 05 CRM ──▶ 06 Base final ──▶ 07 IA
 data/raw      parsers.py      auditoria.py     normalizacao.py crm.py     output/           modelo_frete.py
```

**Regra principal: "parser não limpa; limpador não parseia".**
- Os **leitores** só traduzem a *estrutura* de cada arquivo para o schema. O valor sai exatamente
  como veio: "8,3k" continua "8,3k".
- A **limpeza** recebe registros já no schema e não sabe se vieram de um PDF ou de um JSON.
- O **schema** (`schema.py`) é o único acoplamento entre as camadas.

**Consequência prática:** um canal novo custa só uma função em `parsers.py`. O canal PDF foi o último
a entrar e não exigiu nenhuma mudança na limpeza.

### Fluxo de um registro (exemplo real: WA-0007)

| Etapa | Estado do dado |
|---|---|
| Bruto (WhatsApp) | `oi, Frota Pampa aqui. preciso levar 7 carros de cascavel  pr pra Floripa/SC, coleta 04/25/2026, fecha em 8,3k?` |
| Depois do parser | `cliente_nome='Frota Pampa'`, `origem='cascavel  pr'`, `destino='Floripa/SC'`, `qtd='7'`, `veiculo='carros'`, `valor='8,3k'`, `data='04/25/2026'` |
| Depois da limpeza | `Cascavel/PR`, `Florianópolis/SC`, `7`, peso estimado `9100 kg`, `8300.00`, `2026-04-25`, status `NOVA` |
| Depois do CRM | `CLI007 – PAMPA GESTÃO DE FROTAS LTDA` (FUZZY, score 87,9) |
| IA | frete justo ≈ R$ 8.400–8.800 → informado R$ 8.300 → DENTRO DO ESPERADO |

---

## 5. Os dados

### 5.1 Dados brutos (sintéticos)
O grupo não tinha os arquivos reais da Rodomax. Por isso, `gerar_dados.py` cria um lote **sintético**
com **semente fixa** (`random.Random(2026)`): ele gera sempre os mesmos arquivos e reproduz
exatamente o cenário da apresentação (mesmas quantidades por canal, mesmos tipos de problema).

Problemas plantados de propósito, porque são os que a auditoria precisa encontrar:
- 24 grafias de origem para 13 cidades ("CASCAVEL - PR", "cascavel  pr", "Cascavel/PR", "cwb", "foz", "poa"...);
- 5 grafias de valor ("R$ 1.500,00", "1.500,00", "1500.00", "1500", "1,5k");
- peso em kg, em toneladas e sem unidade;
- CNPJ com máscara, só dígitos, truncado ("24.883.107"), oculto ("**.***.***/0001-**") ou ausente;
- datas em dd/mm/aaaa, ISO, "15-abr-2026" e mm/dd ("04/25/2026");
- 6 mensagens de WhatsApp sem destino, 2 quantidades inválidas e 2 reenvios da API;
- clientes que mandam apelido em vez da razão social ("Frota Pampa") e 10 clientes novos que não
  estão no CRM.

**Como o frete é gerado** (função `frete_real` em `gerar_dados.py`; o modelo de IA **não vê** essa fórmula):

```
frete por veículo = (250 + 1,3 × km) × fator do veículo × negociação
fator do veículo:  carro 1,0 · moto 0,35 · caminhonete 1,45
negociação:        aleatória entre 0,85 e 1,15; em ~5% dos casos × 0,5 ou × 1,9 (fora da curva)
```

Para usar dados reais, basta colocar os arquivos em `data/raw/` e rodar `python main.py`, sem `--gerar`.

### 5.2 CRM
`data/crm/clientes.csv`: 8 clientes (CLI001 a CLI008), com razão social e CNPJ válido (dígitos
verificadores corretos).

### 5.3 Gabarito
`data/gabarito/vinculo_rotulado.csv` diz qual é o cliente verdadeiro de cada demanda. É usado **só**
para calibrar o limiar de similaridade (`calibracao.py`). O pipeline nunca lê esse arquivo para
decidir um vínculo.

---

## 6. Módulo por módulo

### 6.1 `bugfree/config.py`: parâmetros
| Parâmetro | Valor | Para quê |
|---|---|---|
| `LIMIAR_FUZZY` | 85 | Score mínimo (0–100) para aceitar vínculo por nome |
| `LOCALE_CANAL` | dict | Formato de data de cada canal (`dmy`, `iso` ou `None` = sem formato garantido) |
| `STATUS_PADRAO` | `NOVA` | Status quando o canal não informa (WhatsApp) |

### 6.2 `bugfree/catalogos.py`: vocabulário controlado
- `chave(texto)`: forma de comparação. Tira acento, passa para minúsculas, tira pontuação e junta
  espaços. É usada em todo o projeto: `chave("São Paulo") == chave("SAO PAULO") == "sao paulo"`.
- `CIDADES`: as 18 cidades atendidas → (nome oficial, UF).
- `APELIDOS_CIDADE`: `cwb`→Curitiba, `floripa`→Florianópolis, `poa`→Porto Alegre, `sampa`→São Paulo, `bh`, `foz`.
- `TIPOS_CARGA` e `STATUS`: variações → valor canônico (`cegonheira`→`CEGONHA`, `aprovado`→`APROVADA`).
- `MAPA_COLUNAS`: cabeçalhos das fontes tabulares → campo do schema (`Saída`→`origem`, `Frete`→`valor_frete`).
- `COORDENADAS` e `distancia_km(a, b)`: latitude e longitude das cidades e distância estimada (para a IA).
- `PESO_PADRAO_VEICULO`: carro 1.300 kg, moto 180 kg, caminhonete 2.100 kg.

### 6.3 `bugfree/schema.py`: o contrato
- `CAMPOS_BRUTOS`: o que todo leitor entrega (`id_demanda, canal, cliente_nome, cnpj, origem, destino,
  tipo_carga, qtd_unidades, peso, valor_frete, data_coleta, status, veiculo`).
- `CAMPOS_FINAIS`: as colunas da base final.
- `registro_bruto(**campos)`: cria o registro e **rejeita campos fora do schema**, o que garante que
  nenhum leitor invente colunas.

### 6.4 `bugfree/parsers.py`: estágio 02, leitores
| Função | Canal | Como lê |
|---|---|---|
| `ler_whatsapp` | `.txt` exportado | Separa as mensagens pelo carimbo `dd/mm/aaaa hh:mm - Autor:`, junta as linhas de continuação, ignora as respostas do operador (só "Cliente") e decide entre template (`_template`) e texto livre (`_texto_livre`) |
| `ler_email` | `.html` | Parser de HTML da biblioteca padrão (`_Tabelas`) que coleta as tabelas. Só usa tabelas que têm coluna de ID (ignora a assinatura). Cabeçalhos diferentes são traduzidos pelo `MAPA_COLUNAS` |
| `ler_api` | `.jsonl` | Cada linha é um evento; navega no JSON aninhado (`payload.rota.origem`...) |
| `ler_csv` | `.csv` | Abre em **latin-1** com separador `;` |
| `ler_pdf` | `.pdf` | `pdfplumber.extract_tables()` e troca as quebras de linha dentro da célula por espaço |

`LEITORES` registra os 5 leitores; `ler_todos()` executa todos.

**Texto livre (WhatsApp):** expressões regulares, por exemplo:
- `RE_ROTA`: `<n> carros de <origem> pra <destino>` (ancorada na quantidade, para não confundir com o
  "de" de "Gestão **de** Frotas");
- `RE_QTD`: `<n> <carros|motos|caminhonetes>`, que também captura o tipo de veículo;
- `RE_VALOR`: `fecha em 8,3k` / `valor R$ 4.200`;
- `RE_DATA`: `coleta 04/25/2026`;
- `RE_NOME`: `oi, <nome> aqui.` / `aqui é da <nome>.`

Se a mensagem não tem destino, o parser preenche só a origem. A limpeza depois descarta a demanda
como "rota incompleta".

### 6.5 `bugfree/auditoria.py`: estágio 03, medir antes de corrigir
`auditar(por_canal, obsoletas)` devolve:
- **estatística descritiva** (`estatisticas`): n, média, desvio padrão, mínimo, Q1, mediana, Q3,
  máximo e outliers pelo critério de Tukey (fora de Q1 − 1,5×IQR e Q3 + 1,5×IQR) para o valor do
  frete, o frete por veículo, o peso e a quantidade. Os valores são convertidos só para medir;
- **colunas obsoletas** (`colunas_obsoletas`): cada coluna da fonte que não pertence ao schema é
  registrada pelo leitor (`parsers._registrar_obsoleta`) e justificada com evidência medida
  ("100% vazia", "valor constante", % preenchida) e com o motivo de negócio (`MOTIVO_OBSOLETA`).
  São 11 colunas, por exemplo `DIGITADO_POR` (dado pessoal), `COL_AUX` (vazia), `tentativa` (controle
  técnico) e `Contato` (telefone, LGPD);
- **cardinalidade:** valores distintos encontrados × valores reais (origem 24×13, destino 14×8,
  tipo 12×7, status 11×7). O "real" é obtido aplicando o dicionário de referência às grafias;
- **formatos:** distribuição das grafias de valor, peso, CNPJ e data (`formato_valor`, `formato_peso`,
  `formato_cnpj`, `formato_data`);
- **IDs repetidos** (os reenvios da API) e **nulos por campo**.

### 6.6 `bugfree/normalizacao.py`: estágio 04, limpeza
| Função | Entrada → saída | Regra |
|---|---|---|
| `normalizar_local` | `CASCAVEL - PR`, `cascavel  pr`, `Floripa/SC`, `cwb` → (`Cascavel`,`PR`) | Apelido → catálogo → separa cidade/UF → aproximação para erro de digitação (`rapidfuzz`, ≥ 88). Rejeita UF que não combina com a cidade |
| `normalizar_valor` | `R$ 1.500,00`, `1.500,00`, `1500`, `1500.0`, `8,3k` → `1500.0` / `8300.0` | Tira "R$"; "k" = ×1000; vírgula = decimal BR; `1.500` com 3 dígitos após o ponto = milhar |
| `normalizar_peso` | `12 t`, `12.000 kg`, `12000` → `12000.0` | "t" = ×1000; sem unidade = kg |
| `normalizar_data` | `2026-04-15`, `15-abr-2026`, `04/25/2026`, `05/04/2026` → ISO + `ambigua?` | Número >12 define dia e mês; senão usa o formato do canal; no WhatsApp marca `data_ambigua=True` |
| `normalizar_tipo` / `normalizar_status` | `cegonheira` → `CEGONHA` | Vocabulário controlado; o que está fora vira nulo |
| `normalizar_cnpj` + `cnpj_valido` | `24.883.107/0001-93` → `24883107000193` | Só aceita 14 dígitos com os **dois dígitos verificadores** corretos. Truncado ou oculto vira nulo |
| `estimar_peso` | `veiculo='carros'`, qtd 7 → 9100 kg | Peso típico × quantidade, quando o peso não veio (`peso_estimado=True`) |
| `normalizar_registro` | registro bruto → (limpo, motivo) | Aplica tudo e decide o descarte |
| `executar` | lista de brutos → (base, descartes) | Duplicata técnica → rota incompleta → quantidade inválida. **Todo descarte vai para a lista com id, canal, motivo e o valor que causou** |

**Por que CNPJ truncado vira nulo:** um CNPJ parcial poderia casar com o cliente errado. Vínculo
errado contamina o faturamento; vínculo ausente só gera trabalho de revisão.

### 6.7 `bugfree/crm.py`: estágio 05, vínculo ao cadastro
Ordem de decisão em `vincular()`:
1. **CNPJ válido encontrado no cadastro** → `CNPJ` (determinístico, score 100). 78 demandas.
2. Senão, **similaridade da razão social** ≥ 85 → `FUZZY`. 15 demandas.
3. Senão → `SEM_MATCH`, que vai para `curadoria_crm.csv` com o candidato mais próximo. 10 demandas.

Como a similaridade funciona:
- `nome_chave()`: "PAMPA GESTÃO DE FROTAS LTDA" → "pampa gestao frota" (sem sufixo societário,
  sem preposição, sem plural simples);
- `similaridade(a, b) = max( média(token_set_ratio, token_sort_ratio), ratio sem espaços )`;
  - o `token_set` aceita um nome contido no outro ("frota pampa" ⊂ "pampa gestao frota");
  - o `token_sort` penaliza quando sobra muita coisa, porque só o token_set aceitaria "Pampa" = qualquer coisa com "Pampa";
  - a comparação sem espaços resolve nomes colados ("MotoCenter" = "Moto Center").

### 6.8 `bugfree/calibracao.py`: por que o limiar é 85
Para cada limiar de 50 a 100, compara o vínculo previsto com o gabarito e calcula:
- **precisão** = vínculos certos / vínculos feitos;
- **recall** = clientes encontrados / clientes que existiam;
- **F1** = média harmônica das duas.

A faixa com melhor F1 foi de 70 a 85. Usamos **o maior limiar da faixa (85)**, o lado conservador,
pelo mesmo motivo do CNPJ: errar o cliente é pior que não achar.

### 6.9 `bugfree/modelo_frete.py`: estágio 07, IA
Explicado em detalhe na seção 7.

### 6.10 `bugfree/relatorio.py`: relatório HTML
Gera `output/relatorio.html`, um arquivo único com os gráficos embutidos (matplotlib → PNG em base64),
seguindo a ordem dos slides: problema, diagnóstico, ingestão, normalização, descartes, resultado,
calibração, curadoria, base final, IA e limitações. Os exemplos de transformação são **buscados
nos dados reais**, não escritos à mão.

### 6.11 `main.py`: orquestração
Executa os 7 estágios em ordem, imprime o resumo de cada um no terminal e grava as saídas. Se
`data/raw/` não existir, gera os dados antes.

---

## 7. A técnica de IA: frete justo

### 7.1 Problema
**Pergunta:** "qual seria um frete justo para esta rota e esta carga?"
**Quem usa:** o operador comercial, ao cotar ou aceitar uma demanda.
**Benefício:** padroniza a cotação (hoje depende da experiência de cada operador) e pega erros de
digitação ou valores fora da curva antes de fechar o frete.

### 7.2 Por que regressão
O alvo é um **número contínuo** (R$), então a escolha natural é a regressão. As outras trilhas foram
descartadas: a classificação ("vai ser atendida?") precisaria de um histórico de atendimento que não
existe na base; a de linguagem natural dependeria de internet (LLM) ou de um modelo que não entende
gírias ("cwb").

### 7.3 Alvo e atributos
- **Alvo:** frete **por veículo** = `valor_frete / qtd_unidades`. O frete total estimado é a
  previsão × quantidade. Isso evita que o modelo só aprenda que "mais veículos = mais caro".
- **Atributos** (`atributos()`):

| Atributo | Como é calculado | Por quê |
|---|---|---|
| `distancia_km` | Haversine entre as cidades × 1,25 | Frete cresce com a distância. Só existe porque o HUB padronizou as cidades |
| `peso_por_veiculo` | `peso_kg / qtd` (mediana se faltar) | Diferencia moto, carro e caminhonete |
| `km_x_porte` | `distancia × peso_por_veiculo / 1000` | Interação: o custo por km cresce com o porte |
| `peso_informado` | 1 se tinha peso, 0 se foi imputado | O modelo pode compensar a imputação |
| `tipo_<X>` | One-hot das 7 categorias | Equipamentos diferentes podem ter preços diferentes |

**Haversine:** fórmula da distância entre dois pontos na superfície da Terra a partir da latitude e
longitude. O fator 1,25 aproxima o quanto a estrada é mais longa que a linha reta.

### 7.4 Modelos comparados
| Modelo | Ideia |
|---|---|
| **Linha de base** (`LinhaDeBase`) | Sempre prevê a média do frete por veículo do treino. Serve de régua: se o modelo não bater isso, não serve |
| **Regressão linear** | `frete = b0 + b1·km + b2·peso + b3·km×porte + ...`. Cada coeficiente é "quanto soma" |
| **Árvore de regressão** | Divide os dados em perguntas ("km > 800?", "peso < 500?") e prevê a média de cada folha |

**Parâmetros:**
- Árvore: `max_depth` testado em {2, 3, 4, 5, 6, 8} por validação cruzada 5-fold **só no treino**; o
  melhor foi 4. `min_samples_leaf=3` evita folhas com um único caso (overfitting).
- `random_state=42` em tudo, para o resultado ser reprodutível.

### 7.5 Avaliação
- **Treino/teste 75/25:** 77 demandas para treinar e 26 nunca vistas para testar.
- **Validação cruzada 5-fold:** confirma que o resultado não depende de uma divisão específica.
- **Métricas** sobre o frete total:
  - **MAE** (erro absoluto médio, em R$): "em média o modelo erra R$ X". Fácil para o operador entender;
  - **R²**: quanto da variação do frete o modelo explica (0 = nada, 1 = tudo);
  - **erro percentual médio** (MAPE), como complemento.

| Modelo | MAE teste | R² teste | MAE cv5 | R² cv5 |
|---|---|---|---|---|
| Linha de base | R$ 2.787 | 0,20 | R$ 2.945 | 0,27 |
| **Regressão linear** | **R$ 1.172** | **0,71** | **R$ 1.011** | **0,78** |
| Árvore (depth 4) | R$ 1.213 | 0,72 | R$ 1.118 | 0,79 |

**Escolhido:** regressão linear, que tem o menor MAE no teste e é mais fácil de explicar.
**Interpretação:** cada km soma ≈ R$ 0,32 por veículo, mais ≈ R$ 0,68 por km a cada tonelada de porte.

### 7.6 Faixa normal e veredito
Usando previsões de validação cruzada, calcula-se o desvio percentual entre o real e o previsto em
cada demanda. Os percentis 5 e 95 desses desvios formam a **faixa normal** (≈ −47% a +45%). Numa
demanda nova:
- desvio abaixo do percentil 5 → **ABAIXO DA CURVA**;
- desvio acima do percentil 95 → **ACIMA DA CURVA**;
- senão → **DENTRO DO ESPERADO**.

### 7.7 Uso (função `prever`)
`prever(artefato, demanda_normalizada)` → frete justo, faixa mínima e máxima, distância, R$ por
veículo, diferença % para o valor informado e veredito. O modelo treinado fica salvo em
`output/modelo_frete.pkl` (pickle) e é carregado pela tela.

### 7.8 Acertos e erros típicos
- **Acertos** (erro < 3%): rotas com peso informado, como API-0003, Porto Alegre → Rio, R$ 14.900 real
  e R$ 15.064 previsto.
- **Erros grandes:** (a) templates do WhatsApp **sem peso nem tipo de veículo**, em que o porte foi
  imputado como carro mas eram motos (WA-0014, +240%); (b) fretes **realmente fora da curva**
  (CSV-0006, metade do normal). Nesse segundo caso, o "erro" é o alerta funcionando.

### 7.9 KNN também testado para o frete
Um quarto modelo, **KNN regressor** (`KNeighborsRegressor`, atributos padronizados, peso pela
distância), entrou na comparação. O número de vizinhos foi escolhido por validação cruzada no treino
(3, 5, 7 ou 9; o melhor foi 9). Resultado no teste: MAE **R$ 1.500**, R² 0,72. É melhor que a linha de
base, mas pior que a regressão linear (R$ 1.172), que continua a escolhida. Com só 103 demandas, há
poucos vizinhos realmente parecidos para cada caso.

---

## 7B. IA 2: perfis de demanda e anomalias (`bugfree/perfis.py`)

**Pergunta:** "que tipos de demanda recebemos e quais fogem do padrão?"
**Quem usa:** o planejamento (os perfis mostram que frota priorizar) e o comercial (uma anomalia
indica conferir a demanda antes de aceitar).

### K-means: perfis
- **Atributos:** distância (km), peso por veículo (porte) e quantidade (tamanho do lote),
  padronizados com `StandardScaler`, porque o K-means usa distância e o km dominaria sem escala.
- **Escolha do k:** testamos k de 2 a 6 e escolhemos pela **silhueta** (de −1 a 1; mede o quanto cada
  ponto está mais perto do próprio grupo que do vizinho).
- **Linha de base:** a silhueta de uma divisão **aleatória** com o mesmo k (média de 20 sorteios).
- **Resultado:** k = 6, silhueta **0,38**, contra **−0,10** da divisão aleatória. Cada perfil recebe um
  nome pelo centro do grupo:

| Perfil | Demandas | Frete médio por veículo |
|---|---|---|
| Carros · média distância · lote grande | 34 | R$ 1.064 |
| Motos · média distância · lote grande | 19 | R$ 417 |
| Carros · longa distância · lote pequeno | 16 | R$ 1.411 |
| Motos · média distância · lote médio | 14 | R$ 384 |
| Motos · longa distância · lote médio | 10 | R$ 626 |
| Carros · longa distância · lote grande | 10 | R$ 2.064 |

### DBSCAN: anomalias
- **Atributos:** log da distância, log do peso por veículo e log do frete por veículo, padronizados.
  O log deixa a escala relativa: metade ou o dobro do preço pesam igual.
- **Parâmetros:** `min_samples=3`; `eps` = percentil 90 da distância até o 3º vizinho (método da
  curva k-distância). Testamos os percentis 90, 95 e 98 com min_samples 3, 4 e 5 e ficamos com o que
  achava mais fretes fora da curva marcando menos demandas.
- **Avaliação** contra o gabarito dos fretes plantados fora da curva (`frete_fora_da_curva` em
  `vinculo_rotulado.csv`):

| Método | Marcadas | Achou | Precisão | Recall |
|---|---|---|---|---|
| **DBSCAN** | 9 | 2 de 3 | 22% | 67% |
| Linha de base: regra IQR só no preço | 1 | 0 de 3 | 0% | 0% |

- **Leitura crítica:** o DBSCAN encontra o que é **incomum**, não necessariamente **errado**. Das 9
  marcações, 2 são fretes plantados fora da curva; as outras são rotas raras (Joinville → Curitiba,
  133 km; Porto Alegre → BH, 1.678 km) ou o template sem tipo de veículo. Para "preço errado", o
  alerta da regressão (frete justo) é mais preciso. O DBSCAN serve para "demanda atípica, vale conferir".
- **Para uma demanda nova** (`analisar`), não existe `predict` no DBSCAN. Usamos a regra do próprio
  algoritmo: se a demanda está a mais de `eps` de todos os pontos-núcleo, ela foge do padrão.

### KNN: casos parecidos
`NearestNeighbors` (k = 3) sobre distância e porte padronizados. Para cada demanda nova, mostra as 3
demandas do histórico mais parecidas, com rota, quantidade e frete por veículo. É uma referência
concreta para o operador ("cobramos R$ 300 por moto nessa rota").

---

## 7C. IA 3: taxa de acerto da extração (`bugfree/extracao.py`)

**Pergunta:** "como extrair automaticamente origem, destino, quantidade, valor, prazo e cliente de uma
mensagem livre?"

- **Extrator avaliado:** expressões regulares (`parsers.py`) + normalização (catálogo de cidades,
  apelidos, aproximação) + vínculo ao CRM por similaridade.
- **Gabarito:** o que cada mensagem realmente diz (`data/gabarito/whatsapp_campos.csv`, gerado junto
  com os dados) e **10 mensagens novas escritas à mão em formatos diferentes**
  (`data/gabarito/mensagens_teste.csv`), para medir a generalização.
- **Linha de base:** ler só mensagens no formato de template ("Campo: valor").
- **Métrica:** % de acerto por campo e % de mensagens com todos os campos corretos.

| Conjunto | Acerto médio por campo | Mensagem 100% correta |
|---|---|---|
| Lote (25 mensagens) | 100% | 100% |
| Lote: linha de base | 46% | 32% |
| **Mensagens novas (10)** | **83%** | **50%** |
| Novas: linha de base | 5% | 0% |

- **Leitura crítica:** 100% no lote é otimista, porque as regras foram escritas conhecendo aqueles
  formatos. Nas mensagens novas, os erros mostram os limites da regex: "até" em vez de "pra", "de X a Y",
  "em X indo para Y", e saudações diferentes ("Olá", "sou da"). **Próximo passo:** um modelo de
  linguagem (NER ou LLM) validado contra o schema e medido com este mesmo gabarito.

---

## 8. O sistema (`tela.py`)

Um servidor HTTP da biblioteca padrão (`http.server`), sem framework, que serve `bugfree/tela.html`
e responde com JSON. **A tela não tem regra própria: chama as mesmas funções do pipeline.** Os
gráficos são desenhados em SVG pelo próprio navegador, sem bibliotecas externas, e por isso
funcionam sem internet.

| Aba | O que faz | Rota / função no servidor |
|---|---|---|
| **Painel** | Indicadores do HUB e da IA, cartões "como a IA ajuda" e gráficos: canais, funil, erro de cada modelo de frete, acerto da extração, perfis e anomalias, cardinalidade e vínculo ao CRM | `GET /api/painel` → `painel()` (lê os arquivos de `output/`) |
| **Nova demanda** | Formulário (com sugestões de cidades, clientes e tipos) → **Exportar** (ou Ctrl+Enter) → aceita ou descartada, frete justo (regressão), perfil (K-means), padrão (DBSCAN), 3 casos parecidos (KNN) e o antes e depois de cada campo | `POST {campo:"demanda"}` → `demanda()` |
| **Simulador de frete** | Rota, veículo, quantidade, tipo e valor proposto → a estimativa muda na hora, com medidor da faixa normal, veredito, perfil, padrão e casos parecidos. Tem cenários prontos e o botão "Criar demanda com esta simulação" | `POST {campo:"simular"}` → `simular()` |
| **Mensagem WhatsApp** | Cola a mensagem inteira → parser + limpeza + CRM; botão "Usar no formulário" leva os campos extraídos para a Nova demanda | `POST {campo:"mensagem"}` → `mensagem()` |
| **Base do HUB** | As 103 demandas da base final com busca, filtros (canal, vínculo, perfil, "só os que fogem do padrão") e ordenação por coluna | `GET /api/base` |
| **Exportadas** | Demandas válidas cadastradas na tela (guardadas no navegador, `localStorage`), com excluir item e **Baixar CSV** | (só no navegador) |

O botão **A+ Apresentação** aumenta o texto para o projetor, e a escolha fica salva no navegador.

Cada campo tem uma função que devolve `{saida, regra, ok, extra}` (`valor`, `peso`, `data`, `local`,
`tipo`, `status`, `cnpj`, `cliente`, `qtd`, `veiculo`), e é isso que aparece na coluna "Regra aplicada".

Detalhe técnico: no Windows, dois servidores podiam abrir a mesma porta ao mesmo tempo. Por isso o
código desliga o `allow_reuse_address`; se a porta 8000 estiver ocupada, ele só abre o navegador.

---

## 9. Arquivos de saída (`output/`)

| Arquivo | Conteúdo |
|---|---|
| `base_final.csv` | As 103 demandas normalizadas e vinculadas (separador `,`, UTF-8 com BOM para abrir no Excel) |
| `descartes.csv` | Os 10 excluídos, com id, canal, motivo e valor bruto que causou a exclusão |
| `curadoria_crm.csv` | Os 10 sem cliente encontrado, com o candidato mais próximo e o score |
| `calibracao_limiar.csv` | Precisão, recall e F1 por limiar |
| `auditoria.json` | Todas as medidas da auditoria |
| `modelo_frete.pkl` | Modelo de IA treinado |
| `ia_avaliacao.json` | Métricas, busca de profundidade, coeficientes, faixa normal |
| `ia_previsoes_teste.csv` | Previsão × real de cada demanda do teste |
| `perfis.pkl` | K-means, DBSCAN e KNN treinados (usados pela tela) |
| `ia_perfis.json` | Silhueta por k, perfis, anomalias e avaliação contra o gabarito |
| `ia_extracao.json` | Taxa de acerto da extração por campo e lista de erros |
| `relatorio.html` | Relatório completo com gráficos |

---

## 10. Decisões de projeto

| Decisão | Motivo |
|---|---|
| Separar parser e limpeza pelo schema | Canal novo = uma função; mudança de regra não mexe nos leitores |
| Nenhum descarte silencioso | A pergunta "por que essa demanda não está na programação?" sempre tem resposta |
| CNPJ truncado vira nulo, limiar conservador | Vínculo errado é pior que vínculo ausente |
| Formato de data por canal | Resolve a ambiguidade de 05/04 onde o canal tem formato fixo; no WhatsApp, marca a data |
| Dados sintéticos com semente fixa | Reprodutível: todo integrante obtém os mesmos números |
| Prever frete por veículo, não total | Remove o efeito trivial da quantidade |
| Atributo km × porte | O custo por km depende do porte; a regressão linear sozinha não enxerga a interação |
| Escolher pelo MAE | Erro em reais é o que importa ao operador |
| Sem framework web | Menos dependências; roda em qualquer máquina com Python |
| Gabarito só na calibração | Evita "colar a resposta" no pipeline |

---

## 11. Perguntas prováveis na arguição

**1. Por que regressão e não classificação?**
O alvo é um valor em reais (contínuo). Classificar "vai ser atendida" exigiria um histórico de
atendimento que não temos.

**2. O que é a linha de base e por que ela importa?**
É prever sempre a média. Se o modelo não erra menos que isso, ele não agrega nada. O nosso erra 58% menos.

**3. O que significa MAE de R$ 1.172?**
Em média, a previsão do frete total erra R$ 1.172 para mais ou para menos, nas demandas de teste,
que o modelo nunca viu.

**4. O que é R² = 0,71?**
O modelo explica cerca de 71% da variação do frete entre as demandas. O resto é negociação, ruído e
o que não está nos atributos.

**5. Por que separar treino e teste? E a validação cruzada?**
Para medir em dados que o modelo não viu, ou seja, para detectar overfitting. Com só 103 demandas,
uma única divisão pode dar sorte ou azar. A validação cruzada em 5 partes testa cada demanda uma
vez e confirma o resultado.

**6. Como foi escolhida a profundidade da árvore?**
Por validação cruzada 5-fold só no conjunto de treino, testando 2 a 8. O teste não foi usado para
escolher, para não contaminar a avaliação.

**7. Por que a linear ganhou da árvore?**
Com o atributo km × porte, a relação ficou quase linear. A árvore divide em faixas e perde precisão
com poucos dados por folha.

**8. De onde vem a distância?**
Da fórmula de haversine entre as coordenadas das cidades, × 1,25 de fator rodoviário. Só é possível
porque a limpeza transforma "floripa", "FLORIANOPOLIS - SC" e "Florianópolis/SC" na mesma cidade.

**9. E quando falta o peso?**
Se a mensagem diz o tipo ("7 carros"), estimamos o peso pelo peso típico × quantidade. Se não diz
nada, usamos a mediana e marcamos `peso_informado=0`. Essa é a maior fonte de erro do modelo.

**10. Como o sistema decide "fora da curva"?**
Compara o valor informado com o frete justo. Se o desvio sai da faixa entre os percentis 5 e 95 dos
erros do modelo (medidos por validação cruzada), avisa.

**11. Os dados são reais?**
Não. São sintéticos, gerados com semente fixa para reproduzir o cenário da Rodomax. O pipeline lê
arquivos reais do mesmo jeito: basta trocar a pasta `data/raw/`.

**12. E a LGPD?**
O modelo não usa nome nem CNPJ como atributo, só rota, porte e tipo de carga. A base tem dados de
empresas (CNPJ) e as mensagens podem ter dados pessoais (nome, telefone). Em produção: acesso
restrito, retenção limitada das mensagens brutas, mascarar o telefone e base legal de execução de
contrato.

**13. Como "Frota Pampa" vira CLI007?**
Não tem CNPJ, então vai para a similaridade de nomes: "frota pampa" × "pampa gestao frota" dá
score 87,9, que é ≥ 85.

**14. Por que o limiar é 85?**
A curva de precisão e recall no gabarito mostrou F1 máximo entre 70 e 85. Escolhemos o maior da
faixa porque vínculo errado é pior que vínculo ausente.

**15. Por que "04/25/2026" é lido como mês/dia?**
Porque 25 não pode ser mês. Quando os dois números são ≤ 12 (05/04), usamos o formato do canal; no
WhatsApp, que não tem formato garantido, a data é marcada como ambígua.

**16. Como adicionar um canal novo?**
Escrever uma função `ler_<canal>(raw)` que devolve `registro_bruto(...)` e registrá-la em `LEITORES`.
Nada mais muda.

**17. Quantas técnicas de IA o protótipo usa?**
Quatro, cada uma respondendo a uma pergunta da Rodomax: regressão (frete justo), K-means (perfis de
demanda), DBSCAN (o que foge do padrão) e KNN (casos parecidos; também testado como modelo de frete).
Além disso, medimos a taxa de acerto da extração de mensagens livres.

**18. O que é silhueta e por que 0,38 é bom?**
Mede se cada demanda está mais perto do próprio grupo que do grupo vizinho (de −1 a 1). Uma divisão
aleatória dá −0,10; o K-means dá 0,38, ou seja, os grupos têm estrutura real, embora não sejam
totalmente separados (é comum com dados reais e misturados).

**19. Por que o DBSCAN tem precisão de só 22%?**
Porque ele marca o que é incomum, e nem tudo que é incomum está errado: rotas muito curtas ou muito
longas também ficam isoladas. Mesmo assim, achou 2 dos 3 fretes plantados fora da curva, e a regra
simples (IQR) não achou nenhum. Para preço errado, o alerta da regressão é melhor.

**20. A extração acerta 100%?**
No lote, sim, mas isso é otimista: as regras foram escritas conhecendo aqueles formatos. Em 10
mensagens novas, escritas de outro jeito, o acerto foi 83% por campo. Os erros vêm de conectivos e
saudações que a regex não conhece, e o próximo passo é um modelo de linguagem.

---

## 12. Limitações e próximos passos

| Limitação | Próximo passo |
|---|---|
| Dados sintéticos, só 103 demandas | Retreinar com o histórico real da Rodomax |
| Distância estimada (linha reta × 1,25) | API de rotas (OSRM, Google Maps) com o km real |
| Porte imputado nas mensagens sem tipo de veículo | Template do WhatsApp pedir o tipo; extração por linguagem natural (NER ou LLM) |
| Faixa normal larga (−47% a +45%) | Estreita com mais dados e menos imputação |
| Parser de texto livre por regex | NER ou LLM validado contra o schema |
| Limiar calibrado com 8 clientes | Curva de precisão e recall com centenas de pares rotulados |
| Lote reprocessado inteiro | Carga incremental com watermark e idempotência por `id_demanda` |
| Modelo sugere, não decide | Operador tem a palavra final; monitorar o MAE em produção e retreinar periodicamente |

---

## 13. Glossário

| Termo | Significado |
|---|---|
| **Schema** | Lista fixa de campos que todas as camadas usam |
| **Normalização** | Transformar grafias diferentes no mesmo formato padrão |
| **Cardinalidade** | Quantidade de valores distintos numa coluna |
| **Vocabulário controlado** | Lista fechada de valores aceitos (ex.: 7 status) |
| **Fuzzy matching** | Comparação aproximada de textos (tolera diferenças) |
| **Precisão / Recall / F1** | Acerto dos vínculos feitos / cobertura dos vínculos possíveis / média harmônica das duas |
| **Regressão** | Modelo que prevê um número contínuo |
| **Linha de base** | Referência simples para comparar o modelo |
| **MAE** | Erro absoluto médio |
| **R²** | Proporção da variação explicada pelo modelo |
| **Validação cruzada (k-fold)** | Divide os dados em k partes e testa em cada uma |
| **Overfitting** | Modelo que decora o treino e erra em dados novos |
| **One-hot** | Uma coluna 0/1 para cada categoria |
| **Imputação** | Preencher um valor ausente com uma estimativa (ex.: mediana) |
| **Haversine** | Fórmula da distância entre dois pontos do globo |
| **Semente (seed)** | Número que torna o sorteio aleatório reprodutível |
