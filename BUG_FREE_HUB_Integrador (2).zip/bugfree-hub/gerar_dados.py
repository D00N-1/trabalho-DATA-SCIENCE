"""Gera o lote de dados brutos dos cinco canais (dados sinteticos, semente fixa).

Reproduz o cenario descrito na apresentacao: 113 demandas brutas espalhadas
por WhatsApp (25), e-mail (20), Portal/API (27), planilha legado (29) e
ordens de coleta em PDF (12), cada canal escrevendo o mesmo dado de um jeito.

Tambem gera:
  data/crm/clientes.csv              cadastro de clientes (8 clientes)
  data/gabarito/vinculo_rotulado.csv  cliente verdadeiro de cada demanda
                                       (pares rotulados para calibrar o limiar)

Uso:  python gerar_dados.py
"""
import csv
import json
import random
import shutil
from datetime import date, datetime, timedelta
from pathlib import Path

from fpdf import FPDF

from bugfree.catalogos import distancia_km
from bugfree.normalizacao import normalizar_local

RAIZ = Path(__file__).resolve().parent / "data"
rng = random.Random(2026)

# --------------------------------------------------------------------------
# CNPJ
# --------------------------------------------------------------------------

def _dv(digitos):
    pesos = [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2][-len(digitos):]
    r = sum(int(d) * p for d, p in zip(digitos, pesos)) % 11
    return "0" if r < 2 else str(11 - r)


def cnpj_valido(raiz8: str) -> str:
    base = raiz8 + "0001"
    d1 = _dv(base)
    d2 = _dv(base + d1)
    return base + d1 + d2


def mascara(c: str) -> str:
    return f"{c[:2]}.{c[2:5]}.{c[5:8]}/{c[8:12]}-{c[12:]}"


# --------------------------------------------------------------------------
# Cadastro (CRM) e prospects (clientes que ainda nao estao no CRM)
# --------------------------------------------------------------------------

CRM = [
    ("CLI001", "TRANSLOG AUTOMOTIVA LTDA", "11222333", "Curitiba", "PR"),
    ("CLI002", "AGRO SUL VEICULOS S.A.", "07345981", "Toledo", "PR"),
    ("CLI003", "CONCESSIONARIA PARANA MOTORS LTDA", "33190774", "Cascavel", "PR"),
    ("CLI004", "LOCADORA VIA BRASIL LTDA", "45120639", "São Paulo", "SP"),
    ("CLI005", "OESTE MAQUINAS AGRICOLAS LTDA", "18765302", "Chapecó", "SC"),
    ("CLI006", "MOTO CENTER CASCAVEL LTDA", "29871455", "Cascavel", "PR"),
    ("CLI007", "PAMPA GESTÃO DE FROTAS LTDA", "24883107", "Porto Alegre", "RS"),
    ("CLI008", "RENTCAR LOCACOES S.A.", "52036618", "Curitiba", "PR"),
]
CNPJ_CRM = {cid: cnpj_valido(r) for cid, _, r, _, _ in CRM}
NOME_CRM = {cid: nome for cid, nome, *_ in CRM}

# Como cada cliente costuma se identificar quando NAO manda CNPJ
APELIDOS = [
    ("CLI007", "Frota Pampa"),
    ("CLI001", "Translog Automotiva"),
    ("CLI002", "Agro Sul Veículos"),
    ("CLI003", "Concessionária Paraná Motors"),
    ("CLI004", "Locadora Via Brasil"),
    ("CLI005", "Oeste Máquinas Agrícolas"),
    ("CLI006", "Moto Center Cascavel"),
    ("CLI008", "RentCar Locações"),
    ("CLI007", "Pampa Frotas"),
    ("CLI001", "Translog Automotivo"),
    ("CLI002", "AgroSul Veiculos"),
    ("CLI003", "Parana Motors Concessionaria"),
    ("CLI004", "Via Brasil Locadora"),
    ("CLI005", "Oeste Maquinas"),
    ("CLI006", "MotoCenter Cascavel"),
    ("CLI008", "Rentcar Locacoes SA"),
]

PROSPECTS = [  # (nome, raiz do CNPJ ou None)
    ("Transportes Irmãos Bertoldi", None),
    ("Auto Peças Zanella", "61402288"),
    ("Agropecuária Três Marias", None),
    ("Iguaçu Seminovos", "38554120"),
    ("Moto Center Toledo", None),
    ("Via Sul Locações", "70119345"),
    ("Zanetti Implementos", "44012876"),
    ("Grupo Fronteira Veículos", "57730291"),
    ("Coopervale Cooperativa", None),
    ("Andrade & Filhos Transportes", "65218840"),
]

# --------------------------------------------------------------------------
# Grafias de cidade por canal: (texto bruto, cidade verdadeira)
# --------------------------------------------------------------------------

ORIG = {
    "whatsapp": [("cascavel  pr", "cascavel"), ("cwb", "curitiba"), ("foz", "foz"),
                 ("poa", "poa"), ("Toledo/PR", "toledo"), ("Maringá/PR", "maringa"),
                 ("Cascavel/PR", "cascavel")],
    "csv": [("CASCAVEL - PR", "cascavel"), ("CURITIBA - PR", "curitiba"),
            ("TOLEDO - PR", "toledo"), ("FOZ DO IGUACU - PR", "foz"),
            ("MARINGA - PR", "maringa"), ("CHAPECO - SC", "chapeco"),
            ("SAO PAULO - SP", "sp")],
    "padrao": [("Cascavel/PR", "cascavel"), ("Curitiba/PR", "curitiba"),
               ("Toledo/PR", "toledo"), ("Foz do Iguaçu/PR", "foz"),
               ("Maringá/PR", "maringa"), ("Londrina/PR", "londrina"),
               ("Ponta Grossa/PR", "ponta"), ("Chapecó/SC", "chapeco"),
               ("Joinville/SC", "joinville"), ("Porto Alegre/RS", "poa"),
               ("São Paulo/SP", "sp"), ("Campinas/SP", "campinas"),
               ("Dourados/MS", "dourados")],
}
DEST = {
    "whatsapp": [("Floripa/SC", "floripa"), ("sampa", "sp"), ("BH", "bh"),
                 ("Curitiba/PR", "curitiba")],
    "csv": [("FLORIANOPOLIS - SC", "floripa"), ("CURITIBA - PR", "curitiba"),
            ("SAO PAULO - SP", "sp")],
    "padrao": [("Florianópolis/SC", "floripa"), ("Curitiba/PR", "curitiba"),
               ("São Paulo/SP", "sp"), ("Porto Alegre/RS", "poa"),
               ("Campo Grande/MS", "cg"), ("Goiânia/GO", "goiania"),
               ("Belo Horizonte/MG", "bh"), ("Rio de Janeiro/RJ", "rio")],
}

TIPOS = {
    "api": ["cegonha", "PRANCHA", "BAU", "container"],
    "csv": ["Cegonha", "prancha", "baú", "sider", "carreta aberta"],
    "email": ["cegonheira", "Sider", "guincho", "Cegonha"],
    "pdf": ["cegonha", "prancha"],
    "whatsapp": ["cegonha", "guincho"],
}
STATUS = {
    "api": ["NOVA", "EM_COTACAO", "APROVADA", "AGENDADA", "CONCLUIDA"],
    "csv": ["Nova", "em cotação", "Cotada", "aprovado", "Cancelada"],
    "email": ["Nova", "Cotada", "AGENDADA", "aprovado"],
    "pdf": ["Agendada"],
}

VEICULOS = [("carros", 1300), ("motos", 180), ("caminhonetes", 2100)]
MES_ABREV = ["jan", "fev", "mar", "abr", "mai", "jun", "jul", "ago", "set", "out", "nov", "dez"]


class Ciclo:
    """Percorre uma lista em ordem, voltando ao inicio (garante que toda grafia aparece)."""

    def __init__(self, itens, inicio=0):
        self.itens, self.i = list(itens), inicio

    def prox(self):
        v = self.itens[self.i % len(self.itens)]
        self.i += 1
        return v


ciclos_orig = {k: Ciclo(v) for k, v in ORIG.items()}
ciclos_dest = {k: Ciclo(v) for k, v in DEST.items()}
ciclos_tipo = {k: Ciclo(v) for k, v in TIPOS.items()}
ciclos_status = {k: Ciclo(v) for k, v in STATUS.items()}
ciclo_crm = Ciclo([c[0] for c in CRM])
ciclo_apelido = Ciclo(APELIDOS, inicio=1)   # o indice 0 (Frota Pampa) e do WA-0007
ciclo_prospect = Ciclo(PROSPECTS)


def rota(canal):
    grupo = canal if canal in ("whatsapp", "csv") else "padrao"
    o_txt, o_id = ciclos_orig[grupo].prox()
    d_txt, d_id = ciclos_dest[grupo].prox()
    while d_id == o_id:
        d_txt, d_id = ciclos_dest[grupo].prox()
    return o_txt, d_txt


def sequencia_classes(n_cnpj, n_fuzzy, n_none):
    lista = ["cnpj"] * n_cnpj + ["fuzzy"] * n_fuzzy + ["none"] * n_none
    rng.shuffle(lista)
    return lista


MULT_VEICULO = {"carros": 1.0, "motos": 0.35, "caminhonetes": 1.45}


def frete_real(origem_txt, destino_txt, veiculo, qtd, ruido):
    """Como a Rodomax 'de verdade' cobra (o modelo de IA nao ve esta formula):
    taxa fixa + R$/km por veiculo, ajustada pelo porte do veiculo, com negociacao."""
    o, _ = normalizar_local(origem_txt)
    d, _ = normalizar_local(destino_txt)
    km = distancia_km(o, d)
    por_veiculo = (250 + 1.3 * km) * MULT_VEICULO[veiculo] * ruido
    return max(100, round(qtd * por_veiculo, -2))


def demanda(id_, canal, classe):
    """Monta a demanda 'verdadeira' (antes de ser escrita no formato do canal)."""
    veic, peso_un = rng.choice(VEICULOS[:2]) if canal != "whatsapp" else rng.choice(VEICULOS)
    qtd = rng.randint(1, 9)
    ruido = rng.uniform(0.85, 1.15)          # negociacao normal: +-15%
    if rng.random() < 0.05:                   # ~5% fora da curva (erro de digitacao, urgencia, desconto)
        ruido *= rng.choice([0.5, 1.9])
        FORA_DA_CURVA.add(id_)                # gabarito para avaliar a deteccao de anomalias
    if classe == "cnpj":
        cid = ciclo_crm.prox()
        nome = NOME_CRM[cid] if rng.random() < 0.6 else rng.choice([a for c, a in APELIDOS if c == cid])
        cnpj = CNPJ_CRM[cid]
    elif classe == "fuzzy":
        cid, nome = ciclo_apelido.prox()
        cnpj = None
    else:
        nome, raiz = ciclo_prospect.prox()
        cid = None
        cnpj = cnpj_valido(raiz) if raiz else None
    o, d = rota(canal)
    valor = frete_real(o, d, veic, qtd, ruido)
    coleta =date(2026, 4, 14) + timedelta(days=rng.randint(0, 36))
    return dict(id=id_, canal=canal, classe=classe, cliente_id=cid, nome=nome, cnpj=cnpj,
                origem=o, destino=d, qtd=qtd, veiculo=veic, peso=qtd * peso_un,
                valor=valor, coleta=coleta)


# --------------------------------------------------------------------------
# Formatos de escrita
# --------------------------------------------------------------------------

def br(v, casas=2):
    s = f"{v:,.{casas}f}"
    return s.replace(",", "X").replace(".", ",").replace("X", ".")


def valor_txt(v, estilo):
    return {"rs": f"R$ {br(v)}", "br": br(v), "int": str(int(v)),
            "k": f"{br(v / 1000, 1)}k".replace(",0k", "k")}[estilo]


def peso_txt(kg, estilo):
    return {"kg": f"{int(kg)} kg", "t": f"{br(kg / 1000, 1)} t".replace(",0 t", " t"),
            "nu": str(int(kg)), "kgbr": f"{br(kg, 0)} kg"}[estilo]


def dmy(d):
    return d.strftime("%d/%m/%Y")


# --------------------------------------------------------------------------
# Canal 1 - WhatsApp (texto livre ou template)
# --------------------------------------------------------------------------

WA_CAMPOS = []
FORA_DA_CURVA = set()


def gerar_whatsapp(gabarito):
    ids = [f"WA-{i:04d}" for i in range(1, 26)]
    rota_incompleta = {"WA-0001", "WA-0004", "WA-0010", "WA-0015", "WA-0019", "WA-0023"}
    classes = Ciclo(sequencia_classes(8, 7, 3))
    linhas = []
    inicio = datetime(2026, 4, 1, 8, 0)
    ciclo_valor = Ciclo(["k", "int"])
    for n, id_ in enumerate(ids, start=1):
        quando = inicio + timedelta(days=(n * 11) // 7, hours=n % 9, minutes=(n * 17) % 60)
        if id_ == "WA-0007":   # exemplo usado na apresentacao
            quando = datetime(2026, 4, 12, 9, 14)
            corpo = ("oi, Frota Pampa aqui. preciso levar 7 carros de cascavel  pr pra "
                     "Floripa/SC, coleta 04/25/2026, fecha em 8,3k?")
            gabarito.append(("WA-0007", "CLI007"))
            _ = rota("whatsapp")  # consome a grafia para manter o ciclo
        elif id_ in rota_incompleta:
            d = demanda(id_, "whatsapp", "fuzzy")
            corpo = (f"oi, {d['nome']} aqui. preciso levar {d['qtd']} {d['veiculo']} de "
                     f"{d['origem']}, me passa um valor?")
            gabarito.append((id_, d["cliente_id"]))
        else:
            classe = classes.prox()
            d = demanda(id_, "whatsapp", classe)
            gabarito.append((id_, d["cliente_id"]))
            if classe == "cnpj":
                cnpj = mascara(d["cnpj"]) if n % 2 else d["cnpj"]
                corpo = "\n".join([
                    "*SOLICITAÇÃO DE FRETE*",
                    f"Empresa: {d['nome']}",
                    f"CNPJ: {cnpj}",
                    f"Origem: {d['origem']}",
                    f"Destino: {d['destino']}",
                    f"Veículos: {d['qtd']}",
                    f"Tipo: {ciclos_tipo['whatsapp'].prox()}",
                    f"Coleta: {dmy(d['coleta'])}",
                    f"Valor: {valor_txt(d['valor'], 'rs')}",
                ])
            elif n % 2:
                corpo = (f"oi, {d['nome']} aqui. preciso levar {d['qtd']} {d['veiculo']} de "
                         f"{d['origem']} pra {d['destino']}, coleta {dmy(d['coleta'])}, "
                         f"fecha em {valor_txt(d['valor'], ciclo_valor.prox())}?")
            else:
                corpo = (f"bom dia! aqui é da {d['nome']}. tenho {d['qtd']} {d['veiculo']} "
                         f"saindo de {d['origem']} para {d['destino']}. coleta "
                         f"{dmy(d['coleta'])}. valor {valor_txt(d['valor'], ciclo_valor.prox())} ok?")
        # gabarito da extracao: o que a mensagem REALMENTE diz (para medir a taxa de acerto)
        if id_ == "WA-0007":
            WA_CAMPOS.append(dict(id_demanda=id_, origem="Cascavel", destino="Florianópolis",
                                  qtd_unidades=7, veiculo="carro", valor_frete=8300.0,
                                  data_coleta="2026-04-25", cliente_id="CLI007"))
        else:
            completa = id_ not in rota_incompleta
            template = completa and classe == "cnpj"
            WA_CAMPOS.append(dict(
                id_demanda=id_, origem=normalizar_local(d["origem"])[0],
                destino=normalizar_local(d["destino"])[0] if completa else None,
                qtd_unidades=d["qtd"], veiculo=None if template else d["veiculo"].rstrip("s"),
                valor_frete=float(d["valor"]) if completa else None,
                data_coleta=d["coleta"].isoformat() if completa else None,
                cliente_id=d["cliente_id"]))
        carimbo = quando.strftime("%d/%m/%Y %H:%M")
        linhas.append(f"{carimbo} - Cliente: {id_} - {corpo}")
        resposta = (quando + timedelta(minutes=7)).strftime("%d/%m/%Y %H:%M")
        linhas.append(f"{resposta} - Rodomax Comercial: recebido! já te retorno com a cotação 👍")
    pasta = RAIZ / "raw" / "whatsapp"
    pasta.mkdir(parents=True, exist_ok=True)
    (pasta / "conversa_comercial.txt").write_text("\n".join(linhas) + "\n", encoding="utf-8")


# --------------------------------------------------------------------------
# Canal 2 - E-mail (tabelas HTML com cabecalhos diferentes)
# --------------------------------------------------------------------------

CAB_A = ["Ref", "Cliente", "CNPJ", "Origem", "Destino", "Qtd", "Tipo", "Peso", "Valor",
         "Coleta", "Status", "Observação"]
CAB_B = ["Ref", "Empresa", "Documento", "Saída", "Chegada", "Veículos", "Equipamento",
         "Peso", "Frete", "Data coleta", "Situação", "Contato"]
# colunas extras (obsoletas para o HUB): observacao livre e telefone do contato (dado pessoal)
EXTRA_A = ["", "", "confirmar janela de coleta", ""]
EXTRA_B = ["(45) 99812-4471", "(41) 99654-1209", "(45) 99123-8890"]


def gerar_email(gabarito):
    classes = Ciclo(sequencia_classes(14, 3, 2))
    linhas = []
    for i in range(1, 21):
        id_ = f"EM-{i:04d}"
        classe = "cnpj" if id_ == "EM-0011" else classes.prox()
        d = demanda(id_, "email", classe)
        gabarito.append((id_, d["cliente_id"]))
        if classe == "fuzzy":
            cnpj = mascara(CNPJ_CRM[d["cliente_id"]])[:10]   # truncado: 24.883.107
        elif d["cnpj"]:
            cnpj = mascara(d["cnpj"])
        else:
            cnpj = ""
        data = (f"{d['coleta'].day:02d}-{MES_ABREV[d['coleta'].month - 1]}-{d['coleta'].year}"
                if i % 2 else dmy(d["coleta"]))
        linhas.append([
            id_, d["nome"], cnpj, d["origem"], d["destino"],
            "" if id_ == "EM-0011" else str(d["qtd"]),
            ciclos_tipo["email"].prox(),
            peso_txt(d["peso"], "t" if i % 2 else "kg"),
            valor_txt(d["valor"], "rs" if i % 3 else "br"),
            data, ciclos_status["email"].prox(),
        ])
    pasta = RAIZ / "raw" / "email"
    pasta.mkdir(parents=True, exist_ok=True)
    grupos = [linhas[0:4], linhas[4:7], linhas[7:11], linhas[11:14], linhas[14:17], linhas[17:20]]
    for n, grupo in enumerate(grupos, start=1):
        cab = CAB_A if n % 2 else CAB_B
        th = "".join(f"<th>{c}</th>" for c in cab)
        extra = EXTRA_A if n % 2 else EXTRA_B
        trs = "\n".join("<tr>" + "".join(f"<td>{v}</td>" for v in l + [extra[k % len(extra)]]) + "</tr>"
                        for k, l in enumerate(grupo))
        html = f"""<html><head><meta charset="utf-8"><title>Programação de fretes #{n}</title></head>
<body>
<p>Prezados, boa tarde.</p>
<p>Segue abaixo a programação de transporte desta semana. Favor confirmar disponibilidade.</p>
<table border="1">
<tr>{th}</tr>
{trs}
</table>
<p>Atenciosamente,</p>
<table><tr><td>Setor de Logística</td><td>(45) 3333-0000</td></tr></table>
</body></html>
"""
        (pasta / f"email_{n:02d}.html").write_text(html, encoding="utf-8")


# --------------------------------------------------------------------------
# Canal 3 - Portal / API (webhook JSON, com reenvios)
# --------------------------------------------------------------------------

def gerar_api(gabarito):
    classes = Ciclo(sequencia_classes(23, 0, 2))
    eventos = []
    for i in range(1, 26):
        id_ = f"API-{i:04d}"
        d = demanda(id_, "api", classes.prox())
        gabarito.append((id_, d["cliente_id"]))
        eventos.append({
            "evento": "demanda.criada",
            "tentativa": 1,
            "recebido_em": f"2026-04-{(i % 28) + 1:02d}T{8 + i % 10:02d}:{(i * 7) % 60:02d}:00-03:00",
            "payload": {
                "id_demanda": id_,
                "cliente": {"razao_social": d["nome"], "cnpj": d["cnpj"]},
                "rota": {"origem": d["origem"], "destino": d["destino"]},
                "carga": {"tipo": ciclos_tipo["api"].prox(), "qtd": d["qtd"],
                          "peso_kg": float(d["peso"])},
                "valor": float(d["valor"]),
                "data_coleta": d["coleta"].isoformat(),
                "status": ciclos_status["api"].prox(),
            },
        })
    # reenvios tecnicos (timeout do portal): mesmo id_demanda, tentativa 2
    saida = []
    for ev in eventos:
        saida.append(ev)
        pid = ev["payload"]["id_demanda"]
        if pid in ("API-0009", "API-0020"):
            alvo = {"API-0009": "API-0005", "API-0020": "API-0012"}[pid]
            orig = next(e for e in eventos if e["payload"]["id_demanda"] == alvo)
            saida.append({**orig, "tentativa": 2})
    pasta = RAIZ / "raw" / "api"
    pasta.mkdir(parents=True, exist_ok=True)
    with open(pasta / "webhooks.jsonl", "w", encoding="utf-8") as f:
        for ev in saida:
            f.write(json.dumps(ev, ensure_ascii=False) + "\n")


# --------------------------------------------------------------------------
# Canal 4 - Planilha legado (CSV latin-1, separador ;)
# --------------------------------------------------------------------------

def gerar_csv(gabarito):
    classes = Ciclo(sequencia_classes(22, 3, 3))
    pasta = RAIZ / "raw" / "csv"
    pasta.mkdir(parents=True, exist_ok=True)
    estilos_valor = Ciclo(["rs", "br", "int"])
    estilos_peso = Ciclo(["kg", "t", "nu"])
    with open(pasta / "planilha_legado.csv", "w", encoding="latin-1", newline="") as f:
        w = csv.writer(f, delimiter=";")
        # as 4 ultimas colunas sao heranca do sistema antigo (obsoletas para o HUB)
        w.writerow(["ID", "CLIENTE", "CNPJ", "ORIGEM", "DESTINO", "QTD", "TIPO", "PESO",
                    "VALOR", "DT_COLETA", "STATUS", "DIGITADO_POR", "COD_FILIAL_ANTIGO",
                    "COL_AUX", "DT_ULT_ALTERACAO"])
        for i in range(1, 30):
            id_ = f"CSV-{i:04d}"
            classe = "cnpj" if id_ == "CSV-0008" else classes.prox()
            d = demanda(id_, "csv", classe)
            gabarito.append((id_, d["cliente_id"]))
            w.writerow([
                id_, d["nome"].upper(), mascara(d["cnpj"]) if d["cnpj"] else "",
                d["origem"], d["destino"], "0" if id_ == "CSV-0008" else d["qtd"],
                ciclos_tipo["csv"].prox(), peso_txt(d["peso"], estilos_peso.prox()),
                valor_txt(d["valor"], estilos_valor.prox()), dmy(d["coleta"]),
                ciclos_status["csv"].prox(),
                ["Marcia S.", "Joao P.", "Carla M."][i % 3], "01", "",
                f"{(i % 27) + 1:02d}/03/2026 17:{(i * 7) % 60:02d}",
            ])


# --------------------------------------------------------------------------
# Canal 5 - Ordem de coleta (PDF com tabela)
# --------------------------------------------------------------------------

def gerar_pdf(gabarito):
    classes = Ciclo(sequencia_classes(11, 1, 0))
    pasta = RAIZ / "raw" / "pdf"
    pasta.mkdir(parents=True, exist_ok=True)
    cab = ["OC", "Cliente", "CNPJ", "Origem", "Destino", "Qtd", "Tipo", "Peso", "Valor",
           "Coleta", "Status"]
    larg = [17, 50, 33, 27, 27, 9, 16, 19, 23, 19, 21]
    for doc in range(3):
        pdf = FPDF(orientation="L", format="A4")
        pdf.add_page()
        pdf.set_font("Helvetica", "B", 13)
        pdf.cell(0, 9, "RODOMAX TRANSPORTES - ORDEM DE COLETA", new_x="LMARGIN", new_y="NEXT")
        pdf.set_font("Helvetica", "", 9)
        pdf.cell(0, 6, f"Documento OC-LOTE-{doc + 1:02d}  |  Emitido em 0{doc + 6}/04/2026",
                 new_x="LMARGIN", new_y="NEXT")
        pdf.ln(3)
        pdf.set_font("Helvetica", "", 7)
        with pdf.table(col_widths=larg, text_align="LEFT", line_height=4.5) as tabela:
            linha = tabela.row()
            for c in cab:
                linha.cell(c)
            for k in range(4):
                i = doc * 4 + k + 1
                id_ = f"OC-{i:04d}"
                d = demanda(id_, "pdf", classes.prox())
                gabarito.append((id_, d["cliente_id"]))
                cnpj = mascara(d["cnpj"]) if d["cnpj"] else "**.***.***/0001-**"
                valores = [id_, d["nome"].upper(), cnpj, d["origem"], d["destino"],
                           str(d["qtd"]), ciclos_tipo["pdf"].prox(), peso_txt(d["peso"], "kgbr"),
                           valor_txt(d["valor"], "rs"), dmy(d["coleta"]),
                           ciclos_status["pdf"].prox()]
                linha = tabela.row()
                for v in valores:
                    linha.cell(v)
        pdf.ln(4)
        pdf.set_font("Helvetica", "I", 8)
        pdf.cell(0, 5, "Assinatura do expedidor: ______________________")
        pdf.output(str(pasta / f"ordem_coleta_lote_{doc + 1:02d}.pdf"))


# --------------------------------------------------------------------------

def main():
    if (RAIZ / "raw").exists():
        shutil.rmtree(RAIZ / "raw")
    gabarito = []
    gerar_whatsapp(gabarito)
    gerar_email(gabarito)
    gerar_api(gabarito)
    gerar_csv(gabarito)
    gerar_pdf(gabarito)

    (RAIZ / "crm").mkdir(parents=True, exist_ok=True)
    with open(RAIZ / "crm" / "clientes.csv", "w", encoding="utf-8", newline="") as f:
        w = csv.writer(f)
        w.writerow(["cliente_id", "razao_social", "cnpj", "cidade", "uf"])
        for cid, nome, _, cidade, uf in CRM:
            w.writerow([cid, nome, mascara(CNPJ_CRM[cid]), cidade, uf])

    (RAIZ / "gabarito").mkdir(parents=True, exist_ok=True)
    with open(RAIZ / "gabarito" / "vinculo_rotulado.csv", "w", encoding="utf-8", newline="") as f:
        w = csv.writer(f)
        w.writerow(["id_demanda", "cliente_id_real", "frete_fora_da_curva"])
        for id_, cid in gabarito:
            w.writerow([id_, cid or "", int(id_ in FORA_DA_CURVA)])
    with open(RAIZ / "gabarito" / "whatsapp_campos.csv", "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(WA_CAMPOS[0]))
        w.writeheader()
        w.writerows({k: ("" if v is None else v) for k, v in r.items()} for r in WA_CAMPOS)
    print(f"Dados gerados em {RAIZ}  ({len(gabarito)} demandas unicas + 2 reenvios da API)")


if __name__ == "__main__":
    main()
