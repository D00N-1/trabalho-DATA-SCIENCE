"""BUG FREE - HUB Integrador de Dados: executa o pipeline completo.

    python main.py            roda os 6 estagios e grava tudo em output/
    python main.py --gerar    recria antes os dados brutos de exemplo (data/raw)
    python main.py --abrir    abre o relatorio HTML no navegador ao final
"""
import argparse
import csv
import json
import sys
import time
import webbrowser
from collections import Counter

from bugfree import (auditoria, calibracao, config, crm, extracao, modelo_frete, normalizacao, parsers,
                     perfis, relatorio)
from bugfree.schema import CAMPOS_FINAIS

NOMES = relatorio.NOMES_CANAL


def titulo(n, nome, arquivo):
    print(f"\n\033[33m[{n}/9]\033[0m \033[1m{nome}\033[0m  \033[90m{arquivo}\033[0m")
    time.sleep(0.15)


def salvar_csv(caminho, linhas, campos):
    with open(caminho, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=campos, extrasaction="ignore")
        w.writeheader()
        w.writerows(linhas)


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--gerar", action="store_true", help="recria os dados brutos de exemplo")
    ap.add_argument("--abrir", action="store_true", help="abre o relatorio no navegador")
    args = ap.parse_args()

    if args.gerar or not config.DIR_RAW.exists():
        import gerar_dados
        gerar_dados.main()

    out = config.DIR_OUTPUT
    out.mkdir(exist_ok=True)
    print("\n\033[1mBUG FREE - HUB Integrador de Dados\033[0m  (UNIVEL x Rodomax)")
    print("=" * 64)

    # 01 ------------------------------------------------------------------
    titulo(1, "Canais - fontes brutas", "data/raw/")
    for pasta in sorted(config.DIR_RAW.iterdir()):
        arqs = [a.name for a in pasta.iterdir()]
        print(f"   {pasta.name:<9} {len(arqs)} arquivo(s): {', '.join(arqs)}")

    # 02 ------------------------------------------------------------------
    titulo(2, "Leitores - extraem e mapeiam para o schema", "bugfree/parsers.py")
    brutos = parsers.ler_todos(config.DIR_RAW)
    for canal, regs in brutos.items():
        print(f"   {NOMES[canal]:<22} {len(regs):>3} registros")
    todos = [r for regs in brutos.values() for r in regs]
    print(f"   {'TOTAL':<22} {len(todos):>3} demandas brutas")

    # 03 ------------------------------------------------------------------
    titulo(3, "Auditoria - mede a bagunca antes de corrigir", "bugfree/auditoria.py")
    aud = auditoria.auditar(brutos, parsers.colunas_obsoletas())
    print(f"   {'coluna':<12}{'distintos':>10}{'reais':>8}")
    for c in aud["cardinalidade"]:
        print(f"   {c['coluna']:<12}{c['distintos']:>10}{c['reais']:>8}")
    print(f"   valor_frete em {len(aud['formatos']['valor_frete'])} grafias: " +
          " | ".join(f"{f['formato'].split(' (')[0]} {f['pct']}%" for f in aud["formatos"]["valor_frete"]))
    print(f"   peso: " + " | ".join(f"{f['formato']} {f['registros']}" for f in aud["formatos"]["peso"]))
    print(f"   cnpj: " + " | ".join(f"{f['formato'].split(' (')[0]} {f['registros']}" for f in aud["formatos"]["cnpj"]))
    print(f"   ids repetidos: {aud['ids_repetidos']}")
    print(f"   {'estatistica':<18}{'n':>4}{'media':>10}{'mediana':>10}{'min':>9}{'max':>10}{'outliers':>9}")
    for k, e in aud["estatisticas"].items():
        print(f"   {k:<18}{e['n']:>4}{e['media']:>10,.0f}{e['mediana']:>10,.0f}{e['minimo']:>9,.0f}"
              f"{e['maximo']:>10,.0f}{e['outliers_iqr']:>9}")
    print(f"   colunas obsoletas eliminadas na leitura: {len(aud['colunas_obsoletas'])}")
    for c in aud["colunas_obsoletas"]:
        print(f"     - {c['canal']:<9}{c['coluna']:<20}{c['evidencia']:<34}{c['motivo']}")

    # 04 ------------------------------------------------------------------
    titulo(4, "Limpeza - normaliza e descarta com motivo", "bugfree/normalizacao.py")
    base, descartes = normalizacao.executar(todos)
    for motivo, n in Counter(d["motivo"] for d in descartes).most_common():
        print(f"   descartado: {motivo:<36} {n}")
    print(f"   {len(descartes)} de {len(todos)} excluidos, 100% com motivo -> {len(base)} validos")

    # 05 ------------------------------------------------------------------
    titulo(5, "CRM - vincula ao cadastro de clientes", "bugfree/crm.py")
    clientes = crm.carregar_crm(config.ARQ_CRM)
    crm.vincular(base, clientes, config.LIMIAR_FUZZY)
    vinc = Counter(r["metodo_vinculo"] for r in base)
    for m, rot in [("CNPJ", "CNPJ (deterministico)"), ("FUZZY", f"razao social (score >= {config.LIMIAR_FUZZY})"),
                   ("SEM_MATCH", "sem match -> curadoria")]:
        print(f"   {rot:<34} {vinc[m]:>3}  ({100 * vinc[m] / len(base):.1f}%)")
    calib = calibracao.calibrar(base, clientes, calibracao.carregar_gabarito(config.ARQ_GABARITO))
    print(f"   calibracao: melhor F1 com limiar entre {min(calib['faixa_otima'])} e "
          f"{max(calib['faixa_otima'])}; recomendado {calib['limiar_recomendado']} "
          f"(em uso: {config.LIMIAR_FUZZY})")

    # 06 ------------------------------------------------------------------
    titulo(6, "Base final - grava resultados", "output/")
    salvar_csv(out / "base_final.csv", base, CAMPOS_FINAIS)
    salvar_csv(out / "descartes.csv", descartes, ["id_demanda", "canal", "motivo", "valor_bruto"])
    salvar_csv(out / "curadoria_crm.csv", [r for r in base if r["metodo_vinculo"] == "SEM_MATCH"],
               ["id_demanda", "canal", "cliente_nome_original", "cnpj", "candidato_mais_proximo", "score_vinculo"])
    salvar_csv(out / "calibracao_limiar.csv", calib["curva"], list(calib["curva"][0]))
    (out / "auditoria.json").write_text(json.dumps(aud, ensure_ascii=False, indent=2), encoding="utf-8")
    for arq in ["base_final.csv", "descartes.csv", "curadoria_crm.csv", "calibracao_limiar.csv",
                "auditoria.json"]:
        print(f"   output/{arq}")

    # 07 ------------------------------------------------------------------
    titulo(7, "IA - estimativa de frete justo (regressao)", "bugfree/modelo_frete.py")
    ia = modelo_frete.treinar_e_avaliar(base)
    print(f"   {ia['n_total']} demandas  ->  treino {ia['n_treino']} | teste {ia['n_teste']}"
          f"   (alvo: R$ por veiculo; atributos: {', '.join(ia['atributos'][:4])}, tipo de carga)")
    print(f"   {'modelo':<38}{'MAE teste':>12}{'R2 teste':>10}{'MAE cv5':>11}")
    for r in ia["resultados"]:
        print(f"   {r['modelo']:<38}{'R$ ' + format(r['teste']['mae'], ',.0f'):>12}"
              f"{r['teste']['r2']:>10.3f}{'R$ ' + format(r['cv5']['mae'], ',.0f'):>11}")
    mae_b = ia["resultados"][0]["teste"]["mae"]
    mae_v = next(r for r in ia["resultados"] if r["modelo"] == ia["vencedor"])["teste"]["mae"]
    print(f"   escolhido: {ia['vencedor']}  (erro {100 * (1 - mae_v / mae_b):.0f}% menor que a linha de base)")
    modelo_frete.salvar(ia["_artefato"], out / "modelo_frete.pkl")
    salvar_csv(out / "ia_previsoes_teste.csv", ia["exemplos_teste"], list(ia["exemplos_teste"][0]))
    (out / "ia_avaliacao.json").write_text(json.dumps({k: v for k, v in ia.items() if k != "_artefato"},
                                                      ensure_ascii=False, indent=2, default=float), encoding="utf-8")
    wa7 = modelo_frete.prever(ia["_artefato"], next(r for r in base if r["id_demanda"] == "WA-0007"))
    print(f"   exemplo WA-0007: informado R$ {wa7['informado']:,.0f} | frete justo R$ {wa7['frete_justo']:,.0f}"
          f" ({wa7['diferenca_pct']:+.1f}%) -> {wa7['veredito']}")
    # 08 ------------------------------------------------------------------
    titulo(8, "IA - perfis (K-means), anomalias (DBSCAN) e casos parecidos (KNN)", "bugfree/perfis.py")
    pf = perfis.treinar_e_avaliar(base, perfis.carregar_gabarito_anomalias(config.ARQ_GABARITO))
    p = pf["perfis"]
    print(f"   K-means: k={p['k']} perfis escolhido pela silhueta = {p['silhueta']:.3f}"
          f"  (linha de base aleatoria: {p['silhueta_aleatoria']:.3f})")
    for g in p["grupos"]:
        print(f"     - {g['nome']:<44}{g['demandas']:>3} demandas | R$ {g['frete_medio_por_veiculo']:,.0f}/veiculo")
    a = pf["anomalias"]
    for nome, chave_a in [("DBSCAN", "dbscan"), ("Linha de base IQR", "linha_de_base_iqr")]:
        av = a[chave_a]["avaliacao"]
        print(f"   {nome:<18} marcou {av['marcadas']:>2} | achou {av['acertos']} de {av['reais']} fretes fora da curva"
              f" | precisao {av['precisao']}% recall {av['recall']}%")
    perfis.salvar(pf["_artefato"], out / "perfis.pkl")
    (out / "ia_perfis.json").write_text(json.dumps({k: v for k, v in pf.items() if k != "_artefato"},
                                                   ensure_ascii=False, indent=2, default=float), encoding="utf-8")

    # 09 ------------------------------------------------------------------
    titulo(9, "IA - taxa de acerto da extracao de mensagens livres", "bugfree/extracao.py")
    ex = extracao.avaliar(config.DIR_RAW, config.DIR_DADOS / "gabarito" / "whatsapp_campos.csv",
                          config.DIR_DADOS / "gabarito" / "mensagens_teste.csv", clientes, config.LIMIAR_FUZZY)
    print(f"   {'conjunto':<36}{'acerto medio/campo':>19}{'registro completo':>19}")
    for nome, k in [("lote (25 mensagens)", "lote"), ("lote - linha de base (so template)", "lote_linha_de_base"),
                    ("mensagens novas (10)", "teste"), ("novas - linha de base (so template)", "teste_linha_de_base")]:
        print(f"   {nome:<36}{ex[k]['media_campos']:>18}%{ex[k]['registro_completo']:>18}%")
    (out / "ia_extracao.json").write_text(json.dumps(ex, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    for arq in ["perfis.pkl", "ia_perfis.json", "ia_extracao.json"]:
        print(f"   output/{arq}")

    texto_wa7 = next(l for l in (config.DIR_RAW / "whatsapp" / "conversa_comercial.txt")
                     .read_text(encoding="utf-8").splitlines() if "WA-0007" in l)
    relatorio.gerar(out / "relatorio.html", brutos_por_canal=brutos, aud=aud, base=base,
                    descartes=descartes, calib=calib, limiar=config.LIMIAR_FUZZY, texto_wa7=texto_wa7,
                    ia=ia, wa7_ia=wa7, pf=pf, ex=ex)
    for arq in ["modelo_frete.pkl", "ia_previsoes_teste.csv", "ia_avaliacao.json", "relatorio.html"]:
        print(f"   output/{arq}")

    n_vinc = vinc["CNPJ"] + vinc["FUZZY"]
    print("\n" + "=" * 64)
    print(f"  FUNIL: {len(todos)} brutos -> {len(descartes)} descartados -> {len(base)} na base final"
          f" -> {n_vinc} vinculados ao CRM")
    print(f"  Aproveitamento: {100 * len(base) / len(todos):.1f}% ({len(base)}/{len(todos)})   "
          f"Vinculo ao CRM: {100 * n_vinc / len(base):.1f}% ({n_vinc}/{len(base)})")
    print("=" * 64)

    if args.abrir:
        webbrowser.open((out / "relatorio.html").as_uri())


if __name__ == "__main__":
    main()
