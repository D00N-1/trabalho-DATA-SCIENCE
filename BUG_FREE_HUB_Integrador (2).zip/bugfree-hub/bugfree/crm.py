"""Estagio 05 - CRM: vincula cada demanda ao cadastro de clientes.

1. CNPJ valido encontrado no cadastro   -> vinculo deterministico
2. senao, similaridade da razao social  -> vinculo fuzzy (score >= limiar)
3. senao                                -> sem match, vai para curadoria
"""
import csv
import re

from rapidfuzz import fuzz

from .catalogos import chave

STOPWORDS = {"ltda", "sa", "s", "a", "me", "eireli", "de", "da", "do", "das", "dos", "e"}


def carregar_crm(caminho):
    with open(caminho, encoding="utf-8") as f:
        clientes = list(csv.DictReader(f))
    for c in clientes:
        c["cnpj_digitos"] = re.sub(r"\D", "", c["cnpj"])
        c["nome_chave"] = nome_chave(c["razao_social"])
    return clientes


def nome_chave(nome):
    """'PAMPA GESTÃO DE FROTAS LTDA' -> 'pampa gestao frota' (sem sufixo societario,
    sem preposicao, plural simples removido)."""
    tokens = []
    for t in chave(nome).split():
        if t in STOPWORDS:
            continue
        if len(t) > 3 and t.endswith("s"):
            t = t[:-1]
        tokens.append(t)
    return " ".join(tokens)


def similaridade(a, b):
    """Media entre token_set (um nome contido no outro) e token_sort (nomes
    parecidos por inteiro). So o token_set aceitaria 'Pampa' = 'Pampa Frotas'.
    Tambem compara sem espacos, para nomes colados ('MotoCenter' = 'Moto Center')."""
    por_tokens = (fuzz.token_set_ratio(a, b) + fuzz.token_sort_ratio(a, b)) / 2
    colado = fuzz.ratio(a.replace(" ", ""), b.replace(" ", ""))
    return max(por_tokens, colado)


def melhor_candidato(nome, clientes):
    """(cliente, score) do cliente mais parecido com o nome informado."""
    if not nome:
        return None, 0.0
    k = nome_chave(nome)
    return max(((c, similaridade(k, c["nome_chave"])) for c in clientes),
               key=lambda x: x[1])


def vincular(base, clientes, limiar):
    por_cnpj = {c["cnpj_digitos"]: c for c in clientes}
    for r in base:
        cliente = por_cnpj.get(r["cnpj"]) if r["cnpj"] else None
        if cliente:
            metodo, score = "CNPJ", 100.0
        else:
            cliente, score = melhor_candidato(r["cliente_nome_original"], clientes)
            metodo = "FUZZY" if cliente and score >= limiar else "SEM_MATCH"
            if metodo == "SEM_MATCH":
                r["candidato_mais_proximo"] = cliente["razao_social"] if cliente else None
                cliente = None
        r["cliente_id"] = cliente["cliente_id"] if cliente else None
        r["cliente_razao_social"] = cliente["razao_social"] if cliente else None
        r["metodo_vinculo"] = metodo
        r["score_vinculo"] = round(score, 1)
    return base
