"""Calibracao do limiar de similaridade do vinculo fuzzy.

Usa pares rotulados (data/gabarito/vinculo_rotulado.csv: qual e o cliente
verdadeiro de cada demanda) e mede, para cada limiar candidato, a precisao
e a cobertura (recall) do vinculo por razao social. O gabarito e usado SO
aqui, para escolher o limiar; o pipeline nunca olha para ele.
"""
import csv

from .crm import melhor_candidato

LIMIARES = list(range(50, 101, 5))


def carregar_gabarito(caminho):
    with open(caminho, encoding="utf-8") as f:
        return {r["id_demanda"]: (r["cliente_id_real"] or None) for r in csv.DictReader(f)}


def calibrar(base, clientes, gabarito, limiares=LIMIARES):
    # so entram demandas que chegam ao fuzzy (sem CNPJ valido no cadastro)
    cnpjs = {c["cnpj_digitos"] for c in clientes}
    pares = []
    for r in base:
        if r["cnpj"] in cnpjs:
            continue
        cliente, score = melhor_candidato(r["cliente_nome_original"], clientes)
        pares.append((cliente["cliente_id"] if cliente else None, score,
                      gabarito.get(r["id_demanda"])))

    curva = []
    for t in limiares:
        vp = fp = fn = 0
        for previsto, score, real in pares:
            previsto = previsto if score >= t else None
            if previsto and previsto == real:
                vp += 1
            else:
                fp += previsto is not None
                fn += real is not None
        precisao = vp / (vp + fp) if vp + fp else 1.0
        recall = vp / (vp + fn) if vp + fn else 1.0
        f1 = 2 * precisao * recall / (precisao + recall) if precisao + recall else 0.0
        curva.append({"limiar": t, "vinculos_corretos": vp, "vinculos_errados": fp,
                      "perdidos": fn, "precisao": round(100 * precisao, 1),
                      "recall": round(100 * recall, 1), "f1": round(100 * f1, 1)})

    melhor_f1 = max(p["f1"] for p in curva)
    recomendado = max(p["limiar"] for p in curva if p["f1"] == melhor_f1)
    return {"pares_avaliados": len(pares), "curva": curva, "limiar_recomendado": recomendado,
            "faixa_otima": [p["limiar"] for p in curva if p["f1"] == melhor_f1]}
