"""Estagio 04 - Limpeza: normaliza e descarta (com motivo).

Regra da arquitetura: limpador nao parseia. Recebe registros no schema
bruto, sem saber de qual formato de arquivo vieram.
"""
import re
from datetime import date

from rapidfuzz import fuzz, process

from .catalogos import (APELIDOS_CIDADE, CIDADES, MESES, PESO_PADRAO_VEICULO, STATUS,
                        TIPOS_CARGA, UFS, chave)
from .config import LOCALE_CANAL, STATUS_PADRAO

# --------------------------------------------------------------------------
# Local (cidade + UF)
# --------------------------------------------------------------------------

RE_CIDADE_UF = re.compile(r"^(?P<cidade>.+?)[\s/\-]+(?P<uf>[a-z]{2})$")


def _cidade_oficial(k):
    k = APELIDOS_CIDADE.get(k, k)
    if k in CIDADES:
        return CIDADES[k]
    # erro de digitacao (ex.: "cascavell"): aproxima pelo catalogo
    achado = process.extractOne(k, list(CIDADES), scorer=fuzz.ratio, score_cutoff=88)
    return CIDADES[achado[0]] if achado else None


def normalizar_local(bruto):
    """'CASCAVEL - PR' | 'cascavel  pr' | 'Floripa/SC' | 'cwb' -> ('Cidade', 'UF')."""
    k = chave(bruto)
    if not k:
        return None, None
    oficial = _cidade_oficial(k)
    if oficial is None and (m := RE_CIDADE_UF.match(k)) and m["uf"].upper() in UFS:
        oficial = _cidade_oficial(m["cidade"])
        if oficial and oficial[1] != m["uf"].upper():
            return None, None             # cidade e UF nao combinam
    return oficial if oficial else (None, None)


# --------------------------------------------------------------------------
# Numeros: valor (R$) e peso (kg)
# --------------------------------------------------------------------------

def _numero_br(s):
    s = s.strip()
    if "," in s:                                   # 1.500,00 / 8,3
        return float(s.replace(".", "").replace(",", "."))
    if re.fullmatch(r"\d{1,3}(\.\d{3})+", s):      # 1.500 (milhar)
        return float(s.replace(".", ""))
    return float(s)                                # 1500 / 1500.00


def normalizar_valor(bruto):
    """'R$ 1.500,00' | '1.500,00' | '1500' | '1500.0' | '1,5k' -> 1500.0"""
    if bruto is None:
        return None
    if isinstance(bruto, (int, float)):
        return round(float(bruto), 2)
    s = str(bruto).replace("R$", "").replace(" ", "").lower()
    mult = 1000 if s.endswith("k") else 1
    s = s.rstrip("k")
    try:
        return round(_numero_br(s) * mult, 2)
    except ValueError:
        return None


def normalizar_peso(bruto):
    """'12 t' | '12000 kg' | '12.000 kg' | '12000' -> 12000.0 (kg)"""
    if bruto is None:
        return None
    if isinstance(bruto, (int, float)):
        return float(bruto)
    m = re.fullmatch(r"\s*([\d.,]+)\s*(t|ton|toneladas?|kg)?\s*", str(bruto).lower())
    if not m:
        return None
    n = _numero_br(m[1])
    return round(n * 1000, 1) if m[2] and m[2].startswith("t") else round(n, 1)


def normalizar_qtd(bruto):
    try:
        q = int(str(bruto).strip())
    except (TypeError, ValueError):
        return None
    return q if q > 0 else None


# --------------------------------------------------------------------------
# Datas
# --------------------------------------------------------------------------

def normalizar_data(bruto, canal):
    """Devolve (data ISO, ambigua?).

    - '2026-04-15' (ISO)                 -> sem ambiguidade
    - '15-abr-2026'                      -> sem ambiguidade
    - '04/25/2026'                       -> 25 nao pode ser mes: lido como mm/dd
    - '05/04/2026' em canal com formato fixo (LOCALE_CANAL) -> segue o formato
    - '05/04/2026' em canal sem formato  -> lido como dd/mm e marcado ambiguo
    """
    if bruto is None:
        return None, False
    s = str(bruto).strip().lower()
    try:
        if (m := re.match(r"^(\d{4})-(\d{2})-(\d{2})", s)):
            return date(int(m[1]), int(m[2]), int(m[3])).isoformat(), False
        if (m := re.fullmatch(r"(\d{1,2})-([a-z]{3})-(\d{4})", s)) and m[2] in MESES:
            return date(int(m[3]), MESES[m[2]], int(m[1])).isoformat(), False
        if (m := re.fullmatch(r"(\d{1,2})/(\d{1,2})/(\d{4})", s)):
            a, b, ano = int(m[1]), int(m[2]), int(m[3])
            if a > 12:
                return date(ano, b, a).isoformat(), False
            if b > 12:
                return date(ano, a, b).isoformat(), False
            ambigua = LOCALE_CANAL.get(canal) is None and a != b
            return date(ano, b, a).isoformat(), ambigua
    except ValueError:
        pass
    return None, False


# --------------------------------------------------------------------------
# Vocabulario controlado e documento
# --------------------------------------------------------------------------

def normalizar_tipo(bruto):
    return TIPOS_CARGA.get(chave(bruto)) if bruto else None


def normalizar_status(bruto):
    return STATUS.get(chave(bruto)) if bruto else None


def cnpj_valido(digitos):
    if not re.fullmatch(r"\d{14}", digitos or "") or len(set(digitos)) == 1:
        return False

    def dv(base):
        pesos = [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2][-len(base):]
        r = sum(int(d) * p for d, p in zip(base, pesos)) % 11
        return "0" if r < 2 else str(11 - r)

    return digitos[12] == dv(digitos[:12]) and digitos[13] == dv(digitos[:13])


def normalizar_cnpj(bruto):
    """So aceita CNPJ completo com digito verificador correto.

    Um CNPJ parcial (truncado/oculto) poderia apontar para o cliente errado:
    vinculo errado contamina faturamento; vinculo ausente so gera revisao.
    """
    if bruto is None or "*" in str(bruto):
        return None
    d = re.sub(r"\D", "", str(bruto))
    return d if cnpj_valido(d) else None


# --------------------------------------------------------------------------
# Registro completo + exclusao direcionada
# --------------------------------------------------------------------------

def estimar_peso(veiculo, qtd):
    """'7 carros' sem peso informado -> 7 x 1300 kg (peso tipico do veiculo)."""
    k = chave(veiculo).rstrip("s") if veiculo else ""
    return float(qtd * PESO_PADRAO_VEICULO[k]) if k in PESO_PADRAO_VEICULO and qtd else None


def normalizar_registro(r):
    """Devolve (registro_limpo, motivo_descarte). motivo None = registro valido."""
    o_cid, o_uf = normalizar_local(r["origem"])
    qtd = normalizar_qtd(r["qtd_unidades"])
    peso = normalizar_peso(r["peso"])
    peso_estimado = False
    if peso is None and (est := estimar_peso(r.get("veiculo"), qtd)):
        peso, peso_estimado = est, True
    d_cid, d_uf = normalizar_local(r["destino"])
    data, ambigua = normalizar_data(r["data_coleta"], r["canal"])
    limpo = {
        "id_demanda": r["id_demanda"],
        "canal": r["canal"],
        "cliente_nome_original": r["cliente_nome"],
        "cnpj": normalizar_cnpj(r["cnpj"]),
        "origem_cidade": o_cid, "origem_uf": o_uf,
        "destino_cidade": d_cid, "destino_uf": d_uf,
        "tipo_carga": normalizar_tipo(r["tipo_carga"]),
        "qtd_unidades": qtd,
        "peso_kg": peso,
        "peso_estimado": peso_estimado,
        "valor_frete": normalizar_valor(r["valor_frete"]),
        "data_coleta": data,
        "data_ambigua": ambigua,
        "status": normalizar_status(r["status"]) or (None if r["status"] else STATUS_PADRAO),
    }
    if not (o_cid and d_cid):
        return limpo, "rota incompleta ou nao parseavel"
    if limpo["qtd_unidades"] is None:
        return limpo, "quantidade de unidades invalida"
    return limpo, None


def executar(registros):
    """Normaliza todos os registros. Nenhum registro some em silencio:
    todo descarte vai para a lista de descartes com id, canal e motivo."""
    base, descartes, vistos = [], [], set()
    for r in registros:
        if r["id_demanda"] in vistos:
            descartes.append({"id_demanda": r["id_demanda"], "canal": r["canal"],
                              "motivo": "duplicata tecnica (id reenviado)",
                              "valor_bruto": ""})
            continue
        vistos.add(r["id_demanda"])
        limpo, motivo = normalizar_registro(r)
        if motivo:
            campo = {"rota": f"origem={r['origem']!r} destino={r['destino']!r}",
                     "quan": f"qtd_unidades={r['qtd_unidades']!r}"}[motivo[:4]]
            descartes.append({"id_demanda": r["id_demanda"], "canal": r["canal"],
                              "motivo": motivo, "valor_bruto": campo})
        else:
            base.append(limpo)
    return base, descartes
