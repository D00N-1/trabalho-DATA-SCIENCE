"""Dicionarios de referencia (vocabulario controlado)."""
import re
import unicodedata


def chave(texto) -> str:
    """Forma de comparacao: sem acento, minuscula, sem pontuacao, espacos unicos."""
    if texto is None:
        return ""
    s = unicodedata.normalize("NFKD", str(texto))
    s = "".join(c for c in s if not unicodedata.combining(c))
    s = s.lower().replace("_", " ")
    s = re.sub(r"[^a-z0-9 ]+", " ", s)
    return re.sub(r"\s+", " ", s).strip()


# Cidades atendidas: chave -> (nome oficial, UF)
CIDADES = {
    "cascavel": ("Cascavel", "PR"),
    "curitiba": ("Curitiba", "PR"),
    "toledo": ("Toledo", "PR"),
    "foz do iguacu": ("Foz do Iguaçu", "PR"),
    "maringa": ("Maringá", "PR"),
    "londrina": ("Londrina", "PR"),
    "ponta grossa": ("Ponta Grossa", "PR"),
    "chapeco": ("Chapecó", "SC"),
    "joinville": ("Joinville", "SC"),
    "florianopolis": ("Florianópolis", "SC"),
    "porto alegre": ("Porto Alegre", "RS"),
    "sao paulo": ("São Paulo", "SP"),
    "campinas": ("Campinas", "SP"),
    "dourados": ("Dourados", "MS"),
    "campo grande": ("Campo Grande", "MS"),
    "goiania": ("Goiânia", "GO"),
    "belo horizonte": ("Belo Horizonte", "MG"),
    "rio de janeiro": ("Rio de Janeiro", "RJ"),
}

# Coordenadas aproximadas (lat, lon) de cada cidade, para estimar a distancia da rota
COORDENADAS = {
    "Cascavel": (-24.956, -53.455), "Curitiba": (-25.429, -49.271),
    "Toledo": (-24.725, -53.743), "Foz do Iguaçu": (-25.516, -54.585),
    "Maringá": (-23.420, -51.933), "Londrina": (-23.310, -51.162),
    "Ponta Grossa": (-25.095, -50.162), "Chapecó": (-27.100, -52.615),
    "Joinville": (-26.304, -48.846), "Florianópolis": (-27.595, -48.548),
    "Porto Alegre": (-30.035, -51.218), "São Paulo": (-23.551, -46.633),
    "Campinas": (-22.906, -47.061), "Dourados": (-22.221, -54.806),
    "Campo Grande": (-20.469, -54.620), "Goiânia": (-16.686, -49.265),
    "Belo Horizonte": (-19.917, -43.934), "Rio de Janeiro": (-22.907, -43.173),
}
FATOR_RODOVIARIO = 1.25   # estrada e ~25% mais longa que a linha reta


def distancia_km(cidade_a, cidade_b):
    """Distancia rodoviaria estimada: linha reta (haversine) x fator rodoviario."""
    from math import asin, cos, radians, sin, sqrt
    if cidade_a not in COORDENADAS or cidade_b not in COORDENADAS:
        return None
    (la1, lo1), (la2, lo2) = COORDENADAS[cidade_a], COORDENADAS[cidade_b]
    a = sin(radians(la2 - la1) / 2) ** 2 + cos(radians(la1)) * cos(radians(la2)) * sin(radians(lo2 - lo1) / 2) ** 2
    return round(2 * 6371 * asin(sqrt(a)) * FATOR_RODOVIARIO, 1)


# Peso tipico por veiculo transportado (kg), para estimar o peso quando a fonte nao informa
PESO_PADRAO_VEICULO = {"carro": 1300, "moto": 180, "caminhonete": 2100}


# Apelidos usados em texto livre -> chave oficial
APELIDOS_CIDADE = {
    "cwb": "curitiba",
    "foz": "foz do iguacu",
    "poa": "porto alegre",
    "sampa": "sao paulo",
    "bh": "belo horizonte",
    "floripa": "florianopolis",
}

UFS = {"AC", "AL", "AP", "AM", "BA", "CE", "DF", "ES", "GO", "MA", "MT", "MS", "MG", "PA",
       "PB", "PR", "PE", "PI", "RJ", "RN", "RS", "RO", "RR", "SC", "SP", "SE", "TO"}

TIPOS_CARGA = {
    "cegonha": "CEGONHA",
    "cegonheira": "CEGONHA",
    "prancha": "PRANCHA",
    "guincho": "GUINCHO",
    "bau": "BAU",
    "sider": "SIDER",
    "carreta aberta": "CARRETA_ABERTA",
    "container": "CONTAINER",
}

STATUS = {
    "nova": "NOVA", "novo": "NOVA",
    "em cotacao": "EM_COTACAO",
    "cotada": "COTADA", "cotado": "COTADA",
    "aprovada": "APROVADA", "aprovado": "APROVADA",
    "agendada": "AGENDADA", "agendado": "AGENDADA",
    "cancelada": "CANCELADA", "cancelado": "CANCELADA",
    "concluida": "CONCLUIDA", "concluido": "CONCLUIDA",
}

MESES = {"jan": 1, "fev": 2, "mar": 3, "abr": 4, "mai": 5, "jun": 6,
         "jul": 7, "ago": 8, "set": 9, "out": 10, "nov": 11, "dez": 12}

# Por que cada coluna fora do schema e obsoleta para o HUB (chave da coluna -> motivo).
# A auditoria completa com evidencia medida (% preenchido, valores distintos).
MOTIVO_OBSOLETA = {
    "digitado por": "dado pessoal do operador (LGPD), sem uso para a demanda",
    "cod filial antigo": "codigo do sistema legado, nao existe mais",
    "col aux": "coluna auxiliar do sistema legado",
    "dt ult alteracao": "metadado de edicao da planilha, nao descreve a demanda",
    "observacao": "texto livre opcional, sem padrao para analise",
    "contato": "telefone pessoal (LGPD); o contato oficial esta no CRM",
    "evento": "tipo do webhook; o HUB so recebe 'demanda.criada'",
    "tentativa": "controle tecnico de reenvio; o reenvio e tratado pela deduplicacao por id",
    "recebido em": "metadado de transporte do portal",
    "data hora mensagem": "horario da mensagem, nao e a data de coleta",
    "autor": "remetente da conversa; o cliente e identificado pelo nome/CNPJ e pelo CRM",
}

# Cabecalhos encontrados nas fontes tabulares -> campo do schema
MAPA_COLUNAS = {
    "ref": "id_demanda", "id": "id_demanda", "oc": "id_demanda",
    "cliente": "cliente_nome", "empresa": "cliente_nome",
    "cnpj": "cnpj", "documento": "cnpj",
    "origem": "origem", "saida": "origem",
    "destino": "destino", "chegada": "destino",
    "qtd": "qtd_unidades", "veiculos": "qtd_unidades", "quantidade": "qtd_unidades",
    "tipo": "tipo_carga", "equipamento": "tipo_carga",
    "peso": "peso",
    "valor": "valor_frete", "frete": "valor_frete",
    "coleta": "data_coleta", "data coleta": "data_coleta", "dt coleta": "data_coleta",
    "status": "status", "situacao": "status",
}
