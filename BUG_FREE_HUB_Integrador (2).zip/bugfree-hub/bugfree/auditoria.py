"""Estagio 03 - Auditoria: mede a bagunca ANTES de qualquer correcao."""
import re
from collections import Counter

import numpy as np

from .catalogos import MOTIVO_OBSOLETA, chave
from .normalizacao import (normalizar_local, normalizar_peso, normalizar_qtd, normalizar_status,
                           normalizar_tipo, normalizar_valor)

# --------------------------------------------------------------------------
# Classificadores de formato (o que esta escrito, nao o que significa)
# --------------------------------------------------------------------------

FORMATOS_VALOR = [
    "R$ 1.500,00 (moeda BR com simbolo)",
    "1.500,00 (BR sem simbolo)",
    "1500.00 (numero com ponto)",
    "1500 (inteiro)",
    "1,5k (abreviado)",
]


def formato_valor(v):
    if isinstance(v, (int, float)):
        return FORMATOS_VALOR[2]
    s = str(v).strip()
    if s.startswith("R$"):
        return FORMATOS_VALOR[0]
    if s.lower().endswith("k"):
        return FORMATOS_VALOR[4]
    if re.fullmatch(r"\d{1,3}(\.\d{3})*,\d{2}", s):
        return FORMATOS_VALOR[1]
    if re.fullmatch(r"\d+\.\d+", s):
        return FORMATOS_VALOR[2]
    if re.fullmatch(r"\d+", s):
        return FORMATOS_VALOR[3]
    return "outro"


def formato_peso(v):
    if isinstance(v, (int, float)):
        return "kg (numero)"
    s = str(v).lower()
    if s.endswith("t"):
        return "toneladas (12 t)"
    if s.endswith("kg"):
        return "kg com unidade (12000 kg)"
    return "sem unidade (12000)"


def formato_cnpj(v):
    if v is None:
        return "ausente"
    s = str(v)
    if "*" in s:
        return "oculto (**.***.***/0001-**)"
    d = re.sub(r"\D", "", s)
    if len(d) < 14:
        return "truncado (24.883.107)"
    return "cru (so digitos)" if s.isdigit() else "com mascara (00.000.000/0000-00)"


def formato_data(v):
    if v is None:
        return "ausente"
    s = str(v)
    if re.match(r"\d{4}-\d{2}-\d{2}", s):
        return "ISO (2026-04-15)"
    if re.fullmatch(r"\d{1,2}-[a-zA-Z]{3}-\d{4}", s):
        return "dd-mmm-aaaa (15-abr-2026)"
    if (m := re.fullmatch(r"(\d{1,2})/(\d{1,2})/\d{4}", s)):
        return "mm/dd/aaaa (04/25/2026)" if int(m[2]) > 12 else "dd/mm/aaaa (15/04/2026)"
    return "outro"


def _distribuicao(valores, classificador):
    c = Counter(classificador(v) for v in valores)
    total = sum(c.values())
    return [{"formato": k, "registros": n, "pct": round(100 * n / total, 1)}
            for k, n in c.most_common()]


# --------------------------------------------------------------------------

def _cardinalidade(registros, campo, canonico):
    brutos = [r[campo] for r in registros if r[campo] is not None]
    distintos = {str(v).strip() for v in brutos}
    reais = {canonico(v) for v in distintos} - {None, (None, None)}
    return {"coluna": campo, "distintos": len(distintos), "reais": len(reais),
            "grafias": sorted(distintos)}


def colunas_obsoletas(obsoletas):
    """Justifica cada coluna eliminada com evidencia medida + motivo de negocio."""
    linhas = []
    for canal, cols in obsoletas.items():
        for col, valores in cols.items():
            preenchidos = [str(v).strip() for v in valores if v not in (None, "") and str(v).strip()]
            distintos = len(set(preenchidos))
            pct = round(100 * len(preenchidos) / len(valores), 1) if valores else 0.0
            evidencia = ("100% vazia" if not preenchidos else
                         "valor constante" if distintos == 1 else
                         f"{pct}% preenchida, {distintos} valores distintos")
            linhas.append({"canal": canal, "coluna": col, "registros": len(valores),
                           "preenchido_pct": pct, "valores_distintos": distintos,
                           "evidencia": evidencia,
                           "motivo": MOTIVO_OBSOLETA.get(chave(col), "fora do schema do HUB")})
    return linhas


def _descrever(nums):
    a = np.array(nums, dtype=float)
    q1, med, q3 = np.percentile(a, [25, 50, 75])
    iqr = q3 - q1
    lo, hi = q1 - 1.5 * iqr, q3 + 1.5 * iqr
    return {"n": int(len(a)), "media": round(float(a.mean()), 2), "desvio_padrao": round(float(a.std(ddof=1)), 2),
            "minimo": round(float(a.min()), 2), "q1": round(float(q1), 2), "mediana": round(float(med), 2),
            "q3": round(float(q3), 2), "maximo": round(float(a.max()), 2),
            "outliers_iqr": int(((a < lo) | (a > hi)).sum()), "limites_iqr": [round(float(lo), 2), round(float(hi), 2)]}


def estatisticas(registros):
    """Estatistica descritiva dos campos numericos, convertidos so para medir
    (o registro bruto nao e alterado). Outliers pelo criterio de Tukey (1,5 x IQR)."""
    valores = [v for r in registros if (v := normalizar_valor(r["valor_frete"])) is not None]
    pesos = [p for r in registros if (p := normalizar_peso(r["peso"])) is not None]
    qtds = [q for r in registros if (q := normalizar_qtd(r["qtd_unidades"])) is not None]
    por_veic = [normalizar_valor(r["valor_frete"]) / q for r in registros
                if (q := normalizar_qtd(r["qtd_unidades"])) and normalizar_valor(r["valor_frete"])]
    return {"valor_frete": _descrever(valores), "valor_por_veiculo": _descrever(por_veic),
            "peso_kg": _descrever(pesos), "qtd_unidades": _descrever(qtds)}


def auditar(por_canal, obsoletas=None):
    registros = [r for regs in por_canal.values() for r in regs]
    ids = Counter(r["id_demanda"] for r in registros)
    campos = [c for c in registros[0] if c not in ("id_demanda", "canal")]
    return {
        "estatisticas": estatisticas(registros),
        "colunas_obsoletas": colunas_obsoletas(obsoletas or {}),
        "total_brutos": len(registros),
        "por_canal": {c: len(v) for c, v in por_canal.items()},
        "ids_repetidos": {k: n for k, n in ids.items() if n > 1},
        "cardinalidade": [
            _cardinalidade(registros, "origem", normalizar_local),
            _cardinalidade(registros, "destino", normalizar_local),
            _cardinalidade(registros, "tipo_carga", normalizar_tipo),
            _cardinalidade(registros, "status", normalizar_status),
        ],
        "formatos": {
            "valor_frete": _distribuicao([r["valor_frete"] for r in registros
                                          if r["valor_frete"] is not None], formato_valor),
            "peso": _distribuicao([r["peso"] for r in registros if r["peso"] is not None],
                                  formato_peso),
            "cnpj": _distribuicao([r["cnpj"] for r in registros], formato_cnpj),
            "data_coleta": _distribuicao([r["data_coleta"] for r in registros], formato_data),
        },
        "nulos_por_campo": {c: sum(1 for r in registros if r[c] is None) for c in campos},
    }
