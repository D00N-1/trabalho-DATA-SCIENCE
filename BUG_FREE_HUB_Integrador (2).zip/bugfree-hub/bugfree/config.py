"""Caminhos e parametros do pipeline."""
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
DIR_DADOS = RAIZ / "data"
DIR_RAW = DIR_DADOS / "raw"
ARQ_CRM = DIR_DADOS / "crm" / "clientes.csv"
ARQ_GABARITO = DIR_DADOS / "gabarito" / "vinculo_rotulado.csv"
DIR_OUTPUT = RAIZ / "output"

# Limiar de similaridade (0-100) para o vinculo fuzzy por razao social.
# Valor escolhido pela curva de calibracao (bugfree/calibracao.py): o MAIOR
# limiar que ainda atinge o melhor F1 sobre os pares rotulados. Preferimos o
# lado conservador porque vinculo errado contamina faturamento, enquanto
# vinculo ausente so gera trabalho de revisao.
LIMIAR_FUZZY = 85

# Formato de data de cada canal. "dmy" = dd/mm/aaaa (padrao BR), "iso" = aaaa-mm-dd.
# None = canal sem formato garantido (texto humano): datas em que dia e mes
# podem ser trocados sao lidas como dd/mm e marcadas como ambiguas.
LOCALE_CANAL = {
    "whatsapp": None,
    "email": "dmy",
    "api": "iso",
    "csv": "dmy",
    "pdf": "dmy",
}

# Status atribuido quando o canal nao informa nenhum (ex.: WhatsApp).
STATUS_PADRAO = "NOVA"
