"""IA 3 - Taxa de acerto da extracao de campos de mensagens livres (WhatsApp).

Pergunta de negocio: "como extrair automaticamente origem, destino, quantidade,
valor, prazo e cliente de uma mensagem livre?"

Extrator avaliado: expressoes regulares (parsers.py) + normalizacao (dicionario de
cidades, apelidos e aproximacao) + vinculo ao CRM por similaridade de nomes.
Linha de base: ler so mensagens no formato de template ("Campo: valor"), que e o que
um sistema sem tratamento de texto livre conseguiria fazer.

Dois conjuntos de avaliacao:
  1. as 25 mensagens do lote (formatos que o grupo conhecia ao escrever as regras);
  2. 10 mensagens novas escritas de outro jeito (data/gabarito/mensagens_teste.csv),
     para medir o quanto o extrator generaliza para textos que ele nunca viu.
"""
import csv

from . import crm
from .normalizacao import (normalizar_cnpj, normalizar_data, normalizar_local, normalizar_qtd,
                           normalizar_valor)
from .parsers import _template, extrair_mensagem, mensagens_de_clientes

CAMPOS = ["cliente_id", "origem", "destino", "qtd_unidades", "valor_frete", "data_coleta"]


def _cliente(campos, clientes, limiar):
    cnpj = normalizar_cnpj(campos.get("cnpj"))
    if cnpj:
        c = next((c for c in clientes if c["cnpj_digitos"] == cnpj), None)
        if c:
            return c["cliente_id"]
    cli, score = crm.melhor_candidato(campos.get("cliente_nome"), clientes)
    return cli["cliente_id"] if cli and score >= limiar else None


def normalizar_extracao(campos, clientes, limiar):
    """Campos crus extraidos -> valores comparaveis com o gabarito."""
    return {"cliente_id": _cliente(campos, clientes, limiar),
            "origem": normalizar_local(campos.get("origem"))[0],
            "destino": normalizar_local(campos.get("destino"))[0],
            "qtd_unidades": normalizar_qtd(campos.get("qtd_unidades")),
            "valor_frete": normalizar_valor(campos.get("valor_frete")),
            "data_coleta": normalizar_data(campos.get("data_coleta"), "whatsapp")[0]}


def _gab(linha):
    num = lambda v, t: t(float(v)) if v not in ("", None) else None
    return {"cliente_id": linha.get("cliente_id") or None, "origem": linha.get("origem") or None,
            "destino": linha.get("destino") or None, "qtd_unidades": num(linha.get("qtd_unidades"), int),
            "valor_frete": num(linha.get("valor_frete"), float), "data_coleta": linha.get("data_coleta") or None}


def _medir(pares):
    """pares = [(id, previsto, real)] -> acuracia por campo e de registro completo."""
    por_campo = {c: round(100 * sum(p[c] == r[c] for _, p, r in pares) / len(pares), 1) for c in CAMPOS}
    completo = round(100 * sum(all(p[c] == r[c] for c in CAMPOS) for _, p, r in pares) / len(pares), 1)
    erros = [{"id": i, "campo": c, "extraido": p[c], "correto": r[c]}
             for i, p, r in pares for c in CAMPOS if p[c] != r[c]]
    media = round(sum(por_campo.values()) / len(CAMPOS), 1)
    return {"mensagens": len(pares), "por_campo": por_campo, "media_campos": media,
            "registro_completo": completo, "erros": erros}


def avaliar(raw, arq_gabarito_lote, arq_teste, clientes, limiar):
    with open(arq_gabarito_lote, encoding="utf-8") as f:
        gab = {l["id_demanda"]: _gab(l) for l in csv.DictReader(f)}
    msgs = mensagens_de_clientes(raw)
    lote = [(i, normalizar_extracao(extrair_mensagem(c), clientes, limiar), gab[i]) for i, c in msgs]
    base_lote = [(i, normalizar_extracao(_template(c), clientes, limiar), gab[i]) for i, c in msgs]

    with open(arq_teste, encoding="utf-8") as f:
        teste_l = list(csv.DictReader(f, delimiter=";"))
    teste = [(f"T{n:02d}", normalizar_extracao(extrair_mensagem(l["mensagem"]), clientes, limiar), _gab(l))
             for n, l in enumerate(teste_l, start=1)]
    base_teste = [(f"T{n:02d}", normalizar_extracao(_template(l["mensagem"]), clientes, limiar), _gab(l))
                  for n, l in enumerate(teste_l, start=1)]
    textos = {f"T{n:02d}": l["mensagem"] for n, l in enumerate(teste_l, start=1)}
    res_teste = _medir(teste)
    for e in res_teste["erros"]:
        e["mensagem"] = textos[e["id"]]
    return {"campos": CAMPOS,
            "lote": _medir(lote), "lote_linha_de_base": _medir(base_lote),
            "teste": res_teste, "teste_linha_de_base": _medir(base_teste)}
