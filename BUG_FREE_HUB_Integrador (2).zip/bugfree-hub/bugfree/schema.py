"""Schema unico: o unico acoplamento entre as camadas.

Os leitores (parsers.py) entregam registros BRUTOS neste formato, com os
valores exatamente como vieram da fonte. A limpeza (normalizacao.py) recebe
esses registros e devolve registros no formato FINAL.
"""

CAMPOS_BRUTOS = [
    "id_demanda", "canal", "cliente_nome", "cnpj", "origem", "destino",
    "tipo_carga", "qtd_unidades", "peso", "valor_frete", "data_coleta", "status",
    "veiculo",   # so o WhatsApp informa ("7 carros"); usado para estimar o peso
]

CAMPOS_FINAIS = [
    "id_demanda", "canal",
    "cliente_id", "cliente_razao_social", "metodo_vinculo", "score_vinculo",
    "cliente_nome_original", "cnpj",
    "origem_cidade", "origem_uf", "destino_cidade", "destino_uf",
    "tipo_carga", "qtd_unidades", "peso_kg", "peso_estimado", "valor_frete",
    "data_coleta", "data_ambigua", "status",
]


def registro_bruto(**campos) -> dict:
    """Cria um registro bruto garantindo que so existam campos do schema."""
    extras = set(campos) - set(CAMPOS_BRUTOS)
    if extras:
        raise ValueError(f"Campos fora do schema: {sorted(extras)}")
    reg = {c: None for c in CAMPOS_BRUTOS}
    for c, v in campos.items():
        if isinstance(v, str):
            v = v.strip() or None
        reg[c] = v
    return reg
