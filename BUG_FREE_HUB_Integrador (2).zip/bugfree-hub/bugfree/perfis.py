"""IA 2 - Perfis de demanda (K-means), anomalias (DBSCAN) e casos parecidos (KNN).

Pergunta de negocio: "que tipos de demanda recebemos e quais fogem do padrao?"
Quem usa: o planejamento (perfis -> que frota/equipamento priorizar) e o
comercial (anomalia -> conferir a demanda antes de aceitar).

- K-means agrupa as demandas por distancia, porte do veiculo e tamanho do lote.
  O numero de grupos (k) e escolhido pela silhueta. Linha de base: silhueta de
  uma divisao aleatoria com o mesmo k.
- DBSCAN procura demandas "isoladas" considerando rota, porte e preco por veiculo.
  Linha de base: regra estatistica simples (IQR / Tukey) so sobre o preco por veiculo.
  As duas sao comparadas com o gabarito de fretes fora da curva (precisao/recall).
- KNN (vizinhos mais proximos) mostra as demandas anteriores mais parecidas com uma nova.
"""
import csv
import pickle

import numpy as np
from sklearn.cluster import DBSCAN, KMeans
from sklearn.metrics import silhouette_score
from sklearn.neighbors import NearestNeighbors
from sklearn.preprocessing import StandardScaler

from .catalogos import distancia_km

SEMENTE = 42
ATRIB_PERFIL = ["distancia_km", "peso_por_veiculo", "qtd_unidades"]
ATRIB_ANOMALIA = ["log_distancia", "log_peso_por_veiculo", "log_valor_por_veiculo"]


def _num(v):
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def vetor(r, mediana_peso):
    """Atributos de uma demanda normalizada (None se faltar rota/quantidade)."""
    km = distancia_km(r.get("origem_cidade"), r.get("destino_cidade"))
    q = _num(r.get("qtd_unidades"))
    if km is None or not q:
        return None
    peso = _num(r.get("peso_kg"))
    pv = peso / q if peso else mediana_peso
    v = _num(r.get("valor_frete"))
    return {"distancia_km": km, "peso_por_veiculo": pv, "qtd_unidades": q,
            "valor_por_veiculo": v / q if v else None,
            # log: escala relativa (metade ou dobro do preco pesam igual; 100 km e 1.600 km ficam comparaveis)
            "log_distancia": np.log(km), "log_peso_por_veiculo": np.log(pv),
            "log_valor_por_veiculo": np.log(v / q) if v else None}


def _nome_perfil(c):
    dist = "curta distancia" if c[0] < 500 else "media distancia" if c[0] < 1000 else "longa distancia"
    porte = "motos" if c[1] < 600 else "carros" if c[1] < 1700 else "caminhonetes"
    lote = "lote pequeno" if c[2] <= 3 else "lote medio" if c[2] <= 6 else "lote grande"
    return f"{porte.capitalize()} · {dist} · {lote}"


def treinar_e_avaliar(base, gabarito_anomalias=None):
    pesos = [_num(r["peso_kg"]) / _num(r["qtd_unidades"]) for r in base
             if _num(r.get("peso_kg")) and _num(r.get("qtd_unidades"))]
    mediana_peso = float(np.median(pesos))
    linhas = [(r, x) for r in base if (x := vetor(r, mediana_peso))]
    ids = [r["id_demanda"] for r, _ in linhas]

    # ---------------- K-means: perfis ----------------
    Xp = np.array([[x[a] for a in ATRIB_PERFIL] for _, x in linhas])
    esc_p = StandardScaler().fit(Xp)
    Zp = esc_p.transform(Xp)
    rng = np.random.default_rng(SEMENTE)
    busca = []
    for k in range(2, 7):
        km = KMeans(n_clusters=k, n_init=10, random_state=SEMENTE).fit(Zp)
        aleatorio = np.mean([silhouette_score(Zp, rng.integers(0, k, len(Zp))) for _ in range(20)])
        busca.append({"k": k, "silhueta": round(float(silhouette_score(Zp, km.labels_)), 3),
                      "silhueta_aleatoria": round(float(aleatorio), 3), "inercia": round(float(km.inertia_), 1)})
    k_best = max(busca, key=lambda b: b["silhueta"])["k"]
    kmeans = KMeans(n_clusters=k_best, n_init=10, random_state=SEMENTE).fit(Zp)
    centros = esc_p.inverse_transform(kmeans.cluster_centers_)
    nomes = [_nome_perfil(c) for c in centros]
    for i, n in enumerate(nomes):                       # desempata nomes repetidos
        if nomes.count(n) > 1:
            nomes[i] = f"{n} ({i + 1})"
    perfis = []
    for g in range(k_best):
        membros = [linhas[i] for i in np.where(kmeans.labels_ == g)[0]]
        vpv = [x["valor_por_veiculo"] for _, x in membros if x["valor_por_veiculo"]]
        perfis.append({"grupo": g, "nome": nomes[g], "demandas": len(membros),
                       "distancia_media_km": round(float(centros[g][0])),
                       "peso_medio_por_veiculo": round(float(centros[g][1])),
                       "qtd_media": round(float(centros[g][2]), 1),
                       "frete_medio_por_veiculo": round(float(np.mean(vpv)), 2) if vpv else None,
                       "exemplos": [r["id_demanda"] for r, _ in membros[:4]]})
    grupo_de = dict(zip(ids, kmeans.labels_.tolist()))

    # ---------------- DBSCAN: anomalias ----------------
    com_valor = [(r, x) for r, x in linhas if x["log_valor_por_veiculo"] is not None]
    ids_v = [r["id_demanda"] for r, _ in com_valor]
    Xa = np.array([[x[a] for a in ATRIB_ANOMALIA] for _, x in com_valor])
    esc_a = StandardScaler().fit(Xa)
    Za = esc_a.transform(Xa)
    # parametros escolhidos comparando 90/95/98 x 3/4/5 contra o gabarito (melhor recall com
    # menos marcacoes): min_samples=3 e eps = percentil 90 da distancia ate o 3o vizinho
    min_amostras = 3
    dist_k = NearestNeighbors(n_neighbors=min_amostras).fit(Za).kneighbors(Za)[0][:, -1]
    eps = float(np.percentile(dist_k, 90))
    db = DBSCAN(eps=eps, min_samples=min_amostras).fit(Za)
    anom_db = {ids_v[i] for i in np.where(db.labels_ == -1)[0]}

    # linha de base: Tukey (1,5 x IQR) so no preco por veiculo
    vpv = np.array([x["valor_por_veiculo"] for _, x in com_valor])
    q1, q3 = np.percentile(vpv, [25, 75])
    lo, hi = q1 - 1.5 * (q3 - q1), q3 + 1.5 * (q3 - q1)
    anom_iqr = {ids_v[i] for i in np.where((vpv < lo) | (vpv > hi))[0]}

    def _avaliar(previstos):
        if gabarito_anomalias is None:
            return None
        reais = {i for i in ids_v if gabarito_anomalias.get(i)}
        vp = len(previstos & reais)
        return {"marcadas": len(previstos), "reais": len(reais), "acertos": vp,
                "precisao": round(100 * vp / len(previstos), 1) if previstos else 0.0,
                "recall": round(100 * vp / len(reais), 1) if reais else 0.0}

    por_id = {r["id_demanda"]: (r, x) for r, x in com_valor}

    def _desc(i):
        r, x = por_id[i]
        return {"id_demanda": i, "rota": f"{r['origem_cidade']} -> {r['destino_cidade']}",
                "km": round(x["distancia_km"]), "qtd": int(x["qtd_unidades"]),
                "valor_por_veiculo": round(x["valor_por_veiculo"], 2),
                "real_fora_da_curva": bool(gabarito_anomalias.get(i)) if gabarito_anomalias else None}

    # ---------------- KNN: casos parecidos ----------------
    Xs = np.array([[x["distancia_km"], x["peso_por_veiculo"]] for _, x in com_valor])
    esc_s = StandardScaler().fit(Xs)
    vizinhos = NearestNeighbors(n_neighbors=3).fit(esc_s.transform(Xs))
    historico = [_desc(i) for i in ids_v]
    for h in historico:
        h["perfil"] = nomes[grupo_de[h["id_demanda"]]]

    art = {"mediana_peso": mediana_peso, "esc_p": esc_p, "kmeans": kmeans, "nomes": nomes,
           "esc_a": esc_a, "nucleos": Za[db.core_sample_indices_], "eps": eps,
           "esc_s": esc_s, "vizinhos": vizinhos, "historico": historico}
    return {
        "perfis": {"atributos": ATRIB_PERFIL, "busca_k": busca, "k": k_best,
                   "silhueta": next(b["silhueta"] for b in busca if b["k"] == k_best),
                   "silhueta_aleatoria": next(b["silhueta_aleatoria"] for b in busca if b["k"] == k_best),
                   "grupos": perfis},
        "anomalias": {"atributos": ATRIB_ANOMALIA, "eps": round(eps, 3), "min_samples": min_amostras,
                      "dbscan": {"ids": sorted(anom_db), "avaliacao": _avaliar(anom_db),
                                 "detalhe": [_desc(i) for i in sorted(anom_db)]},
                      "linha_de_base_iqr": {"ids": sorted(anom_iqr), "avaliacao": _avaliar(anom_iqr),
                                            "limites": [round(float(lo), 2), round(float(hi), 2)]}},
        "_artefato": art,
    }


def analisar(art, demanda):
    """Demanda nova -> perfil, se foge do padrao e as 3 demandas mais parecidas."""
    x = vetor(demanda, art["mediana_peso"])
    if not x:
        return {"ok": False, "motivo": "Precisa de origem, destino e quantidade validos."}
    g = int(art["kmeans"].predict(art["esc_p"].transform([[x[a] for a in ATRIB_PERFIL]]))[0])
    res = {"ok": True, "perfil": art["nomes"][g]}
    if x["log_valor_por_veiculo"] is not None:
        z = art["esc_a"].transform([[x[a] for a in ATRIB_ANOMALIA]])[0]
        d = float(np.min(np.linalg.norm(art["nucleos"] - z, axis=1)))
        res["anomalia"] = d > art["eps"]          # longe de todo nucleo denso = foge do padrao
        res["distancia_padrao"] = round(d / art["eps"], 2)
    dist, idx = art["vizinhos"].kneighbors(art["esc_s"].transform([[x["distancia_km"], x["peso_por_veiculo"]]]))
    res["parecidos"] = [art["historico"][i] for i in idx[0]]
    return res


def carregar_gabarito_anomalias(caminho):
    with open(caminho, encoding="utf-8") as f:
        return {r["id_demanda"]: r.get("frete_fora_da_curva") == "1" for r in csv.DictReader(f)}


def salvar(art, caminho):
    with open(caminho, "wb") as f:
        pickle.dump(art, f)


def carregar_ou_treinar(caminho, caminho_base):
    if caminho.exists():
        with open(caminho, "rb") as f:
            return pickle.load(f)
    with open(caminho_base, encoding="utf-8-sig") as f:
        art = treinar_e_avaliar(list(csv.DictReader(f)))["_artefato"]
    salvar(art, caminho)
    return art
