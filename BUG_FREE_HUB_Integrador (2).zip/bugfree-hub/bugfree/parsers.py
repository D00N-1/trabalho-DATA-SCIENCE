"""Estagio 02 - Leitores: extraem e MAPEIAM cada fonte para o schema bruto.

Regra da arquitetura: parser nao limpa. Os valores saem exatamente como
estao na fonte; so a estrutura e traduzida para os campos do schema.
Um canal novo = uma funcao nova registrada em LEITORES.
"""
import csv
import json
import re
from html.parser import HTMLParser
from pathlib import Path

import pdfplumber

from .catalogos import MAPA_COLUNAS, chave
from .schema import registro_bruto


# Etapa "eliminacao de colunas obsoletas": toda coluna da fonte que nao pertence ao
# schema e registrada aqui (com os valores vistos) em vez de sumir em silencio.
# A auditoria usa esse registro para justificar a eliminacao de cada uma.
_OBSOLETAS = {}


def _registrar_obsoleta(canal, coluna, valor):
    _OBSOLETAS.setdefault(canal, {}).setdefault(coluna, []).append(valor)


def colunas_obsoletas():
    """{canal: {coluna: [valores encontrados]}} das colunas eliminadas na leitura."""
    return {c: dict(cols) for c, cols in _OBSOLETAS.items()}


def _mapear_linha(cabecalho, linha, canal):
    """Traduz uma linha tabular (cabecalho heterogeneo) para o schema."""
    campos = {}
    for col, valor in zip(cabecalho, linha):
        campo = MAPA_COLUNAS.get(chave(col))
        if campo:
            campos[campo] = valor
        else:
            _registrar_obsoleta(canal, col, valor)
    return registro_bruto(canal=canal, **campos)


def _eh_tabela_de_demandas(cabecalho):
    return any(MAPA_COLUNAS.get(chave(c)) == "id_demanda" for c in cabecalho)


# --------------------------------------------------------------------------
# 1. WhatsApp
# --------------------------------------------------------------------------

RE_MSG = re.compile(r"^(\d{2}/\d{2}/\d{4}) (\d{2}:\d{2}) - ([^:]+): (.*)$")
RE_ID = re.compile(r"^(WA-\d{4})\s*-\s*(.*)$", re.S)
VEIC = r"(?:carros?|motos?|caminhonetes?|ve[ií]culos?)"
RE_ROTA = re.compile(rf"\d+\s+{VEIC}\s+(?:saindo\s+)?de\s+(?P<orig>[^,.?]+?)\s+(?:pra|para)\s+(?P<dest>[^,.?]+)", re.I)
RE_SO_ORIGEM = re.compile(rf"\d+\s+{VEIC}\s+(?:saindo\s+)?de\s+(?P<orig>[^,.?]+)", re.I)
RE_QTD = re.compile(rf"(?P<q>\d+)\s+(?P<v>{VEIC})", re.I)
RE_DATA = re.compile(r"coleta\s+(?P<d>\d{1,2}/\d{1,2}/\d{4})", re.I)
RE_VALOR = re.compile(r"(?:fecha em|valor)\s+(?P<v>R\$\s?[\d.,]+|[\d.,]+k?)", re.I)
RE_NOME = [re.compile(r"^oi,\s*(?P<n>.+?)\s+aqui\.", re.I),
           re.compile(r"aqui [ée] d[ao]\s+(?P<n>.+?)\.", re.I)]
CAMPOS_TEMPLATE = {"empresa": "cliente_nome", "cnpj": "cnpj", "origem": "origem",
                   "destino": "destino", "veiculos": "qtd_unidades", "tipo": "tipo_carga",
                   "coleta": "data_coleta", "valor": "valor_frete"}


def _texto_livre(corpo):
    campos = {}
    m = RE_ROTA.search(corpo)
    if m:
        campos["origem"], campos["destino"] = m["orig"], m["dest"]
    elif (m := RE_SO_ORIGEM.search(corpo)):
        campos["origem"] = m["orig"]
    if (m := RE_QTD.search(corpo)):
        campos["qtd_unidades"], campos["veiculo"] = m["q"], m["v"]
    if (m := RE_DATA.search(corpo)):
        campos["data_coleta"] = m["d"]
    if (m := RE_VALOR.search(corpo)):
        campos["valor_frete"] = m["v"]
    for rx in RE_NOME:
        if (m := rx.search(corpo)):
            campos["cliente_nome"] = m["n"]
            break
    return campos


def _template(corpo):
    campos = {}
    for linha in corpo.splitlines():
        if ":" in linha:
            rotulo, valor = linha.split(":", 1)
            campo = CAMPOS_TEMPLATE.get(chave(rotulo))
            if campo:
                campos[campo] = valor.strip()
    return campos


def extrair_mensagem(corpo):
    """Texto de UMA mensagem -> campos do schema (template 'Campo: valor' ou texto livre)."""
    return _template(corpo) if "Empresa:" in corpo else _texto_livre(corpo)


def mensagens_de_clientes(raw: Path):
    """[(id_demanda, corpo)] das mensagens de clientes na conversa exportada."""
    saida = []
    for msg in _mensagens(raw):
        if msg["autor"] == "Cliente" and (m := RE_ID.match(msg["texto"])):
            saida.append((m[1], m[2]))
    return saida


def _mensagens(raw: Path):
    mensagens, atual = [], None
    for linha in (raw / "whatsapp").glob("*.txt").__next__().read_text(encoding="utf-8").splitlines():
        m = RE_MSG.match(linha)
        if m:
            atual = {"autor": m[3].strip(), "texto": m[4], "quando": f"{m[1]} {m[2]}"}
            mensagens.append(atual)
        elif atual is not None:
            atual["texto"] += "\n" + linha
    return mensagens


def ler_whatsapp(raw: Path):
    mensagens, atual = [], None
    for linha in (raw / "whatsapp").glob("*.txt").__next__().read_text(encoding="utf-8").splitlines():
        m = RE_MSG.match(linha)
        if m:
            atual = {"autor": m[3].strip(), "texto": m[4], "quando": f"{m[1]} {m[2]}"}
            mensagens.append(atual)
        elif atual is not None:            # continuacao de mensagem com quebra de linha
            atual["texto"] += "\n" + linha
    registros = []
    for msg in mensagens:
        if msg["autor"] != "Cliente":      # respostas do operador nao sao demandas
            continue
        m = RE_ID.match(msg["texto"])
        if not m:
            continue
        id_, corpo = m[1], m[2]
        _registrar_obsoleta("whatsapp", "data_hora_mensagem", msg["quando"])
        _registrar_obsoleta("whatsapp", "autor", msg["autor"])
        campos = _template(corpo) if "Empresa:" in corpo else _texto_livre(corpo)
        registros.append(registro_bruto(id_demanda=id_, canal="whatsapp", **campos))
    return registros


# --------------------------------------------------------------------------
# 2. E-mail (tabelas HTML)
# --------------------------------------------------------------------------

class _Tabelas(HTMLParser):
    def __init__(self):
        super().__init__()
        self.tabelas, self._linha, self._celula = [], None, None

    def handle_starttag(self, tag, attrs):
        if tag == "table":
            self.tabelas.append([])
        elif tag == "tr":
            self._linha = []
        elif tag in ("td", "th"):
            self._celula = ""

    def handle_endtag(self, tag):
        if tag in ("td", "th") and self._linha is not None:
            self._linha.append(self._celula or "")
            self._celula = None
        elif tag == "tr" and self._linha is not None:
            self.tabelas[-1].append(self._linha)
            self._linha = None

    def handle_data(self, data):
        if self._celula is not None:
            self._celula += data


def ler_email(raw: Path):
    registros = []
    for arq in sorted((raw / "email").glob("*.html")):
        p = _Tabelas()
        p.feed(arq.read_text(encoding="utf-8"))
        for tabela in p.tabelas:
            if not tabela or not _eh_tabela_de_demandas(tabela[0]):
                continue                    # ignora tabela de assinatura etc.
            cab = tabela[0]
            registros += [_mapear_linha(cab, l, "email") for l in tabela[1:]]
    return registros


# --------------------------------------------------------------------------
# 3. Portal / API (webhook JSON)
# --------------------------------------------------------------------------

def ler_api(raw: Path):
    registros = []
    for arq in sorted((raw / "api").glob("*.jsonl")):
        for linha in arq.read_text(encoding="utf-8").splitlines():
            if not linha.strip():
                continue
            evento = json.loads(linha)
            for k, v in evento.items():
                if k != "payload":
                    _registrar_obsoleta("api", k, v)
            p = evento["payload"]
            registros.append(registro_bruto(
                id_demanda=p.get("id_demanda"), canal="api",
                cliente_nome=p.get("cliente", {}).get("razao_social"),
                cnpj=p.get("cliente", {}).get("cnpj"),
                origem=p.get("rota", {}).get("origem"),
                destino=p.get("rota", {}).get("destino"),
                tipo_carga=p.get("carga", {}).get("tipo"),
                qtd_unidades=p.get("carga", {}).get("qtd"),
                peso=p.get("carga", {}).get("peso_kg"),
                valor_frete=p.get("valor"),
                data_coleta=p.get("data_coleta"),
                status=p.get("status"),
            ))
    return registros


# --------------------------------------------------------------------------
# 4. Planilha legado (CSV latin-1)
# --------------------------------------------------------------------------

def ler_csv(raw: Path):
    registros = []
    for arq in sorted((raw / "csv").glob("*.csv")):
        with open(arq, encoding="latin-1", newline="") as f:
            leitor = csv.reader(f, delimiter=";")
            cab = next(leitor)
            registros += [_mapear_linha(cab, l, "csv") for l in leitor if any(l)]
    return registros


# --------------------------------------------------------------------------
# 5. Ordem de coleta (PDF com tabela)
# --------------------------------------------------------------------------

def ler_pdf(raw: Path):
    registros = []
    for arq in sorted((raw / "pdf").glob("*.pdf")):
        with pdfplumber.open(arq) as pdf:
            for pagina in pdf.pages:
                for tabela in pagina.extract_tables():
                    linhas = [[(c or "").replace("\n", " ") for c in l] for l in tabela]
                    if linhas and _eh_tabela_de_demandas(linhas[0]):
                        registros += [_mapear_linha(linhas[0], l, "pdf") for l in linhas[1:]]
    return registros


LEITORES = {
    "whatsapp": ler_whatsapp,
    "email": ler_email,
    "api": ler_api,
    "csv": ler_csv,
    "pdf": ler_pdf,
}


def ler_todos(raw: Path):
    """Executa todos os leitores e devolve {canal: [registros brutos]}."""
    _OBSOLETAS.clear()
    return {canal: leitor(raw) for canal, leitor in LEITORES.items()}
